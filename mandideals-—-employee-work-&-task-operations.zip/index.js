// index.ts
import express from "express";
import { createServer as createViteServer } from "vite";
import nodemailer from "nodemailer";
import dotenv from "dotenv";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { GoogleGenAI } from "@google/genai";
var __filename = fileURLToPath(import.meta.url);
var __dirname = path.dirname(__filename);
dotenv.config();
var ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      "User-Agent": "aistudio-build"
    }
  }
});
async function startServer() {
  const app = express();
  app.use(express.json());
  app.post("/api/chat", async (req, res) => {
    const { messages, speed = "general" } = req.body;
    try {
      if (!process.env.GEMINI_API_KEY) {
        return res.status(500).json({ error: "Gemini API key is not configured." });
      }
      let modelName = "gemini-3.5-flash";
      if (speed === "complex") modelName = "gemini-3.1-pro-preview";
      if (speed === "fast") modelName = "gemini-3.1-flash-lite";
      const systemInstruction = "You are the GMD Executive Assistant, a professional and helpful AI designed for the MANDIDEALS Employee Portal. Your role is to help employees and admins with task management, attendance protocols, and general operational queries. You are authoritative yet supportive, reflecting the executive culture of Sabyasachi Baral's leadership. Keep responses concise and actionable.";
      const response = await ai.models.generateContent({
        model: modelName,
        contents: messages.map((m) => ({
          role: m.role === "assistant" ? "model" : "user",
          parts: [{ text: m.content }]
        })),
        config: {
          systemInstruction
        }
      });
      res.status(200).json({ content: response.text });
    } catch (error) {
      console.error("Gemini Error:", error);
      res.status(500).json({ error: error.message || "Failed to generate AI response" });
    }
  });
  app.post("/api/send-otp", async (req, res) => {
    const { email, otp, name } = req.body;
    try {
      const transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST || "smtp.gmail.com",
        port: Number(process.env.SMTP_PORT) || 587,
        secure: false,
        auth: {
          user: process.env.SMTP_USER,
          pass: process.env.SMTP_PASS
        }
      });
      const mailOptions = {
        from: `"MANDIDEALS Executive" <${process.env.SMTP_USER || "noreply@mandideals.com"}>`,
        to: email,
        subject: "Executive Security Code - MANDIDEALS",
        html: `
          <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #eee; border-radius: 20px;">
            <h1 style="color: #10b981; font-weight: 900; margin-bottom: 20px;">MANDIDEALS</h1>
            <p style="font-size: 16px; color: #333;">Hello ${name},</p>
            <p style="font-size: 14px; color: #666;">You requested a password reset for your executive account. Use the following code to proceed:</p>
            <div style="background: #f4f4f5; padding: 20px; border-radius: 15px; text-align: center; margin: 30px 0;">
              <span style="font-size: 32px; font-weight: 900; letter-spacing: 10px; color: #111;">${otp}</span>
            </div>
            <p style="font-size: 12px; color: #999;">If you did not request this code, please ignore this email or contact the Super Admin.</p>
            <hr style="border: 0; border-top: 1px solid #eee; margin: 20px 0;" />
            <p style="font-size: 10px; text-align: center; color: #aaa; text-transform: uppercase; letter-spacing: 2px;">Executive Governance \xB7 MANDIDEALS 2026</p>
          </div>
        `
      };
      if (!process.env.SMTP_USER || !process.env.SMTP_PASS) {
        console.log("--- OTP DEBUG (No SMTP Credentials) ---");
        console.log(`To: ${email}`);
        console.log(`OTP: ${otp}`);
        console.log("----------------------------------------");
        return res.status(200).json({ success: true, message: "OTP logged to server console (Demo Mode)" });
      }
      await transporter.sendMail(mailOptions);
      res.status(200).json({ success: true });
    } catch (error) {
      console.error("SMTP Error:", error);
      res.status(500).json({ error: "Failed to send verification email" });
    }
  });
  const distPath = path.resolve(__dirname, "dist");
  const isProduction = fs.existsSync(distPath);
  if (!isProduction) {
    console.log("Running in DEVELOPMENT mode with Vite Middleware");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "custom"
    });
    app.use(vite.middlewares);
    app.use("*", async (req, res, next) => {
      const url = req.originalUrl;
      try {
        const template = fs.readFileSync(path.resolve(__dirname, "index.html"), "utf-8");
        const html = await vite.transformIndexHtml(url, template);
        res.status(200).set({ "Content-Type": "text/html" }).end(html);
      } catch (e) {
        vite.ssrFixStacktrace(e);
        next(e);
      }
    });
  } else {
    console.log("Running in PRODUCTION mode serving from /dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.resolve(distPath, "index.html"));
    });
  }
  const port = process.env.PORT || 3e3;
  app.listen(port, () => {
    console.log(`Server running at port ${port}`);
  });
}
startServer();
