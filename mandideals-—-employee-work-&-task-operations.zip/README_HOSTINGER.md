# MANDIDEALS Deployment Guide for Hostinger

To host this portal on Hostinger without any "Unsupported Framework" or "Invalid Structure" errors, follow these steps exactly:

## 1. Preparation
1. Click the **Download** button in AI Studio to get your project files.
2. **Delete** the `node_modules` folder if it exists in your download.
3. **Zip** all files in the root folder. Your zip should contain:
   - `src/` (folder)
   - `public/` (folder)
   - `package.json`
   - `index.ts`
   - `vite.config.ts`
   - `index.html`
   - `supabase_schema.sql`

## 2. Hostinger Setup
1. Go to the **Node.js** section in your Hostinger hPanel.
2. Upload and extract your `.zip` file into the root folder (e.g., `/home/u123/public_html`).
3. Set **Startup File** to: `index.js`
4. Set **Application Root**: `/home/u123/public_html` (adjust to your actual path).

## 3. Installation & Build (Crucial)
1. Click **npm install**.
2. Click **Run script** and choose `build`. 
   - *This will create the `/dist` folder and the `index.js` file automatically.*

## 4. Environment Variables
Add these in the Hostinger Node.js panel:
- `GEMINI_API_KEY`: Your key from Google AI Studio.
- `SMTP_USER`: Your email for OTPs.
- `SMTP_PASS`: Your email app password.

## 5. Database
- Go to your **Supabase SQL Editor**.
- Copy and run the code from `supabase_schema.sql`.

## 6. Start
- Click **Start** in the Hostinger dashboard.
