-- SQL Script for GMD Employee Portal (MandiDeals)
-- Use this script in the Supabase SQL Editor

/* 
  🚨 HARD RESET / RECOVERY MODE (Use if you see "Registration Sync Error")
  If your Supabase schema cache is stuck, follow these steps:
  1. UNCOMMENT the lines below (remove the -- from lines 12-18).
  2. RUN this script in the SQL Editor.
  3. REFRESH the app page.
  WARNING: This will delete all current staff data and start fresh!
*/

-- DROP TABLE IF EXISTS employees CASCADE;
-- DROP TABLE IF EXISTS attendance_logs CASCADE;
-- DROP TABLE IF EXISTS tasks CASCADE;
-- DROP TABLE IF EXISTS company_notices CASCADE;
-- DROP TABLE IF EXISTS leave_requests CASCADE;
-- DROP TABLE IF EXISTS notifications CASCADE;
-- DROP TABLE IF EXISTS company_settings CASCADE;

-- 1. Employees Table
CREATE TABLE IF NOT EXISTS employees (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password TEXT,
  role TEXT NOT NULL,
  department TEXT NOT NULL,
  phone TEXT,
  location TEXT,
  joineddate TEXT,
  shift TEXT,
  accesslevel TEXT DEFAULT 'STAFF',
  issuperadmin BOOLEAN DEFAULT FALSE,
  avatar TEXT,
  status TEXT DEFAULT 'Off Duty',
  bio TEXT,
  isauthorized BOOLEAN DEFAULT FALSE,
  ispunchedin BOOLEAN DEFAULT FALSE,
  createdat TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Ensure columns exist (for existing tables)
DO $$ 
BEGIN 
  IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='employees' AND COLUMN_NAME='accesslevel') THEN
    ALTER TABLE employees ADD COLUMN accesslevel TEXT DEFAULT 'STAFF';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='employees' AND COLUMN_NAME='isauthorized') THEN
    ALTER TABLE employees ADD COLUMN isauthorized BOOLEAN DEFAULT FALSE;
  END IF;
END $$;

-- Ensure tasks columns exist (for existing tables)
DO $$ 
BEGIN 
  IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='tasks' AND COLUMN_NAME='status') THEN
    ALTER TABLE tasks ADD COLUMN status TEXT DEFAULT 'todo';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='tasks' AND COLUMN_NAME='priority') THEN
    ALTER TABLE tasks ADD COLUMN priority TEXT DEFAULT 'medium';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='tasks' AND COLUMN_NAME='rating') THEN
    ALTER TABLE tasks ADD COLUMN rating DOUBLE PRECISION;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='tasks' AND COLUMN_NAME='subtasks') THEN
    ALTER TABLE tasks ADD COLUMN subtasks JSONB DEFAULT '[]'::jsonb;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='tasks' AND COLUMN_NAME='comments') THEN
    ALTER TABLE tasks ADD COLUMN comments JSONB DEFAULT '[]'::jsonb;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='tasks' AND COLUMN_NAME='duedate') THEN
    ALTER TABLE tasks ADD COLUMN duedate DATE;
  END IF;
END $$;

-- 2. Attendance Logs Table
CREATE TABLE IF NOT EXISTS attendance_logs (
  id TEXT PRIMARY KEY,
  employeeid TEXT NOT NULL,
  employeename TEXT NOT NULL,
  punchin TIMESTAMP WITH TIME ZONE NOT NULL,
  punchout TIMESTAMP WITH TIME ZONE,
  date DATE NOT NULL,
  punchinlat DOUBLE PRECISION,
  punchinlng DOUBLE PRECISION,
  punchoutlat DOUBLE PRECISION,
  punchoutlng DOUBLE PRECISION,
  islate BOOLEAN DEFAULT FALSE,
  createdat TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Ensure islate column exists
DO $$ 
BEGIN 
  IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='attendance_logs' AND COLUMN_NAME='islate') THEN
    ALTER TABLE attendance_logs ADD COLUMN islate BOOLEAN DEFAULT FALSE;
  END IF;
END $$;

-- 3. Tasks Table
CREATE TABLE IF NOT EXISTS tasks (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  employeename TEXT NOT NULL,
  employeerole TEXT,
  department TEXT NOT NULL,
  starttime TEXT NOT NULL,
  endtime TEXT NOT NULL,
  durationhours DOUBLE PRECISION,
  completed BOOLEAN DEFAULT FALSE,
  status TEXT DEFAULT 'todo',
  completedat TIMESTAMP WITH TIME ZONE,
  createdat TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  duedate DATE,
  remindertime TIMESTAMP WITH TIME ZONE,
  remindertriggered BOOLEAN DEFAULT FALSE,
  priority TEXT NOT NULL,
  rating DOUBLE PRECISION,
  subtasks JSONB DEFAULT '[]'::jsonb,
  comments JSONB DEFAULT '[]'::jsonb
);

-- 4. Company Notices Table
CREATE TABLE IF NOT EXISTS company_notices (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  authorname TEXT NOT NULL,
  authorrole TEXT NOT NULL,
  priority TEXT NOT NULL,
  createdat TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  pinned BOOLEAN DEFAULT FALSE
);

-- 5. Leave Requests Table
CREATE TABLE IF NOT EXISTS leave_requests (
  id TEXT PRIMARY KEY,
  employeeid TEXT NOT NULL,
  employeename TEXT NOT NULL,
  startdate DATE NOT NULL,
  enddate DATE NOT NULL,
  reason TEXT NOT NULL,
  status TEXT DEFAULT 'pending',
  createdat TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 6. Notifications Table
CREATE TABLE IF NOT EXISTS notifications (
  id TEXT PRIMARY KEY,
  taskid TEXT NOT NULL,
  tasktitle TEXT NOT NULL,
  employeename TEXT NOT NULL,
  message TEXT NOT NULL,
  triggeredat TIMESTAMP WITH TIME ZONE NOT NULL,
  read BOOLEAN DEFAULT FALSE
);

-- 7. Company Settings (for Singleton Configs)
CREATE TABLE IF NOT EXISTS company_settings (
  key TEXT PRIMARY KEY,
  value JSONB NOT NULL
);

-- Seed Initial Settings
INSERT INTO company_settings (key, value)
VALUES ('company_shift', '{"startTime12": "10:30 AM", "endTime12": "06:30 PM", "durationHours": 8.0, "updatedBy": "Sabyasachi", "updatedAt": "2026-09-29T00:00:00Z"}'::jsonb)
ON CONFLICT (key) DO NOTHING;

-- Seed Initial Departments
INSERT INTO company_settings (key, value)
VALUES ('departments', '["CEO Strategic Initiatives", "Business Development & Tech", "HR & Compliance", "Mandi Floor & Auction Operations", "Accounts & Settlement", "Quality Control & Lab", "Logistics & Fleet Management", "Executive Security & VIP Ops"]'::jsonb)
ON CONFLICT (key) DO NOTHING;

-- Seed Initial Employees
INSERT INTO employees (id, name, email, password, role, department, accesslevel, issuperadmin, isauthorized, status)
VALUES 
('emp-sandip-master', 'Sandip Sahoo (Master Admin)', 'sandeepsahoo2001@gmail.com', 'Sandip@123', 'Managing Director & CTO', 'CEO Strategic Initiatives', 'SUPER_ADMIN', TRUE, TRUE, 'Active'),
('emp-ceo-01', 'Sabyasachi Baral', 'sabyasachi.baral@mandideals.com', 'Sabya@123', 'Founder & CEO', 'CEO Strategic Initiatives', 'SUPER_ADMIN', TRUE, TRUE, 'Active'),
('emp-ceo-legacy', 'Sabyasachi', 'sabya@mandideals.com', 'Sabya@123', 'CEO & Managing Director', 'CEO Strategic Initiatives', 'SUPER_ADMIN', TRUE, TRUE, 'Active')
ON CONFLICT (id) DO NOTHING;

-- Enable public access for now (Development Mode)
ALTER TABLE employees ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public Read Access" ON employees;
DROP POLICY IF EXISTS "Public Write Access" ON employees;
CREATE POLICY "Public Read Access" ON employees FOR SELECT USING (true);
CREATE POLICY "Public Write Access" ON employees FOR ALL USING (true);

ALTER TABLE attendance_logs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public Read Access" ON attendance_logs;
DROP POLICY IF EXISTS "Public Write Access" ON attendance_logs;
CREATE POLICY "Public Read Access" ON attendance_logs FOR SELECT USING (true);
CREATE POLICY "Public Write Access" ON attendance_logs FOR ALL USING (true);

ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public Read Access" ON tasks;
DROP POLICY IF EXISTS "Public Write Access" ON tasks;
CREATE POLICY "Public Read Access" ON tasks FOR SELECT USING (true);
CREATE POLICY "Public Write Access" ON tasks FOR ALL USING (true);

ALTER TABLE company_notices ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public Read Access" ON company_notices;
DROP POLICY IF EXISTS "Public Write Access" ON company_notices;
CREATE POLICY "Public Read Access" ON company_notices FOR SELECT USING (true);
CREATE POLICY "Public Write Access" ON company_notices FOR ALL USING (true);

ALTER TABLE leave_requests ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public Read Access" ON leave_requests;
DROP POLICY IF EXISTS "Public Write Access" ON leave_requests;
CREATE POLICY "Public Read Access" ON leave_requests FOR SELECT USING (true);
CREATE POLICY "Public Write Access" ON leave_requests FOR ALL USING (true);

ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public Read Access" ON notifications;
DROP POLICY IF EXISTS "Public Write Access" ON notifications;
CREATE POLICY "Public Read Access" ON notifications FOR SELECT USING (true);
CREATE POLICY "Public Write Access" ON notifications FOR ALL USING (true);

ALTER TABLE company_settings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public Read Access" ON company_settings;
DROP POLICY IF EXISTS "Public Write Access" ON company_settings;
CREATE POLICY "Public Read Access" ON company_settings FOR SELECT USING (true);
CREATE POLICY "Public Write Access" ON company_settings FOR ALL USING (true);

-- Enable Realtime for all tables to ensure CEO sees live updates across browsers
-- IMPORTANT: You must run this in the Supabase SQL Editor!
ALTER PUBLICATION supabase_realtime ADD TABLE tasks;
ALTER PUBLICATION supabase_realtime ADD TABLE attendance_logs;
ALTER PUBLICATION supabase_realtime ADD TABLE employees;
ALTER PUBLICATION supabase_realtime ADD TABLE company_notices;
ALTER PUBLICATION supabase_realtime ADD TABLE leave_requests;
ALTER PUBLICATION supabase_realtime ADD TABLE notifications;
ALTER PUBLICATION supabase_realtime ADD TABLE company_settings;

-- Force PostgREST to reload the schema cache
NOTIFY pgrst, 'reload schema';
