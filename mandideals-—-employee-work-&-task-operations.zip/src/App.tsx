import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { TaskBoard } from './components/TaskBoard';
import { TaskModal } from './components/TaskModal';
import { ActiveReminderBanner } from './components/ActiveReminderBanner';
import { AuthScreen } from './components/AuthScreen';
import { ProfileView } from './components/ProfileView';
import { CompanyLogoModal } from './components/CompanyLogoModal';
import { CompanyNoticesView } from './components/CompanyNoticesView';
import { NoticeBanner } from './components/NoticeBanner';
import { UpdateShiftModal } from './components/UpdateShiftModal';
import { AdminView } from './components/AdminView';
import { LeaveRequestModal } from './components/LeaveRequestModal';
import { AttendanceDashboard } from './components/AttendanceDashboard';
import { PerformanceMetrics } from './components/PerformanceMetrics';
import { QRScannerModal } from './components/QRScannerModal';
import { QRGeneratorModal } from './components/QRGeneratorModal';
import { ChatAssistant } from './components/ChatAssistant';
import {  Task,
  ThemeMode,
  ViewFilter,
  NotificationLog,
  TaskPriority,
  Employee,
  ActivePage,
  CompanyNotice,
  TaskStatus,
  SubTask,
  CompanyShift,
  AttendanceLog,
  LeaveRequest,
  checkIsSuperAdmin
} from './types/task';
import {
  INITIAL_TASKS,
  INITIAL_EMPLOYEES,
  INITIAL_DEPARTMENTS,
  INITIAL_NOTICES,
  DEFAULT_COMPANY_LOGO,
  calculateDurationHours,
  formatTimeSlot
} from './data/initialTasks';
import { playChime, sendPushNotification } from './services/notificationService';
import { offlineSyncService } from './services/OfflineSyncService';
import { supabase } from './lib/supabase';
import { MapPinOff, Building2, Database, AlertTriangle, ExternalLink as LinkIcon, ShieldAlert, FileText } from 'lucide-react';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

export const DEFAULT_COMPANY_SHIFT: CompanyShift = {
  startTime12: '08:30 AM',
  endTime12: '08:30 PM',
  durationHours: 12.0,
  updatedBy: 'Sabyasachi (CEO)',
  updatedAt: new Date().toISOString(),
  notes: 'Official Mandi Operations & Floor Auction Roster (12-Hour Executive Timing)',
};

export default function App() {
  // 1. Theme State (Light / Dark / System)
  const [theme, setTheme] = useState<ThemeMode>(() => {
    const saved = localStorage.getItem('mandideals_theme');
    if (saved === 'light' || saved === 'dark' || saved === 'system') return saved;
    return 'system';
  });

  useEffect(() => {
    const root = document.documentElement;
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');

    const applyTheme = () => {
      const isDark =
        theme === 'dark' || (theme === 'system' && mediaQuery.matches);
      if (isDark) {
        root.classList.add('dark');
      } else {
        root.classList.remove('dark');
      }
    };

    applyTheme();
    localStorage.setItem('mandideals_theme', theme);

    const listener = () => {
      if (theme === 'system') applyTheme();
    };
    
    const visibilityListener = () => {
      if (document.visibilityState === 'visible') {
        loadAllData();
      }
    };

    mediaQuery.addEventListener('change', listener);
    document.addEventListener('visibilitychange', visibilityListener);
    
    return () => {
      mediaQuery.removeEventListener('change', listener);
      document.removeEventListener('visibilitychange', visibilityListener);
    };
  }, [theme]);

  // 2. Employees State (Includes Sabyasachi CEO & Super Admin)
  const [employees, setEmployees] = useState<Employee[]>(() => {
    return INITIAL_EMPLOYEES;
  });

  useEffect(() => {
    localStorage.setItem('mandideals_employees', JSON.stringify(employees));
  }, [employees]);

  // 3. Current Authenticated User (Defaults to Sabyasachi CEO on fresh session, can switch or log out)
  const [currentUser, setCurrentUser] = useState<Employee | null>(() => {
    try {
      const saved = localStorage.getItem('mandideals_current_user');
      if (saved) {
        const parsed = JSON.parse(saved);
        const isSuper = checkIsSuperAdmin(parsed);
        if (isSuper) {
          return { ...parsed, isSuperAdmin: true, accessLevel: 'SUPER_ADMIN' };
        }
        return parsed;
      }
    } catch (e) {
      console.error('Failed to parse current user', e);
    }
    return null; // Don't default to CEO anymore, force login or use saved
  });

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('mandideals_current_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('mandideals_current_user');
    }
  }, [currentUser]);

  // 4. Company Logo State (Customizable by CEO Super Admin)
  const [companyLogo, setCompanyLogo] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('mandideals_company_logo');
      if (saved !== null) return saved;
    } catch (e) {
      console.error('Failed to parse company logo', e);
    }
    return DEFAULT_COMPANY_LOGO;
  });

  useEffect(() => {
    localStorage.setItem('mandideals_company_logo', companyLogo);
  }, [companyLogo]);

  // 4b. Company Work Shift State (12-Hour Timing Updated by Sabyasachi)
  const [companyShift, setCompanyShift] = useState<CompanyShift>(() => {
    try {
      const saved = localStorage.getItem('mandideals_company_shift');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to parse company shift', e);
    }
    return DEFAULT_COMPANY_SHIFT;
  });

  useEffect(() => {
    localStorage.setItem('mandideals_company_shift', JSON.stringify(companyShift));
  }, [companyShift]);

  const [isUpdateShiftModalOpen, setIsUpdateShiftModalOpen] = useState(false);
  const [isLeaveModalOpen, setIsLeaveModalOpen] = useState(false);

  const handleSaveShift = (updated: CompanyShift) => {
    setCompanyShift(updated);
    // Broadcast an official executive notice to all staff
    const shiftNotice: CompanyNotice = {
      id: `notice-shift-${Date.now()}`,
      title: `⏰ Company Work Shift Updated by ${updated.updatedBy || 'Sabyasachi'}`,
      content: `Official Executive Notice: Work shift schedule is updated to 12-Hour Timing: ${updated.startTime12} – ${updated.endTime12} (${updated.durationHours} hrs). Effective immediately across all mandi operations, floor auctions, and tech rosters. Updated by Sabyasachi.`,
      authorName: updated.updatedBy || 'Sabyasachi',
      authorRole: 'CEO & Managing Director',
      priority: 'operational',
      createdAt: new Date().toISOString(),
      pinned: true,
    };
    setNotices((prev) => [shiftNotice, ...prev]);
    playChime('complete');
    sendPushNotification(
      'MANDIDEALS Shift Updated',
      `Work Shift updated by Sabyasachi: ${updated.startTime12} – ${updated.endTime12}`,
      'shift-update'
    );
  };

  // 5. Company Notices State (Broadcasted to all employees)
  const [notices, setNotices] = useState<CompanyNotice[]>(() => {
    try {
      const saved = localStorage.getItem('mandideals_notices');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to parse notices', e);
    }
    return INITIAL_NOTICES;
  });

  useEffect(() => {
    localStorage.setItem('mandideals_notices', JSON.stringify(notices));
  }, [notices]);

  // 6. Active Page & Profile Navigation
  const [activePage, setActivePage] = useState<ActivePage>('tasks');
  const [viewingEmployee, setViewingEmployee] = useState<Employee>(INITIAL_EMPLOYEES[0]);

  useEffect(() => {
    if (currentUser) {
       setViewingEmployee(currentUser);
    }
  }, [currentUser]);

  // 7. Departments State
  const [departments, setDepartments] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('mandideals_departments');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to parse departments', e);
    }
    return INITIAL_DEPARTMENTS;
  });

  useEffect(() => {
    localStorage.setItem('mandideals_departments', JSON.stringify(departments));
  }, [departments]);

  // 8. Tasks State (Employee Work Logs)
  const [tasks, setTasks] = useState<Task[]>(() => {
    try {
      const saved = localStorage.getItem('mandideals_tasks');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to parse tasks', e);
    }
    return INITIAL_TASKS;
  });

  useEffect(() => {
    localStorage.setItem('mandideals_tasks', JSON.stringify(tasks));
  }, [tasks]);

  // 9. Notifications State
  const [notifications, setNotifications] = useState<NotificationLog[]>(() => {
    try {
      const saved = localStorage.getItem('mandideals_notifications');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to parse notifications', e);
    }
    return [];
  });

  useEffect(() => {
    localStorage.setItem('mandideals_notifications', JSON.stringify(notifications));
  }, [notifications]);

  // 10. View & Filter States
  const [currentView, setCurrentView] = useState<ViewFilter>('all');
  const [selectedPriority, setSelectedPriority] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    if (isSidebarOpen && isMobile) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isSidebarOpen, isMobile]);

  // 11. Modal & Banner States
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [defaultTaskEmployee, setDefaultTaskEmployee] = useState<string | undefined>(undefined);
  const [activeReminderTask, setActiveReminderTask] = useState<Task | null>(null);
  const [isCompanyLogoModalOpen, setIsCompanyLogoModalOpen] = useState(false);
  const [shiftEndReminderTriggered, setShiftEndReminderTriggered] = useState<string | null>(null);
  const [isQRScannerOpen, setIsQRScannerOpen] = useState(false);
  const [isQRGeneratorOpen, setIsQRGeneratorOpen] = useState(false);
  const [qrAction, setQRAction] = useState<'punch-in' | 'punch-out'>('punch-in');
  const [qrRotationSeed, setQrRotationSeed] = useState<string>(() => {
    return localStorage.getItem('mandideals_qr_seed') || 'GMD-SEED-01';
  });
  const [qrLastRotated, setQrLastRotated] = useState<string>(() => {
    return localStorage.getItem('mandideals_qr_rotated') || new Date().toISOString();
  });

  // 12. Timed Reminder Checker (runs every 4 seconds)
  useEffect(() => {
    const checkReminders = () => {
      const now = new Date();
      const todayDateStr = now.toISOString().split('T')[0];

      // --- Task Reminders Logic ---
      setTasks((prevTasks) => {
        let hasChanges = false;
        const updatedTasks = prevTasks.map((task) => {
          if (
            !task.completed &&
            task.reminderTime &&
            !task.reminderTriggered
          ) {
            const remTime = new Date(task.reminderTime);
            if (remTime.getTime() <= now.getTime()) {
              hasChanges = true;

              const isUserTask =
                currentUser &&
                task.employeeName.toLowerCase() === currentUser.name.toLowerCase();
              const isSuperAdminUser =
                currentUser &&
                (currentUser.isSuperAdmin || currentUser.accessLevel === 'SUPER_ADMIN');

              if (isSuperAdminUser || isUserTask) {
                playChime('reminder');

                const timeSlot = formatTimeSlot(task.startTime, task.endTime);
                sendPushNotification(
                  `MANDIDEALS: ${task.employeeName}`,
                  `${task.title} (${timeSlot})`,
                  `mandideals-reminder-${task.id}`
                );

                setActiveReminderTask(task);
              }

              const timeSlot = formatTimeSlot(task.startTime, task.endTime);
              setNotifications((prevLogs) => [
                {
                  id: `notif-${Date.now()}`,
                  taskId: task.id,
                  taskTitle: task.title,
                  employeeName: task.employeeName,
                  message: `Shift task starting: ${task.title} (${timeSlot})`,
                  triggeredAt: new Date().toISOString(),
                  read: false,
                },
                ...prevLogs,
              ]);

              return { ...task, reminderTriggered: true };
            }
          }
          return task;
        });

        return hasChanges ? updatedTasks : prevTasks;
      });

      // --- Shift End Reminder Logic ---
      if (currentUser?.isPunchedIn && companyShift?.endTime12 && shiftEndReminderTriggered !== todayDateStr) {
        const [time, modifier] = companyShift.endTime12.split(' ');
        let [hours, minutes] = time.split(':').map(Number);
        if (modifier === 'PM' && hours < 12) hours += 12;
        if (modifier === 'AM' && hours === 12) hours = 0;
        
        const shiftEnd = new Date(now);
        shiftEnd.setHours(hours, minutes, 0, 0);
        
        const fifteenMinsBefore = new Date(shiftEnd.getTime() - 15 * 60 * 1000);
        
        // Trigger reminder 15 mins before shift end
        if (now.getTime() >= fifteenMinsBefore.getTime() && now.getTime() < shiftEnd.getTime()) {
          setShiftEndReminderTriggered(todayDateStr);
          playChime('reminder');
          sendPushNotification(
            'MANDIDEALS Shift End Reminder',
            `Executive Notice: Your shift officially ends at ${companyShift.endTime12} (in 15 minutes). Please ensure all deliverables are logged before punching out.`,
            'shift-end-reminder'
          );
          
          // Also add to in-app notifications
          setNotifications((prev) => [
            {
              id: `shift-end-${Date.now()}`,
              taskId: 'shift-reminder',
              taskTitle: 'Shift Ending Soon',
              employeeName: currentUser.name,
              message: `Your shift ends at ${companyShift.endTime12}. Remember to punch out for duration accuracy.`,
              triggeredAt: new Date().toISOString(),
              read: false,
            },
            ...prev
          ]);
        }
      }
    };

    checkReminders();
    const interval = setInterval(checkReminders, 4000);
    return () => clearInterval(interval);
  }, [currentUser, companyShift, shiftEndReminderTriggered]);

  // 13. Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      const isInput =
        target.tagName === 'INPUT' ||
        target.tagName === 'TEXTAREA' ||
        target.tagName === 'SELECT' ||
        target.isContentEditable;

      if (e.key === 'Escape') {
        setIsTaskModalOpen(false);
        setActiveReminderTask(null);
        setIsCompanyLogoModalOpen(false);
        return;
      }

      if (isInput) return;

      if (e.key.toLowerCase() === 'n') {
        e.preventDefault();
        setEditingTask(null);
        setDefaultTaskEmployee(currentUser?.name);
        setIsTaskModalOpen(true);
      } else if (e.key === '/') {
        e.preventDefault();
        const searchInput = document.querySelector('input[type="text"]') as HTMLInputElement;
        if (searchInput) searchInput.focus();
      } else if (e.key.toLowerCase() === 'd') {
        e.preventDefault();
        setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentUser]);

  // Security Guard: Non-super-admins cannot view other members' workspaces
  useEffect(() => {
    if (currentUser) {
      const isSuper = Boolean(
        currentUser.isSuperAdmin || currentUser.accessLevel === 'SUPER_ADMIN'
      );
      if (!isSuper && currentView.startsWith('emp:')) {
        const targetEmp = currentView.replace('emp:', '');
        if (targetEmp.toLowerCase() !== currentUser.name.toLowerCase()) {
          setCurrentView('all');
        }
      }
    }
  }, [currentUser, currentView]);

  // Auth Handlers
  const handleLogin = async (email: string, password?: string) => {
    try {
      let matchedEmployee: Employee | null = null;

      // 1. Try to fetch from Supabase first for real-time auth status
      try {
        const { data: matched, error } = await supabase
          .from('employees')
          .select('*')
          .eq('email', email.toLowerCase())
          .single();

        if (matched && !error) {
          matchedEmployee = {
            ...matched,
            accessLevel: matched.accesslevel || matched.accessLevel || 'STAFF',
            isSuperAdmin: matched.issuperadmin !== undefined ? matched.issuperadmin : matched.isSuperAdmin,
            isAuthorized: matched.isauthorized !== undefined ? matched.isauthorized : matched.isAuthorized,
            isPunchedIn: matched.ispunchedin !== undefined ? matched.ispunchedin : matched.isPunchedIn,
            joinedDate: matched.joineddate || matched.joinedDate,
            createdAt: matched.createdat || matched.createdAt
          };
        }
      } catch (e) {
        console.warn('Supabase Login Fetch Error (Fallback to Local):', e);
      }

      // 2. If not found in Supabase or fetch failed, check local state
      if (!matchedEmployee) {
        const localMatched = employees.find(e => e.email.toLowerCase() === email.toLowerCase());
        if (localMatched) {
          matchedEmployee = localMatched;
        }
      }

      if (!matchedEmployee) {
        throw new Error('Staff account not found. Please check spelling or register.');
      }

      // 3. Robust Super Admin Detection
      const isSuper = Boolean(
        matchedEmployee.isSuperAdmin ||
        matchedEmployee.accessLevel === 'SUPER_ADMIN' ||
        matchedEmployee.email.toLowerCase() === 'sabya@mandideals.com' ||
        matchedEmployee.email.toLowerCase() === 'sabyasachi.baral@mandideals.com'
      );
      
      if (isSuper) {
        matchedEmployee = { ...matchedEmployee, isSuperAdmin: true, accessLevel: 'SUPER_ADMIN' };
      }

      // 4. Verify Password
      if (password && matchedEmployee.password && matchedEmployee.password !== password) {
        throw new Error('Invalid password. Please verify credentials.');
      }

      if (matchedEmployee.isAuthorized === false) {
        throw new Error('Your account is pending authorization by the Super Admin (Sabyasachi).');
      }

      // Success
      setCurrentUser(matchedEmployee);
      setViewingEmployee(matchedEmployee);
      setActivePage('tasks');
      
      // Force immediate sync from Supabase after successful login
      loadAllData();
      
      // Request notification permission
      if (typeof Notification !== 'undefined' && Notification.permission === 'default') {
        Notification.requestPermission();
      }

      // Try to update status in Supabase if possible
      try {
        await supabase.from('employees').update({ status: 'Active' }).eq('email', matchedEmployee.email.toLowerCase());
      } catch (e) {
        // Ignore background sync errors
      }
    } catch (err: any) {
      console.error('Login Error:', err);
      throw err; // AuthScreen will catch this and show errorMsg
    }
  };

  const handleRegister = async (newEmp: Employee) => {
    try {
      // 1. Save to Supabase immediately
      // We explicitly map only the lowercase fields to ensure compatibility with Supabase schema cache
      const dbPayload = {
        id: newEmp.id,
        name: newEmp.name,
        email: newEmp.email.toLowerCase(),
        password: newEmp.password,
        role: newEmp.role,
        department: newEmp.department,
        phone: newEmp.phone,
        location: newEmp.location,
        avatar: newEmp.avatar,
        status: newEmp.status,
        bio: newEmp.bio,
        accesslevel: newEmp.accessLevel,
        issuperadmin: newEmp.isSuperAdmin,
        isauthorized: newEmp.isAuthorized,
        ispunchedin: newEmp.isPunchedIn,
        joineddate: newEmp.joinedDate
      };
      
      const { error } = await supabase.from('employees').insert(dbPayload);
      if (error) throw error;

      // 2. Update local state
      const updatedEmployees = [...employees, newEmp];
      setEmployees(updatedEmployees);
      
      playChime('complete');
      sendPushNotification('MANDIDEALS: New Registration', `${newEmp.name} registered for approval.`, 'new-reg');
    } catch (err: any) {
      console.error('Registration Sync Error:', err);
      if (err.message && (err.message.includes('accessLevel') || err.message.includes('accesslevel'))) {
        setDbError('SCHEMA_MISMATCH');
      } else {
        alert('Registration failed to sync with the server. Please check your connection or database schema.');
      }
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
  };

  const handleResetPassword = async (email: string, newPassword: string) => {
    try {
      const { error } = await supabase
        .from('employees')
        .update({ password: newPassword })
        .eq('email', email.toLowerCase());

      if (error && !error.message.includes('Could not find the table')) {
        throw error;
      }

      setEmployees(prev => prev.map(e => e.email.toLowerCase() === email.toLowerCase() ? { ...e, password: newPassword } : e));
      playChime('complete');
    } catch (err) {
      console.error('Password reset sync error:', err);
      // Fallback update local state anyway
      setEmployees(prev => prev.map(e => e.email.toLowerCase() === email.toLowerCase() ? { ...e, password: newPassword } : e));
    }
  };

  const [attendanceLogs, setAttendanceLogs] = useState<AttendanceLog[]>([]);

  useEffect(() => {
    if (attendanceLogs.length > 0) {
      localStorage.setItem('mandideals_attendance', JSON.stringify(attendanceLogs));
    }
  }, [attendanceLogs]);

  const [leaveRequests, setLeaveRequests] = useState<LeaveRequest[]>([]);

  useEffect(() => {
    if (leaveRequests.length > 0) {
      localStorage.setItem('mandideals_leave_requests', JSON.stringify(leaveRequests));
    }
  }, [leaveRequests]);

  // --- SUPABASE SYNC LOGIC ---
  const [isSyncing, setIsSyncing] = useState(true);
  const [syncQueueLength, setSyncQueueLength] = useState(0);
  const [syncError, setSyncError] = useState<string | null>(null);
  const [dbError, setDbError] = useState<'NONE' | 'DATABASE_TABLES_MISSING' | 'SCHEMA_MISMATCH'>('NONE');

  useEffect(() => {
    const unsubLength = offlineSyncService.subscribe(setSyncQueueLength);
    const unsubError = offlineSyncService.subscribeToErrors(setSyncError);
    return () => {
      unsubLength();
      unsubError();
    };
  }, []);

  // Helper to sanitize any employee object for Supabase (forcing lowercase keys)
  const sanitizeEmployeeForDB = (emp: Employee) => ({
    id: emp.id,
    name: emp.name,
    email: emp.email.toLowerCase(),
    password: emp.password,
    role: emp.role,
    department: emp.department,
    phone: emp.phone,
    location: emp.location,
    avatar: emp.avatar,
    status: emp.status,
    bio: emp.bio,
    accesslevel: emp.accessLevel,
    issuperadmin: emp.isSuperAdmin,
    isauthorized: emp.isAuthorized,
    ispunchedin: emp.isPunchedIn,
    joineddate: emp.joinedDate
  });

  // Helper to sanitize any task object for Supabase
  function sanitizeTaskForDB(task: Task) {
    const payload: any = {
      id: task.id,
      title: task.title,
      description: task.description,
      employeename: task.employeeName,
      employeerole: task.employeeRole,
      department: task.department,
      starttime: task.startTime,
      endtime: task.endTime,
      durationhours: task.durationHours,
      completed: task.completed,
      status: task.status,
      completedat: task.completedAt,
      createdat: task.createdAt,
      remindertime: task.reminderTime,
      remindertriggered: task.reminderTriggered,
      priority: task.priority
    };

    // Only include these if they have values to avoid schema errors if columns are missing
    if (task.dueDate) payload.duedate = task.dueDate;
    if (task.rating !== undefined && task.rating !== null) payload.rating = task.rating;
    if (task.subtasks && task.subtasks.length > 0) payload.subtasks = task.subtasks;
    if (task.comments && task.comments.length > 0) payload.comments = task.comments;

    return payload;
  }

  async function loadAllData() {
    try {
      const [
        { data: dbEmployees, error: errEmp },
        { data: dbTasks, error: errTasks },
        { data: dbLogs, error: errLogs },
        { data: dbNotices, error: errNotices },
        { data: dbLeaves, error: errLeaves },
        { data: dbNotifs, error: errNotifs },
        { data: dbSettings, error: errSettings }
      ] = await Promise.all([
        supabase.from('employees').select('*'),
        supabase.from('tasks').select('*'),
        supabase.from('attendance_logs').select('*'),
        supabase.from('company_notices').select('*'),
        supabase.from('leave_requests').select('*'),
        supabase.from('notifications').select('*'),
        supabase.from('company_settings').select('*')
      ]);

      if (errTasks) console.error('Error fetching tasks:', errTasks);
      if (errLogs) console.error('Error fetching attendance logs:', errLogs);
      if (errNotices) console.error('Error fetching notices:', errNotices);
      if (errLeaves) console.error('Error fetching leave requests:', errLeaves);
      if (errNotifs) console.error('Error fetching notifications:', errNotifs);
      if (errSettings) console.error('Error fetching settings:', errSettings);

      if (errEmp) {
        console.error('Error fetching employees:', errEmp);
        if (errEmp.message.includes('Could not find the table')) {
           setDbError('DATABASE_TABLES_MISSING');
           return;
        }
      }

      // If table exists but has 0 rows, it means seeding hasn't happened
      if (dbEmployees && dbEmployees.length === 0) {
        setDbError('DATABASE_TABLES_MISSING');
        return;
      }

      if (dbEmployees && dbEmployees.length > 0) {
        // Normalize casing from DB to App (e.g. accesslevel -> accessLevel)
        const normalized = dbEmployees
          .filter((emp: any) => emp.name !== 'Pooja Sharma') // Remove demo user
          .map((emp: any) => ({
          id: emp.id,
          name: emp.name,
          email: emp.email,
          password: emp.password,
          role: emp.role,
          department: emp.department,
          phone: emp.phone,
          location: emp.location,
          avatar: emp.avatar,
          status: emp.status,
          bio: emp.bio,
          accessLevel: emp.accesslevel || emp.accessLevel || 'STAFF',
          isSuperAdmin: emp.issuperadmin !== undefined ? emp.issuperadmin : emp.isSuperAdmin,
          isAuthorized: emp.isauthorized !== undefined ? emp.isauthorized : emp.isAuthorized,
          isPunchedIn: emp.ispunchedin !== undefined ? emp.ispunchedin : emp.isPunchedIn,
          joinedDate: emp.joineddate || emp.joinedDate,
          createdAt: emp.createdat || emp.createdAt
        })) as Employee[];

        // MERGE STRATEGY: Ensure INITIAL_EMPLOYEES are included if missing in DB
        const mergedEmployees = [...normalized];
        INITIAL_EMPLOYEES.forEach(initial => {
          const exists = mergedEmployees.find(m => m.email.toLowerCase() === initial.email.toLowerCase());
          if (!exists) {
            mergedEmployees.push(initial);
          }
        });

        setEmployees(mergedEmployees);
      }
      
      // Normalize Tasks
      if (dbTasks) {
        const normalizedTasks = dbTasks.map((t: any) => ({
          id: t.id,
          title: t.title,
          description: t.description,
          employeeName: t.employeename || t.employeeName,
          employeeRole: t.employeerole || t.employeeRole,
          department: t.department,
          startTime: t.starttime || t.startTime,
          endTime: t.endtime || t.endTime,
          durationHours: t.durationhours || t.durationHours,
          completed: t.completed,
          status: t.status || (t.completed ? 'completed' : 'todo'),
          completedAt: t.completedat || t.completedAt,
          createdAt: t.createdat || t.createdAt,
          dueDate: t.duedate || t.dueDate,
          reminderTime: t.remindertime || t.reminderTime,
          reminderTriggered: t.remindertriggered || t.reminderTriggered,
          priority: t.priority,
          rating: t.rating,
          subtasks: t.subtasks || [],
          comments: t.comments || []
        })) as Task[];
        
        setTasks(prev => {
          const merged = [...normalizedTasks];
          prev.forEach(p => {
            if (!merged.find(m => m.id === p.id)) {
              // If it's a new local task not yet in DB, keep it
              if (String(p.id).startsWith('task-')) {
                merged.push(p);
              }
            }
          });
          return merged;
        });
      }

      if (dbLogs) {
        const normalizedLogs = dbLogs.map((l: any) => ({
          id: l.id,
          employeeId: l.employeeid || l.employeeId,
          employeeName: l.employeename || l.employeeName,
          punchIn: l.punchin || l.punchIn,
          punchOut: l.punchout || l.punchOut,
          date: l.date,
          punchInLat: l.punchinlat || l.punchInLat,
          punchInLng: l.punchinlng || l.punchInLng,
          punchOutLat: l.punchoutlat || l.punchOutLat,
          punchOutLng: l.punchoutlng || l.punchOutLng,
          isLate: l.islate || l.isLate,
          createdAt: l.createdat || l.createdAt
        })) as AttendanceLog[];
        
        setAttendanceLogs(prev => {
          const merged = [...normalizedLogs];
          prev.forEach(p => {
            if (!merged.find(m => m.id === p.id)) {
              // Keep local punches not yet synced
              if (String(p.id).startsWith('punch-')) {
                merged.push(p);
              }
            }
          });
          return merged;
        });
      }

      if (dbNotices) {
        const normalizedNotices = dbNotices.map((n: any) => ({
          id: n.id,
          title: n.title,
          content: n.content,
          authorName: n.authorname || n.authorName,
          authorRole: n.authorrole || n.authorRole,
          priority: n.priority,
          createdAt: n.createdat || n.createdAt,
          pinned: n.pinned
        })) as CompanyNotice[];
        setNotices(normalizedNotices);
      }

      if (dbLeaves) {
        const normalizedLeaves = dbLeaves.map((r: any) => ({
          id: r.id,
          employeeId: r.employeeid || r.employeeId,
          employeeName: r.employeename || r.employeeName,
          startDate: r.startdate || r.startDate,
          endDate: r.enddate || r.endDate,
          reason: r.reason,
          status: r.status,
          createdAt: r.createdat || r.createdAt
        })) as LeaveRequest[];
        setLeaveRequests(normalizedLeaves);
      }

      if (dbNotifs) {
        const normalizedNotifs = dbNotifs.map((n: any) => ({
          id: n.id,
          taskId: n.taskid || n.taskId,
          taskTitle: n.tasktitle || n.taskTitle,
          employeeName: n.employeename || n.employeeName,
          message: n.message,
          triggeredAt: n.triggeredat || n.triggeredAt,
          read: n.read
        })) as NotificationLog[];
        setNotifications(normalizedNotifs);
      }
      
      if (dbSettings) {
        const shift = dbSettings.find(s => s.key === 'company_shift')?.value;
        if (shift) setCompanyShift(shift);
        
        const depts = dbSettings.find(s => s.key === 'departments')?.value;
        if (depts) setDepartments(depts);

        const logo = dbSettings.find(s => s.key === 'company_logo')?.value;
        if (logo) setCompanyLogo(logo);

        const qrSeed = dbSettings.find(s => s.key === 'qr_rotation_seed')?.value;
        if (qrSeed) {
          setQrRotationSeed(qrSeed);
          localStorage.setItem('mandideals_qr_seed', qrSeed);
        }

        const lastRotated = dbSettings.find(s => s.key === 'qr_last_rotated')?.value;
        if (lastRotated) {
          setQrLastRotated(lastRotated);
          localStorage.setItem('mandideals_qr_rotated', lastRotated);
        }
      }
    } catch (err) {
      console.error('Supabase Sync Error:', err);
    } finally {
      setIsSyncing(false);
    }
  };

  // Initial Data Load from Supabase
  useEffect(() => {
    loadAllData();

    // --- REALTIME SUBSCRIPTIONS ---
    const empSub = supabase.channel('employees_realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'employees' }, payload => {
        const item = payload.new as any;
        if (item) {
          const norm: Employee = {
            id: item.id,
            name: item.name,
            email: item.email,
            password: item.password,
            role: item.role,
            department: item.department,
            phone: item.phone,
            location: item.location,
            avatar: item.avatar,
            status: item.status,
            bio: item.bio,
            accessLevel: item.accesslevel || item.accessLevel || 'STAFF',
            isSuperAdmin: item.issuperadmin !== undefined ? item.issuperadmin : item.isSuperAdmin,
            isAuthorized: item.isauthorized !== undefined ? item.isauthorized : item.isAuthorized,
            isPunchedIn: item.ispunchedin !== undefined ? item.ispunchedin : item.isPunchedIn,
            joinedDate: item.joineddate || item.joinedDate,
            createdAt: item.createdat || item.createdAt
          };
          setEmployees(prev => {
            const exists = prev.find(e => e.id === norm.id);
            if (exists) return prev.map(e => e.id === norm.id ? norm : e);
            return [...prev, norm];
          });
        }
      })
      .subscribe((status) => {
        if (status === 'CHANNEL_ERROR') {
          console.warn('Realtime channel error (employees). Retrying...');
        }
      });

    const taskSub = supabase.channel('tasks_realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'tasks' }, payload => {
        if (payload.eventType === 'DELETE') {
          const oldId = payload.old.id;
          setTasks(prev => prev.filter(t => t.id !== oldId));
          return;
        }

        const t = payload.new as any;
        if (t) {
          const norm: Task = {
            id: t.id,
            title: t.title,
            description: t.description,
            employeeName: t.employeename || t.employeeName,
            employeeRole: t.employeerole || t.employeeRole,
            department: t.department,
            startTime: t.starttime || t.startTime,
            endTime: t.endtime || t.endTime,
            durationHours: t.durationhours || t.durationHours,
            completed: t.completed,
            status: t.status || (t.completed ? 'completed' : 'todo'),
            completedAt: t.completedat || t.completedAt,
            createdAt: t.createdat || t.createdAt,
            dueDate: t.duedate || t.dueDate,
            reminderTime: t.remindertime || t.reminderTime,
            reminderTriggered: t.remindertriggered || t.reminderTriggered,
            priority: t.priority,
            rating: t.rating,
            subtasks: t.subtasks || [],
            comments: t.comments || []
          };
          setTasks(prev => {
            const exists = prev.find(item => item.id === norm.id);
            if (exists) return prev.map(item => item.id === norm.id ? norm : item);
            return [...prev, norm];
          });
        }
      })
      .subscribe((status) => {
        if (status === 'CHANNEL_ERROR') {
          console.warn('Realtime channel error (tasks). Retrying...');
        }
      });

    const logSub = supabase.channel('logs_realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'attendance_logs' }, payload => {
        if (payload.eventType === 'DELETE') {
          const oldId = payload.old.id;
          setAttendanceLogs(prev => prev.filter(l => l.id !== oldId));
          return;
        }

        const l = payload.new as any;
        if (l) {
          const norm: AttendanceLog = {
            id: l.id,
            employeeId: l.employeeid || l.employeeId,
            employeeName: l.employeename || l.employeeName,
            punchIn: l.punchin || l.punchIn,
            punchOut: l.punchout || l.punchOut,
            date: l.date,
            punchInLat: l.punchinlat || l.punchInLat,
            punchInLng: l.punchinlng || l.punchInLng,
            punchOutLat: l.punchoutlat || l.punchOutLat,
            punchOutLng: l.punchoutlng || l.punchOutLng,
            createdAt: l.createdat || l.createdAt,
            isLate: l.islate || l.isLate
          };
          setAttendanceLogs(prev => {
            const exists = prev.find(item => item.id === norm.id);
            if (exists) return prev.map(item => item.id === norm.id ? norm : item);
            return [...prev, norm];
          });
        }
      })
      .subscribe((status) => {
        if (status === 'CHANNEL_ERROR') {
          console.warn('Realtime channel error (logs). Retrying...');
        }
      });

    return () => {
      empSub.unsubscribe();
      taskSub.unsubscribe();
      logSub.unsubscribe();
    };
  }, []);

  // Sync state changes to Supabase (Optimistic UI style - we just push updates)
  // We only sync small settings this way. Large collections like tasks/attendance 
  // are synced directly in handlers to avoid mass-overwrites and data loss.
  useEffect(() => {
    if (!isSyncing) {
      supabase.from('company_settings').upsert({ key: 'company_shift', value: companyShift }).then();
    }
  }, [companyShift, isSyncing]);

  useEffect(() => {
    if (!isSyncing) {
      supabase.from('company_settings').upsert({ key: 'company_logo', value: companyLogo }).then();
    }
  }, [companyLogo, isSyncing]);

  useEffect(() => {
    if (!isSyncing) {
      const dbPayload = notices.map(n => ({
        id: n.id,
        title: n.title,
        content: n.content,
        authorname: n.authorName,
        authorrole: n.authorRole,
        priority: n.priority,
        createdat: n.createdAt,
        pinned: n.pinned
      }));
      supabase.from('company_notices').upsert(dbPayload).then();
    }
  }, [notices, isSyncing]);

  const handlePunchIn = (manualLat?: number, manualLng?: number) => {
    if (!currentUser) return;
    
    const recordPunchIn = (lat: number, lng: number) => {
      const now = new Date();
      const nowStr = now.toISOString();
      const dateStr = nowStr.split('T')[0];

      // Check if late based on companyShift
      let isLate = false;
      if (companyShift && companyShift.startTime12) {
        const [time, modifier] = companyShift.startTime12.split(' ');
        let [hours, minutes] = time.split(':').map(Number);
        if (modifier === 'PM' && hours < 12) hours += 12;
        if (modifier === 'AM' && hours === 12) hours = 0;
        
        const shiftStart = new Date(now);
        shiftStart.setHours(hours, minutes, 0, 0);
        
        // Add 5-minute grace period
        if (now.getTime() > (shiftStart.getTime() + 5 * 60 * 1000)) {
          isLate = true;
        }
      }

      const newLog: AttendanceLog = {
        id: `punch-${Date.now()}`,
        employeeId: currentUser.id,
        employeeName: currentUser.name,
        punchIn: nowStr,
        date: dateStr,
        punchInLat: lat,
        punchInLng: lng,
        isLate: isLate
      };
      setAttendanceLogs((prev) => [...prev, newLog]);
      setCurrentUser({ ...currentUser, isPunchedIn: true });
      setEmployees((prev) => prev.map(e => e.id === currentUser.id ? { ...e, isPunchedIn: true, status: 'On Shift' } : e));
      
      // Sync individually to DB via OfflineSyncService
      offlineSyncService.queueAction({
        table: 'attendance_logs',
        type: 'upsert',
        data: {
          id: newLog.id,
          employeeid: newLog.employeeId,
          employeename: newLog.employeeName,
          punchin: newLog.punchIn,
          date: newLog.date,
          punchinlat: newLog.punchInLat,
          punchinlng: newLog.punchInLng,
          islate: newLog.isLate,
          createdat: new Date().toISOString()
        }
      });

      offlineSyncService.queueAction({
        table: 'employees',
        type: 'update',
        data: { ispunchedin: true, status: 'On Shift' },
        filter: { column: 'id', value: currentUser.id }
      });

      playChime(isLate ? 'alert' : 'complete');

      // Success Notification for user
      if (isLate) {
        alert("⚠️ MANDIDEALS ATTENDANCE NOTICE: You have joined the shift LATE. This incident has been logged for executive review by Sabyasachi Baral (CEO).");
      }

      sendPushNotification(
        isLate ? 'MANDIDEALS: LATE PUNCH' : 'MANDIDEALS Attendance Success',
        isLate 
          ? `Joined LATE at ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}. Executive review triggered.`
          : `Punched IN at ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}. Location: ${lat.toFixed(4)}, ${lng.toFixed(4)}`,
        'punch-success'
      );
    };

    if (manualLat !== undefined && manualLng !== undefined) {
      recordPunchIn(manualLat, manualLng);
      return;
    }

    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => recordPunchIn(position.coords.latitude, position.coords.longitude),
        (error) => {
          if (error.message.toLowerCase().includes('permissions policy') || error.code === 1) {
            console.warn("Geolocation blocked by policy or user. Using manual override.");
            alert("MANDIDEALS NOTICE: Location services are restricted by your browser policy. Attendance will be marked with approximate complex coordinates.");
            recordPunchIn(0, 0);
            return;
          }
          console.warn("Geolocation high-accuracy failed, falling back", error);
          // Fallback to low accuracy and longer timeout
          navigator.geolocation.getCurrentPosition(
            (pos) => recordPunchIn(pos.coords.latitude, pos.coords.longitude),
            (err) => {
              console.warn("Geolocation failed completely, using fallback (0,0)", err.code, err.message);
              // Final fallback: Allow punch with 0,0 but warn
              alert("WARNING: Precise location could not be determined. Using approximate city-level data. Please ensure you are at the Mandi Complex.");
              recordPunchIn(0, 0);
            },
            { timeout: 10000, enableHighAccuracy: false, maximumAge: 120000 }
          );
        },
        { 
          timeout: 12000,
          enableHighAccuracy: true, 
          maximumAge: 60000
        }
      );
    } else {
      console.warn("Geolocation not supported. Recording fallback coordinates.");
      alert("WARNING: Your browser does not support Geolocation. Attendance will be marked with default coordinates (0,0).");
      recordPunchIn(0, 0);
    }
  };

  const handlePunchOut = (manualLat?: number, manualLng?: number) => {
    if (!currentUser) return;

    const recordPunchOut = (lat: number, lng: number) => {
      const nowStr = new Date().toISOString();
      setAttendanceLogs((prev) => 
        prev.map(log => {
          if (log.employeeId === currentUser.id && !log.punchOut) {
            // Update individual log in Supabase via OfflineSyncService
            offlineSyncService.queueAction({
              table: 'attendance_logs',
              type: 'update',
              data: {
                punchout: nowStr,
                punchoutlat: lat,
                punchoutlng: lng
              },
              filter: { column: 'id', value: log.id }
            });

            return { 
              ...log, 
              punchOut: nowStr,
              punchOutLat: lat,
              punchOutLng: lng
            };
          }
          return log;
        })
      );
      setCurrentUser({ ...currentUser, isPunchedIn: false });
      setEmployees((prev) => prev.map(e => e.id === currentUser.id ? { ...e, isPunchedIn: false, status: 'Active' } : e));
      
      // Update employee status in Supabase via OfflineSyncService
      offlineSyncService.queueAction({
        table: 'employees',
        type: 'update',
        data: { ispunchedin: false, status: 'Active' },
        filter: { column: 'id', value: currentUser.id }
      });
      
      playChime('complete');

      // Success Notification for user
      sendPushNotification(
        'MANDIDEALS Attendance Success',
        `Punched OUT at ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}. Shift data saved.`,
        'punch-success'
      );
    };

    if (manualLat !== undefined && manualLng !== undefined) {
      recordPunchOut(manualLat, manualLng);
      return;
    }

    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => recordPunchOut(position.coords.latitude, position.coords.longitude),
        (error) => {
          if (error.message.toLowerCase().includes('permissions policy') || error.code === 1) {
             console.warn("Geolocation blocked by policy or user. Using manual override.");
             recordPunchOut(0, 0);
             return;
          }
          console.warn("Geolocation high-accuracy failed, falling back", error);
          // Fallback to low accuracy and longer timeout
          navigator.geolocation.getCurrentPosition(
            (pos) => recordPunchOut(pos.coords.latitude, pos.coords.longitude),
            (err) => {
              console.warn("Geolocation failed completely during punch-out, using fallback (0,0)", err.code, err.message);
              alert("WARNING: Precise location could not be determined. Finalizing shift with approximate data.");
              recordPunchOut(0, 0);
            },
            { timeout: 10000, enableHighAccuracy: false, maximumAge: 120000 }
          );
        },
        { 
          timeout: 12000,
          enableHighAccuracy: true,
          maximumAge: 60000
        }
      );
    } else {
      console.warn("Geolocation not supported during punch-out. Recording fallback coordinates.");
      alert("WARNING: Your browser does not support Geolocation. Shift will be finalized with default coordinates (0,0).");
      recordPunchOut(0, 0);
    }
  };

  const handleRequestLeave = (startDate: string, endDate: string, reason: string) => {
    if (!currentUser) return;
    const newRequest: LeaveRequest = {
      id: `leave-${Date.now()}`,
      employeeId: currentUser.id,
      employeeName: currentUser.name,
      startDate,
      endDate,
      reason,
      status: 'pending',
      createdAt: new Date().toISOString(),
    };
    setLeaveRequests((prev) => [...prev, newRequest]);
    
    // Sync to DB
    supabase.from('leave_requests').insert({
      id: newRequest.id,
      employeeid: newRequest.employeeId,
      employeename: newRequest.employeeName,
      startdate: newRequest.startDate,
      enddate: newRequest.endDate,
      reason: newRequest.reason,
      status: newRequest.status,
      createdat: newRequest.createdAt
    }).then();

    playChime('complete');
  };

  const handleToggleAuthorization = (id: string, isAuthorized: boolean) => {
    setEmployees((prev) => prev.map(e => e.id === id ? { ...e, isAuthorized } : e));
    supabase.from('employees').update({ isauthorized: isAuthorized }).eq('id', id).then();
    playChime('complete');
  };

  const handleUpdateAccessLevel = (id: string, level: Employee['accessLevel']) => {
    if (!currentUser) return;
    
    // Prevent demoting self (Sabyasachi)
    if (id === currentUser.id && level !== 'SUPER_ADMIN') {
      alert("Executive Protection: Super Admin authority cannot be demoted.");
      return;
    }

    const isSuperAdmin = level === 'SUPER_ADMIN';
    setEmployees((prev) => prev.map(e => e.id === id ? { ...e, accessLevel: level, isSuperAdmin } : e));
    supabase.from('employees').update({ accesslevel: level, issuperadmin: isSuperAdmin }).eq('id', id).then();
    playChime('complete');
  };

  const handleUpdateLeaveStatus = (id: string, status: 'approved' | 'rejected') => {
    setLeaveRequests((prev) => prev.map(r => r.id === id ? { ...r, status } : r));
    supabase.from('leave_requests').update({ status }).eq('id', id).then();
    playChime('complete');
  };
  const handleUpdateEmployee = (updated: Employee) => {
    setEmployees((prev) =>
      prev.map((emp) => (emp.id === updated.id ? updated : emp))
    );
    supabase.from('employees').upsert(sanitizeEmployeeForDB(updated)).then();

    if (currentUser && currentUser.id === updated.id) {
      setCurrentUser(updated);
    }
    if (viewingEmployee.id === updated.id) {
      setViewingEmployee(updated);
    }
  };

  const handleAddEmployee = (empData: Partial<Employee>) => {
    const newEmp: Employee = {
      id: `emp-${Date.now()}`,
      name: empData.name || 'New Staff',
      role: empData.role || 'Operations Specialist',
      department: empData.department || departments[0],
      email: empData.email || `${(empData.name || 'staff').toLowerCase().replace(/\s+/g, '.')}@mandideals.com`,
      password: empData.password || 'ChangeMe@123',
      joinedDate: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }).replace(/ /g, '-'),
      shift: '08:30 AM – 08:30 PM',
      accessLevel: empData.accessLevel || 'STAFF',
      isSuperAdmin: empData.accessLevel === 'SUPER_ADMIN',
      status: 'Active',
      isAuthorized: true,
      location: 'Central Mandi Complex',
      bio: empData.bio || `MANDIDEALS staff member in the ${empData.department || 'Operations'} department.`,
    };
    setEmployees(prev => [...prev, newEmp]);
    supabase.from('employees').insert(sanitizeEmployeeForDB(newEmp)).then();
    playChime('complete');
  };

  const handleDeleteEmployee = (id: string) => {
    if (currentUser && id === currentUser.id) {
      alert("Executive Protection: You cannot delete your own Super Admin account.");
      return;
    }
    setEmployees(prev => prev.filter(e => e.id !== id));
    supabase.from('employees').delete().eq('id', id).then();
    playChime('alert');
  };

  // Open profile for a specific employee (Non-super-admin can only access their own workspace profile)
  const handleOpenProfileForEmployee = (emp: Employee) => {
    const isSuperAdminUser = Boolean(
      currentUser?.isSuperAdmin || currentUser?.accessLevel === 'SUPER_ADMIN'
    );
    if (!isSuperAdminUser && currentUser) {
      setViewingEmployee(currentUser);
    } else {
      setViewingEmployee(emp);
    }
    setActivePage('profile');
  };

  // Company Logo Handler (CEO Super Admin only)
  const handleSaveCompanyLogo = (newLogoUrl: string) => {
    setCompanyLogo(newLogoUrl);
    supabase.from('company_settings').upsert({ key: 'company_logo', value: newLogoUrl }).then();
    playChime('complete');
  };

  // Notices Handlers (Super Admin can add, edit, and delete notices)
  const handleAddNotice = (noticeData: Omit<CompanyNotice, 'id' | 'createdAt'>) => {
    const newNotice: CompanyNotice = {
      id: `notice-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      createdAt: new Date().toISOString(),
      ...noticeData,
    };
    setNotices((prev) => [newNotice, ...prev]);
    
    supabase.from('company_notices').insert({
      id: newNotice.id,
      title: newNotice.title,
      content: newNotice.content,
      authorname: newNotice.authorName,
      authorrole: newNotice.authorRole,
      priority: newNotice.priority,
      createdat: newNotice.createdAt,
      pinned: newNotice.pinned
    }).then();

    playChime('reminder');
    sendPushNotification(
      `📢 MANDIDEALS Notice: ${newNotice.title}`,
      newNotice.content.slice(0, 100),
      `notice-${newNotice.id}`
    );
  };

  const handleEditNotice = (
    id: string,
    updatedData: Partial<Omit<CompanyNotice, 'id' | 'createdAt'>>
  ) => {
    setNotices((prev) =>
      prev.map((n) => {
        if (n.id === id) {
          const updated = { ...n, ...updatedData };
          supabase.from('company_notices').update({
            title: updated.title,
            content: updated.content,
            authorname: updated.authorName,
            authorrole: updated.authorRole,
            priority: updated.priority,
            pinned: updated.pinned
          }).eq('id', id).then();
          return updated;
        }
        return n;
      })
    );
    playChime('complete');
    sendPushNotification(
      'MANDIDEALS Executive Notice',
      `Notice updated: ${updatedData.title || 'Check Notice Board'}`,
      `notice-update-${id}`
    );
  };

  const handleDeleteNotice = (id: string) => {
    setNotices((prev) => prev.filter((n) => n.id !== id));
    supabase.from('company_notices').delete().eq('id', id).then();
    playChime('alert');
  };

  const handleInitiateDisciplinaryNote = (employeeName: string, lateCount: number) => {
    if (!currentUser) return;
    const disciplinaryNotice: Omit<CompanyNotice, 'id' | 'createdAt'> = {
      title: `⚠️ PROTOCOL VIOLATION: ${employeeName}`,
      content: `Executive Audit Flag: Employee ${employeeName} has recorded ${lateCount} LATE arrivals this month, exceeding the maximum allowed threshold of 3. This is a formal disciplinary log regarding shift protocol compliance. Punctuality is critical for MANDIDEALS complex operations.`,
      authorName: currentUser.name,
      authorRole: 'CEO & Master Admin',
      priority: 'urgent',
      pinned: true,
    };
    handleAddNotice(disciplinaryNotice);
    setActivePage('notices');
    playChime('alert');
    alert(`Disciplinary protocol initiated. Formal notice for ${employeeName} has been posted to the Executive Board.`);
  };

  const handleUpdateAttendanceLog = (updatedLog: AttendanceLog) => {
    setAttendanceLogs((prev) =>
      prev.map((log) => (log.id === updatedLog.id ? updatedLog : log))
    );
    // Sync to Supabase
    supabase.from('attendance_logs').update({
      punchin: updatedLog.punchIn,
      punchout: updatedLog.punchOut,
      date: updatedLog.date,
      islate: updatedLog.isLate,
      punchinlat: updatedLog.punchInLat,
      punchinlng: updatedLog.punchInLng,
      punchoutlat: updatedLog.punchOutLat,
      punchoutlng: updatedLog.punchOutLng
    }).eq('id', updatedLog.id).then();
    
    playChime('complete');
  };

  const handleDeleteAttendanceLog = (id: string) => {
    setAttendanceLogs((prev) => prev.filter((log) => log.id !== id));
    supabase.from('attendance_logs').delete().eq('id', id).then();
    playChime('alert');
  };

  const handleTogglePinNotice = (id: string) => {
    setNotices((prev) =>
      prev.map((n) => {
        if (n.id === id) {
          const pinned = !n.pinned;
          supabase.from('company_notices').update({ pinned }).eq('id', id).then();
          return { ...n, pinned };
        }
        return n;
      })
    );
  };

  const handleRegenerateQR = () => {
    const newSeed = `ROT-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const now = new Date().toISOString();
    setQrRotationSeed(newSeed);
    setQrLastRotated(now);
    localStorage.setItem('mandideals_qr_seed', newSeed);
    localStorage.setItem('mandideals_qr_rotated', now);
    supabase.from('company_settings').upsert([
      { key: 'qr_rotation_seed', value: newSeed },
      { key: 'qr_last_rotated', value: now }
    ]).then();
    playChime('complete');
    alert("Executive Action: Security QR Seed has been rotated. All previously printed codes for today are now INVALID.");
  };

  // Tasks Handlers
  const handleSaveTask = (
    taskData: Omit<Task, 'id' | 'createdAt'>,
    existingId?: string
  ) => {
    if (existingId) {
      setTasks((prev) =>
        prev.map((t) => {
          if (t.id === existingId) {
            const updated = { ...t, ...taskData };
            offlineSyncService.queueAction({
              table: 'tasks',
              type: 'upsert',
              data: sanitizeTaskForDB(updated)
            });
            return updated;
          }
          return t;
        })
      );
    } else {
      const newTask: Task = {
        id: `task-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
        createdAt: new Date().toISOString(),
        ...taskData,
      };
      setTasks((prev) => [newTask, ...prev]);
      offlineSyncService.queueAction({
        table: 'tasks',
        type: 'upsert',
        data: sanitizeTaskForDB(newTask)
      });
    }
  };

  const handleQuickAdd = (
    title: string,
    priority: TaskPriority,
    employeeName: string,
    department: string,
    startTime: string,
    endTime: string,
    dueDate?: string,
    reminderTime?: string
  ) => {
    const durationHours = calculateDurationHours(startTime, endTime);
    const matchedEmp = employees.find((e) => e.name === employeeName);

    const newTask: Task = {
      id: `task-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      title,
      employeeName,
      employeeRole: matchedEmp?.role,
      department,
      startTime,
      endTime,
      durationHours,
      priority,
      completed: false,
      createdAt: new Date().toISOString(),
      dueDate,
      reminderTime,
      reminderTriggered: false,
      subtasks: [],
      comments: [],
    };
    setTasks((prev) => [newTask, ...prev]);
    offlineSyncService.queueAction({
      table: 'tasks',
      type: 'upsert',
      data: sanitizeTaskForDB(newTask)
    });
  };

  const handleToggleComplete = (id: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === id) {
          const completed = !t.completed;
          const updated = {
            ...t,
            completed,
            status: (completed ? 'completed' : 'in_progress') as TaskStatus,
            completedAt: completed ? new Date().toISOString() : undefined,
          };
          offlineSyncService.queueAction({
            table: 'tasks',
            type: 'update',
            data: { 
              completed: updated.completed, 
              completedat: updated.completedAt,
              status: updated.status
            },
            filter: { column: 'id', value: id }
          });
          return updated;
        }
        return t;
      })
    );

    if (activeReminderTask && activeReminderTask.id === id) {
      setActiveReminderTask(null);
    }
  };

  const handleDeleteTask = (id: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== id));
    supabase.from('tasks').delete().eq('id', id).then();
    playChime('alert');
    if (activeReminderTask && activeReminderTask.id === id) {
      setActiveReminderTask(null);
    }
  };

  const handleEditTask = (task: Task) => {
    setEditingTask(task);
    setIsTaskModalOpen(true);
  };

  const handleSnoozeTask = (taskId: string, minutes: number) => {
    const newReminder = new Date(Date.now() + minutes * 60 * 1000).toISOString();
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === taskId) {
          const updated = { ...t, reminderTime: newReminder, reminderTriggered: false };
          supabase.from('tasks').update({ 
            remindertime: updated.reminderTime, 
            remindertriggered: updated.reminderTriggered 
          }).eq('id', taskId).then();
          return updated;
        }
        return t;
      })
    );
    if (activeReminderTask && activeReminderTask.id === taskId) {
      setActiveReminderTask(null);
    }
  };

  const handleToggleSubtask = (taskId: string, subtaskId: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === taskId) {
          const updated = {
            ...t,
            subtasks: t.subtasks.map((s) =>
              s.id === subtaskId ? { ...s, completed: !s.completed } : s
            ),
          };
          offlineSyncService.queueAction({
            table: 'tasks',
            type: 'update',
            data: { subtasks: updated.subtasks },
            filter: { column: 'id', value: taskId }
          });
          return updated;
        }
        return t;
      })
    );
  };

  const handleUpdateTaskStatus = (id: string, newStatus: TaskStatus) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === id) {
          const isCompleted = newStatus === 'completed';
          const updated = {
            ...t,
            status: newStatus,
            completed: isCompleted,
            completedAt: isCompleted ? (t.completedAt || new Date().toISOString()) : undefined,
          };
          offlineSyncService.queueAction({
            table: 'tasks',
            type: 'update',
            data: { 
              status: updated.status, 
              completed: updated.completed, 
              completedat: updated.completedAt 
            },
            filter: { column: 'id', value: id }
          });
          return updated;
        }
        return t;
      })
    );
    if (newStatus === 'completed') {
      playChime('complete');
    } else {
      playChime('reminder');
    }
  };

  const handleUpdateTaskDescription = (id: string, description: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === id) {
          offlineSyncService.queueAction({
            table: 'tasks',
            type: 'update',
            data: { description },
            filter: { column: 'id', value: id }
          });
          return { ...t, description };
        }
        return t;
      })
    );
    playChime('complete');
  };

  const handleUpdateTaskRating = (id: string, rating: number) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === id) {
          offlineSyncService.queueAction({
            table: 'tasks',
            type: 'update',
            data: { rating },
            filter: { column: 'id', value: id }
          });
          return { ...t, rating };
        }
        return t;
      })
    );
    playChime('complete');
  };

  const handleAddSubtask = (taskId: string, title: string) => {
    const newSub: SubTask = {
      id: `sub-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      title,
      completed: false,
    };
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === taskId) {
          const updated = { ...t, subtasks: [...(t.subtasks || []), newSub] };
          offlineSyncService.queueAction({
            table: 'tasks',
            type: 'update',
            data: { subtasks: updated.subtasks },
            filter: { column: 'id', value: taskId }
          });
          return updated;
        }
        return t;
      })
    );
    playChime('complete');
  };

  const handleClearCompleted = () => {
    const completedIds = tasks.filter(t => t.completed).map(t => t.id);
    if (completedIds.length === 0) return;

    if (window.confirm(`Are you sure you want to permanently clear all ${completedIds.length} completed work logs?`)) {
      setTasks((prev) => prev.filter((t) => !t.completed));
      completedIds.forEach(id => {
        offlineSyncService.queueAction({
          table: 'tasks',
          type: 'delete',
          filter: { column: 'id', value: id }
        });
      });
      playChime('alert');
    }
  };

  // CEO Super Admin action: Approve all tasks
  const handleApproveAllTasks = () => {
    setTasks(prev => {
      const updatedTasks = prev.map((t) => ({
        ...t,
        completed: true,
        completedAt: t.completedAt || new Date().toISOString(),
      }));

      // Sync to Supabase - using upsert for bulk update via OfflineSyncService
      updatedTasks.forEach(task => {
        offlineSyncService.queueAction({
          table: 'tasks',
          type: 'upsert',
          data: sanitizeTaskForDB(task)
        });
      });

      return updatedTasks;
    });
    
    playChime('complete');
  };

  // Export Work Logs to TSV format for Google Sheets / Excel
  const handleExportCsv = () => {
    const isSuperAdminUser = Boolean(
      currentUser?.isSuperAdmin || currentUser?.accessLevel === 'SUPER_ADMIN'
    );
    const tasksToExport = isSuperAdminUser
      ? tasks
      : tasks.filter((t) => (t.employeeName || '').toLowerCase() === (currentUser?.name || '').toLowerCase());

    const headers = [
      'Status',
      'Deliverable / Task Title',
      'Employee Name',
      'Role',
      'Department',
      'Start Time',
      'End Time',
      'Duration (Hours)',
      'Date',
      'Priority',
    ];

    const rows = tasksToExport.map((t) => [
      t.completed ? 'Completed' : 'In Progress',
      `"${t.title.replace(/"/g, '""')}"`,
      `"${t.employeeName}"`,
      `"${t.employeeRole || ''}"`,
      `"${t.department}"`,
      t.startTime,
      t.endTime,
      (t.durationHours || calculateDurationHours(t.startTime, t.endTime)).toFixed(2),
      t.dueDate || '',
      t.priority,
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const reportPrefix = isSuperAdminUser
      ? 'mandideals_master_work_report'
      : `${currentUser?.name.replace(/\s+/g, '_')}_work_logs`;
    link.download = `${reportPrefix}_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportAttendance = (filters?: { startDate?: string; endDate?: string; employeeId?: string }) => {
    const isSuperAdminUser = Boolean(
      currentUser?.isSuperAdmin || currentUser?.accessLevel === 'SUPER_ADMIN'
    );

    let logsToExport = attendanceLogs;

    // Apply Super Admin filters
    if (isSuperAdminUser && filters) {
      if (filters.employeeId && filters.employeeId !== 'all') {
        logsToExport = logsToExport.filter(l => l.employeeId === filters.employeeId);
      }
      if (filters.startDate) {
        logsToExport = logsToExport.filter(l => l.date >= (filters.startDate as string));
      }
      if (filters.endDate) {
        logsToExport = logsToExport.filter(l => l.date <= (filters.endDate as string));
      }
    } else if (!isSuperAdminUser) {
      // Non-admins only export their own
      logsToExport = attendanceLogs.filter((l) => l.employeeId === currentUser?.id);
    }

    const headers = [
      'Employee Name',
      'Date',
      'Punch In (Time)',
      'Punch In Lat',
      'Punch In Lng',
      'Punch Out (Time)',
      'Punch Out Lat',
      'Punch Out Lng',
      'Total Duration',
      'Status'
    ];

    const rows = logsToExport.map((l) => {
      const start = new Date(l.punchIn);
      const end = l.punchOut ? new Date(l.punchOut) : null;
      let duration = 'Active';
      if (end) {
        const diff = end.getTime() - start.getTime();
        const h = Math.floor(diff / (1000 * 60 * 60));
        const m = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        duration = `${h}h ${m}m`;
      }
      return [
        l.employeeName,
        l.date,
        start.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true }),
        l.punchInLat || 'N/A',
        l.punchInLng || 'N/A',
        end ? end.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true }) : 'N/A',
        l.punchOutLat || 'N/A',
        l.punchOutLng || 'N/A',
        duration,
        l.punchOut ? 'Completed' : 'Active'
      ];
    });

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `attendance_report_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportPdf = (filters?: { startDate?: string; endDate?: string; employeeId?: string }) => {
    const isSuperAdminUser = Boolean(
      currentUser?.isSuperAdmin || currentUser?.accessLevel === 'SUPER_ADMIN'
    );

    let logsToExport = attendanceLogs;

    // Apply Super Admin filters
    if (isSuperAdminUser && filters) {
      if (filters.employeeId && filters.employeeId !== 'all') {
        logsToExport = logsToExport.filter(l => l.employeeId === filters.employeeId);
      }
      if (filters.startDate) {
        logsToExport = logsToExport.filter(l => l.date >= (filters.startDate as string));
      }
      if (filters.endDate) {
        logsToExport = logsToExport.filter(l => l.date <= (filters.endDate as string));
      }
    } else if (!isSuperAdminUser) {
      logsToExport = attendanceLogs.filter((l) => l.employeeId === currentUser?.id);
    }

    const doc = new jsPDF();
    
    // Add Company Header
    doc.setFontSize(22);
    doc.setTextColor(16, 185, 129); // Emerald-600
    doc.text('MANDIDEALS EXECUTIVE PORTAL', 105, 20, { align: 'center' });
    
    doc.setFontSize(14);
    doc.setTextColor(100);
    doc.text('Attendance & Operational Punctuality Report', 105, 30, { align: 'center' });
    
    doc.setFontSize(10);
    doc.text(`Generated on: ${new Date().toLocaleString()}`, 105, 38, { align: 'center' });
    
    if (filters?.startDate || filters?.endDate) {
      doc.text(`Period: ${filters?.startDate || 'All Time'} to ${filters?.endDate || 'Present'}`, 105, 45, { align: 'center' });
    }

    // Summary Stats
    const totalRecords = logsToExport.length;
    const lateArrivals = logsToExport.filter(l => l.isLate).length;
    const completedShifts = logsToExport.filter(l => l.punchOut).length;
    
    doc.setFontSize(12);
    doc.setTextColor(0);
    doc.text('Summary Statistics:', 14, 60);
    doc.setFontSize(10);
    doc.text(`Total Records: ${totalRecords}`, 14, 68);
    doc.text(`Late Arrivals: ${lateArrivals}`, 60, 68);
    doc.text(`Completed Shifts: ${completedShifts}`, 110, 68);

    const tableData = logsToExport.sort((a, b) => new Date(b.punchIn).getTime() - new Date(a.punchIn).getTime()).map(l => {
      const start = new Date(l.punchIn);
      const end = l.punchOut ? new Date(l.punchOut) : null;
      let duration = 'Active';
      if (end) {
        const diff = end.getTime() - start.getTime();
        const h = Math.floor(diff / (1000 * 60 * 60));
        const m = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        duration = `${h}h ${m}m`;
      }
      return [
        l.employeeName,
        l.date,
        start.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true }),
        end ? end.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true }) : '---',
        duration,
        l.isLate ? 'LATE' : 'ON TIME'
      ];
    });

    autoTable(doc, {
      startY: 75,
      head: [['Employee Name', 'Date', 'Punch In', 'Punch Out', 'Duration', 'Status']],
      body: tableData,
      theme: 'striped',
      headStyles: { fillColor: [16, 185, 129] },
      columnStyles: {
        5: { fontStyle: 'bold' }
      },
      didParseCell: (data) => {
        if (data.column.index === 5 && data.cell.text[0] === 'LATE') {
          data.cell.styles.textColor = [225, 29, 72]; // Rose-600
        }
      }
    });

    doc.save(`mandideals_attendance_${new Date().toISOString().split('T')[0]}.pdf`);
    playChime('complete');
  };

  const handleQRScanSuccess = (decodedText: string) => {
    let isValid = false;
    
    // Legacy support for fixed code
    if (decodedText === 'MANDIDEALS-COMPLEX-VALID-2026') {
      isValid = true;
    } 
    // New dynamic verification format
    else if (decodedText.startsWith('MANDIDEALS-VERIFY:')) {
      const parts = decodedText.split(':');
      const expiryStr = parts[1];
      const genDateStr = parts[2]; // Security rotation component
      const scannedSeed = parts[3]; // Manual rotation component
      
      const expiryDate = new Date(expiryStr);
      const today = new Date();
      today.setHours(0, 0, 0, 0); // Start of today

      // 1. Check Permanent/Temporary Expiry
      if (expiryDate < today) {
        alert("⚠️ ACCESS EXPIRED: This QR code is no longer valid. Please contact Super Admin for a new one.");
        return;
      }

      // 2. Check 24-Hour Rotation Policy
      if (genDateStr) {
        const genDate = new Date(genDateStr);
        genDate.setHours(0, 0, 0, 0);
        const timeDiff = today.getTime() - genDate.getTime();
        const daysDiff = timeDiff / (1000 * 3600 * 24);

        // Codes older than 24h (1 calendar day) are invalidated to prevent reuse
        if (daysDiff > 1) {
          alert("❌ SECURITY ROTATION EXPIRED: This printed QR code is over 24 hours old. Employees must use the latest daily verification code.");
          return;
        }
      }

      // 3. Check Manual Rotation Seed (If security compromised)
      if (scannedSeed && scannedSeed !== qrRotationSeed) {
        alert("❌ SECURITY BREACH DETECTED: This QR code has been manually invalidated by the Super Admin. Please scan the newly generated code.");
        return;
      }

      isValid = true;
    }

    if (isValid) {
      setIsQRScannerOpen(false);
      // Try to get geolocation even with QR for rich data, but fallback to 0,0 if fails
      if ("geolocation" in navigator) {
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            if (qrAction === 'punch-in') handlePunchIn(pos.coords.latitude, pos.coords.longitude);
            else handlePunchOut(pos.coords.latitude, pos.coords.longitude);
          },
          () => {
            // Fallback to 0,0 since QR is valid
            if (qrAction === 'punch-in') handlePunchIn(0, 0);
            else handlePunchOut(0, 0);
          },
          { timeout: 5000 }
        );
      } else {
        if (qrAction === 'punch-in') handlePunchIn(0, 0);
        else handlePunchOut(0, 0);
      }
    } else {
      alert("❌ INVALID QR CODE: This is not an authorized MANDIDEALS Complex verification code.");
    }
  };

  // If database tables are missing or schema is corrupt, show setup instructions
  if (dbError === 'DATABASE_TABLES_MISSING' || dbError === 'SCHEMA_MISMATCH') {
    return (
      <div className="min-h-screen w-full flex flex-col items-center justify-center bg-neutral-900 text-white p-6 overflow-y-auto">
        <div className="max-w-2xl w-full bg-neutral-800 border border-neutral-700 rounded-3xl p-8 shadow-2xl space-y-6">
          <div className="flex items-center gap-4 border-b border-neutral-700 pb-6">
            <div className={`w-16 h-16 rounded-2xl flex items-center justify-center shadow-lg ${dbError === 'SCHEMA_MISMATCH' ? 'bg-rose-500 shadow-rose-500/20' : 'bg-amber-500 shadow-amber-500/20'}`}>
              {dbError === 'SCHEMA_MISMATCH' ? <AlertTriangle className="w-8 h-8 text-white" /> : <Database className="w-8 h-8 text-neutral-950" />}
            </div>
            <div>
              <h2 className="text-2xl font-black tracking-tight text-white uppercase italic">
                {dbError === 'SCHEMA_MISMATCH' ? 'Schema Cache Corrupted' : 'Database Setup Required'}
              </h2>
              <p className="text-neutral-400 font-medium">
                {dbError === 'SCHEMA_MISMATCH' 
                  ? 'Your Supabase cache is out of sync with the app. A hard reset is recommended.' 
                  : 'Supabase tables have not been created in your project yet.'}
              </p>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-sm font-black text-emerald-400 uppercase tracking-widest">Permanent Solution:</h3>
            <ol className="space-y-3 text-sm text-neutral-300 list-decimal ml-4 font-medium">
              <li>Open your <strong>Supabase SQL Editor</strong>.</li>
              <li>Copy and paste the entire code from <code>/supabase_schema.sql</code>.</li>
              {dbError === 'SCHEMA_MISMATCH' && (
                <li className="text-rose-400 font-black italic">CRITICAL: Uncomment lines 12-18 (the DROP TABLE commands) before running!</li>
              )}
              <li>Click <strong>"Run"</strong>.</li>
              <li>Refresh this page.</li>
            </ol>
          </div>

          <div className="bg-neutral-950/50 rounded-2xl p-5 border border-neutral-700/50">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-black text-neutral-500 uppercase tracking-tighter">Required SQL Script</span>
              <span className="text-[10px] font-bold text-emerald-500 italic">Copy this file</span>
            </div>
            <code className="text-xs font-mono text-emerald-400 break-all select-all">/supabase_schema.sql</code>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
            <button 
              onClick={() => {
                setDbError('NONE');
                setIsSyncing(false);
              }}
              className="py-4 rounded-2xl bg-neutral-700 text-white font-black uppercase tracking-widest text-xs hover:bg-neutral-600 transition-colors"
            >
              Skip (Offline Mode)
            </button>
            <button 
              onClick={() => window.location.reload()}
              className="py-4 rounded-2xl bg-emerald-500 text-neutral-950 font-black uppercase tracking-widest text-xs shadow-xl shadow-emerald-500/20 hover:bg-emerald-400 transition-colors"
            >
              Refresh App
            </button>
          </div>
        </div>
      </div>
    );
  }

  // If user is not authenticated, show Login & Register screen
  if (isSyncing) {
    return (
      <div className="min-h-screen w-full flex flex-col items-center justify-center bg-neutral-50 dark:bg-neutral-950 p-6">
        <div className="w-16 h-16 rounded-2xl bg-neutral-900 dark:bg-neutral-100 flex items-center justify-center animate-pulse mb-6 shadow-xl border-2 border-emerald-500">
          <Building2 className="w-8 h-8 text-white dark:text-neutral-900" />
        </div>
        <div className="text-center space-y-2">
          <h2 className="text-lg font-black tracking-tighter text-neutral-900 dark:text-neutral-100 uppercase">MANDIDEALS Executive Portal</h2>
          <div className="flex items-center justify-center gap-2 text-xs font-bold text-emerald-600 uppercase tracking-widest">
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
            Connecting to GMD Cloud Database...
          </div>
        </div>
      </div>
    );
  }

  if (!currentUser) {
    return (
      <AuthScreen
        onLogin={handleLogin}
        onRegister={handleRegister}
        onResetPassword={handleResetPassword}
        employees={employees}
        departments={departments}
        companyLogo={companyLogo}
      />
    );
  }

  const isCurrentSuperAdmin = checkIsSuperAdmin(currentUser);

  // Security & Privacy Rule:
  // "the company mebers and their work only shows to super admin not any one"
  // Super Admin (Sabyasachi) sees all company members and all of their work logs.
  // Any other employee only sees their own assigned deliverables and their own profile!
  const visibleTasks = isCurrentSuperAdmin
    ? tasks
    : tasks.filter(
        (t) => (t.employeeName || '').toLowerCase() === (currentUser?.name || '').toLowerCase()
      );

  const visibleEmployees = isCurrentSuperAdmin
    ? employees
    : employees.filter((e) => e.id === currentUser?.id);

  const visibleNotifications = isCurrentSuperAdmin
    ? notifications
    : notifications.filter(
        (n) => (n.employeeName || '').toLowerCase() === (currentUser?.name || '').toLowerCase()
      );

  const activeViewingEmployee = isCurrentSuperAdmin ? viewingEmployee : currentUser;

  // Mobile Restriction: Only Super Admin can access via mobile
  if (isMobile && !isCurrentSuperAdmin) {
    return (
      <div className="min-h-screen w-full flex flex-col items-center justify-center bg-neutral-900 text-white p-8 text-center">
        <div className="w-20 h-20 rounded-3xl bg-rose-500/20 flex items-center justify-center mb-6 border-2 border-rose-500 animate-pulse">
          <ShieldAlert className="w-10 h-10 text-rose-500" />
        </div>
        <h1 className="text-2xl font-black tracking-tighter uppercase mb-4">Mobile Access Restricted</h1>
        <p className="text-neutral-400 text-sm leading-relaxed max-w-xs mb-8 font-medium">
          MANDIDEALS Enterprise Security Protocol: The mobile interface is strictly reserved for <span className="text-amber-400 font-bold">Super Admin (Sabyasachi)</span> authorization.
        </p>
        <div className="space-y-4 w-full max-w-xs">
          <div className="p-4 rounded-2xl bg-neutral-800 border border-neutral-700 text-left">
            <h3 className="text-xs font-black uppercase text-emerald-500 mb-1">Company Policy</h3>
            <p className="text-[11px] text-neutral-300 font-medium">Please use a Desktop or Tablet device to access your work logs and shift operations.</p>
          </div>
          <button 
            onClick={handleLogout}
            className="w-full py-4 rounded-2xl bg-neutral-100 text-neutral-900 font-black uppercase tracking-widest text-xs hover:bg-white transition-all active:scale-95 shadow-xl"
          >
            Switch Account / Logout
          </button>
        </div>
        <div className="mt-12 text-[10px] font-bold text-neutral-600 uppercase tracking-widest">
          © MANDIDEALS GLOBAL · GMD CLOUD SECURE
        </div>
      </div>
    );
  }

  const handleRefreshData = () => {
    setIsSyncing(true);
    loadAllData();
  };

  return (
    <div className="h-screen w-full flex flex-col bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 transition-colors duration-200 overflow-hidden isolate">
      
      {/* 2. MANDIDEALS Top Navigation Bar */}
      <Navbar
        theme={theme}
        onThemeChange={setTheme}
        isSidebarOpen={isSidebarOpen}
        onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
        onOpenNewTask={() => {
          setEditingTask(null);
          setDefaultTaskEmployee(currentUser.name);
          setIsTaskModalOpen(true);
        }}
        tasks={visibleTasks}
        employees={visibleEmployees}
        currentUser={currentUser}
        companyLogo={companyLogo}
        companyShift={companyShift}
        onOpenUpdateShift={() => setIsUpdateShiftModalOpen(true)}
        activePage={activePage}
        noticesCount={notices.length}
        onNavigatePage={setActivePage}
        onOpenProfileForEmployee={handleOpenProfileForEmployee}
        onOpenChangeLogo={() => setIsCompanyLogoModalOpen(true)}
        onLogout={handleLogout}
        selectedEmployeeFilter={currentView.startsWith('emp:') ? currentView.replace('emp:', '') : null}
        onSelectEmployeeFilter={(name) => {
          if (name && isCurrentSuperAdmin) setCurrentView(`emp:${name}`);
          else setCurrentView('all');
        }}
        notifications={visibleNotifications}
        onClearNotifications={() => setNotifications([])}
        onSnoozeTask={handleSnoozeTask}
        onCompleteTask={handleToggleComplete}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onExportCsv={handleExportCsv}
        syncQueueLength={syncQueueLength}
        syncError={syncError}
        onClearSyncError={() => setSyncError(null)}
      />

      {/* 3. Company Notice Banner (Broadcasted to everyone on main pages) */}
      {activePage !== 'notices' && notices.length > 0 && (
        <NoticeBanner
          notices={notices}
          onOpenNoticesView={() => setActivePage('notices')}
        />
      )}

      {/* 4. Main Workspace Container: Sidebar + View Content */}
      <div className="flex-1 flex flex-col md:flex-row min-h-0 md:overflow-hidden">
        
        {/* Left Sidebar */}
        <Sidebar
          isOpen={isSidebarOpen}
          currentView={currentView}
          onSelectView={(v) => {
            setCurrentView(v);
            setSelectedPriority(null);
            setActivePage('tasks');
            if (isMobile) setIsSidebarOpen(false);
          }}
          departments={departments}
          employees={visibleEmployees}
          currentUser={currentUser}
          companyShift={companyShift}
          onAddEmployee={handleAddEmployee}
          onOpenProfile={(emp) => {
            handleOpenProfileForEmployee(emp);
            if (isMobile) setIsSidebarOpen(false);
          }}
          selectedPriority={selectedPriority}
          onSelectPriority={setSelectedPriority}
          tasks={visibleTasks}
          onOpenNewTask={() => {
            setEditingTask(null);
            setDefaultTaskEmployee(currentUser.name);
            setIsTaskModalOpen(true);
            if (isMobile) setIsSidebarOpen(false);
          }}
          activePage={activePage}
          onNavigatePage={(page) => {
            setActivePage(page);
            if (isMobile) setIsSidebarOpen(false);
          }}
          noticesCount={notices.length}
          onLogout={handleLogout}
          onPunchIn={handlePunchIn}
          onPunchOut={handlePunchOut}
          onOpenLeaveModal={() => {
            setIsLeaveModalOpen(true);
            if (isMobile) setIsSidebarOpen(false);
          }}
          onOpenUpdateShift={() => setIsUpdateShiftModalOpen(true)}
          onApproveAllTasks={handleApproveAllTasks}
          onExportMasterSheet={handleExportCsv}
          onOpenChangeLogo={() => setIsCompanyLogoModalOpen(true)}
          onOpenNotices={() => setActivePage('notices')}
          onOpenQRScanner={(action) => {
            setQRAction(action);
            setIsQRScannerOpen(true);
          }}
          onOpenQRGenerator={() => setIsQRGeneratorOpen(true)}
          onRefreshData={handleRefreshData}
        />

        {/* Mobile Sidebar Backdrop */}
        {isMobile && isSidebarOpen && (
          <div 
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40 animate-in fade-in duration-300"
            onClick={() => setIsSidebarOpen(false)}
          />
        )}

        {/* Main Center Canvas: TaskBoard, Member Profile, or Company Notices View */}
        <main className="flex-1 flex flex-col min-w-0 bg-white dark:bg-neutral-950 overflow-y-auto relative">
          {activePage === 'admin' ? (
            <AdminView
              employees={employees}
              leaveRequests={leaveRequests}
              onToggleAuthorization={handleToggleAuthorization}
              onUpdateAccessLevel={handleUpdateAccessLevel}
              onUpdateLeaveStatus={handleUpdateLeaveStatus}
              onAddEmployee={handleAddEmployee}
              onUpdateEmployee={handleUpdateEmployee}
              onDeleteEmployee={handleDeleteEmployee}
              currentUser={currentUser}
            />
          ) : activePage === 'attendance' ? (
            <AttendanceDashboard
              currentUser={currentUser}
              employees={employees}
              attendanceLogs={attendanceLogs}
              tasks={visibleTasks}
              companyShift={companyShift}
              onExportLogs={handleExportAttendance}
              onExportPdf={handleExportPdf}
              onUpdateAttendanceLog={handleUpdateAttendanceLog}
              onDeleteAttendanceLog={handleDeleteAttendanceLog}
              onInitiateDisciplinaryNote={handleInitiateDisciplinaryNote}
            />
          ) : activePage === 'performance' ? (
            <PerformanceMetrics
              tasks={tasks}
              employees={employees}
            />
          ) : activePage === 'profile' ? (
            <ProfileView
              currentLoggedInUser={currentUser}
              viewingEmployee={activeViewingEmployee}
              onSelectViewingEmployee={setViewingEmployee}
              employees={visibleEmployees}
              tasks={visibleTasks}
              departments={departments}
              onUpdateEmployee={handleUpdateEmployee}
              onBackToTasks={() => setActivePage('tasks')}
              onOpenNewTaskForEmployee={(empName) => {
                setDefaultTaskEmployee(empName);
                setEditingTask(null);
                setIsTaskModalOpen(true);
              }}
              onToggleComplete={handleToggleComplete}
              onDeleteTask={handleDeleteTask}
              onEditTask={handleEditTask}
              onQuickSnooze={handleSnoozeTask}
              onToggleSubtask={handleToggleSubtask}
              notices={notices}
              onAddNotice={handleAddNotice}
              onEditNotice={handleEditNotice}
              onDeleteNotice={handleDeleteNotice}
              onTogglePinNotice={handleTogglePinNotice}
              onUpdateStatus={handleUpdateTaskStatus}
              onUpdateDescription={handleUpdateTaskDescription}
              onAddSubtask={handleAddSubtask}
              onUpdateRating={handleUpdateTaskRating}
              leaveRequests={leaveRequests}
            />
          ) : activePage === 'notices' ? (
            <CompanyNoticesView
              currentUser={currentUser}
              notices={notices}
              onAddNotice={handleAddNotice}
              onEditNotice={handleEditNotice}
              onDeleteNotice={handleDeleteNotice}
              onTogglePinNotice={handleTogglePinNotice}
              onBackToTasks={() => setActivePage('tasks')}
            />
          ) : (
            <TaskBoard
              currentView={currentView}
              tasks={visibleTasks}
              departments={departments}
              employees={visibleEmployees}
              selectedPriority={selectedPriority}
              searchQuery={searchQuery}
              companyShift={companyShift}
              onOpenUpdateShift={() => setIsUpdateShiftModalOpen(true)}
              onToggleComplete={handleToggleComplete}
              onDelete={handleDeleteTask}
              onEdit={handleEditTask}
              onQuickSnooze={handleSnoozeTask}
              onToggleSubtask={handleToggleSubtask}
              onQuickAdd={handleQuickAdd}
              onClearCompleted={handleClearCompleted}
              currentUser={currentUser}
              isSuperAdmin={isCurrentSuperAdmin}
              onUpdateStatus={handleUpdateTaskStatus}
              onUpdateDescription={handleUpdateTaskDescription}
              onAddSubtask={handleAddSubtask}
              onUpdateRating={handleUpdateTaskRating}
            />
          )}
        </main>

      </div>

      {/* 5. Task Creation & Edit Modal */}
      <TaskModal
        isOpen={isTaskModalOpen}
        onClose={() => {
          setIsTaskModalOpen(false);
          setEditingTask(null);
          setDefaultTaskEmployee(undefined);
        }}
        onSave={handleSaveTask}
        editingTask={editingTask}
        employees={visibleEmployees}
        departments={departments}
        defaultEmployee={
          !isCurrentSuperAdmin
            ? currentUser.name
            : defaultTaskEmployee ||
              (currentView.startsWith('emp:')
                ? currentView.replace('emp:', '')
                : currentUser.name)
        }
        defaultDepartment={
          currentView.startsWith('dept:') ? currentView.replace('dept:', '') : undefined
        }
        currentUser={currentUser}
        isSuperAdmin={isCurrentSuperAdmin}
      />

      {/* 6. Company Logo Upload / URL Modal (CEO Super Admin Authority) */}
      <CompanyLogoModal
        isOpen={isCompanyLogoModalOpen}
        onClose={() => setIsCompanyLogoModalOpen(false)}
        currentLogo={companyLogo}
        onSaveLogo={handleSaveCompanyLogo}
        isCeo={isCurrentSuperAdmin}
      />

      {/* 8. Floating Active Push Reminder Banner */}
      <ActiveReminderBanner
        activeTask={activeReminderTask}
        onDismiss={() => setActiveReminderTask(null)}
        onSnooze={handleSnoozeTask}
        onComplete={handleToggleComplete}
      />

      {/* 9. Update Company Work Shift Modal (12-Hour Timing Updated by Sabyasachi) */}
      <UpdateShiftModal
        isOpen={isUpdateShiftModalOpen}
        onClose={() => setIsUpdateShiftModalOpen(false)}
        currentShift={companyShift}
        onSaveShift={handleSaveShift}
      />

      <LeaveRequestModal
        isOpen={isLeaveModalOpen}
        onClose={() => setIsLeaveModalOpen(false)}
        onSubmit={handleRequestLeave}
      />

      <QRScannerModal
        isOpen={isQRScannerOpen}
        onClose={() => setIsQRScannerOpen(false)}
        onScanSuccess={handleQRScanSuccess}
        title={qrAction === 'punch-in' ? 'Punch In Verification' : 'Punch Out Verification'}
      />

      <QRGeneratorModal
        isOpen={isQRGeneratorOpen}
        onClose={() => setIsQRGeneratorOpen(false)}
        rotationSeed={qrRotationSeed}
        lastRotated={qrLastRotated}
        onRegenerate={handleRegenerateQR}
      />
      
      {/* GMD AI Assistant */}
      <ChatAssistant />
    </div>
  );
}
