import React, { useState, useRef, useEffect } from 'react';
import {
  Building2,
  Bell,
  Sun,
  Moon,
  Laptop,
  Plus,
  Search,
  BellRing,
  Volume2,
  Check,
  Clock,
  UserCheck,
  X,
  FileSpreadsheet,
  Crown,
  LogOut,
  User,
  ChevronDown,
  Megaphone,
  Image as ImageIcon,
  ArrowRightLeft,
  LayoutGrid,
  BarChart3,
  Database
} from 'lucide-react';
import { ThemeMode, NotificationLog, Task, Employee, ActivePage, CompanyShift, checkIsSuperAdmin } from '../types/task';
import {
  getNotificationPermission,
  requestNotificationPermission,
  sendPushNotification,
  playChime
} from '../services/notificationService';
import { formatTimeSlot } from '../data/initialTasks';

interface NavbarProps {
  theme: ThemeMode;
  onThemeChange: (theme: ThemeMode) => void;
  onOpenNewTask: () => void;
  tasks: Task[];
  employees: Employee[];
  currentUser: Employee;
  companyLogo: string;
  activePage: ActivePage;
  noticesCount: number;
  companyShift?: CompanyShift;
  onOpenUpdateShift?: () => void;
  onNavigatePage: (page: ActivePage) => void;
  onOpenProfileForEmployee: (emp: Employee) => void;
  onOpenChangeLogo: () => void;
  onLogout?: () => void;
  selectedEmployeeFilter: string | null;
  onSelectEmployeeFilter: (empName: string | null) => void;
  notifications: NotificationLog[];
  onClearNotifications: () => void;
  onSnoozeTask: (taskId: string, minutes: number) => void;
  onCompleteTask: (taskId: string) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onExportCsv: () => void;
  isSidebarOpen?: boolean;
  onToggleSidebar?: () => void;
  syncQueueLength?: number;
  syncError?: string | null;
  onClearSyncError?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  theme,
  onThemeChange,
  onOpenNewTask,
  tasks,
  employees,
  currentUser,
  companyLogo,
  activePage,
  noticesCount,
  companyShift,
  onOpenUpdateShift,
  onNavigatePage,
  onOpenProfileForEmployee,
  onOpenChangeLogo,
  notifications,
  onClearNotifications,
  onSnoozeTask,
  onCompleteTask,
  searchQuery,
  onSearchChange,
  onExportCsv,
  onLogout,
  isSidebarOpen,
  onToggleSidebar,
  syncQueueLength = 0,
  syncError,
  onClearSyncError,
}) => {
  const [showNotificationTray, setShowNotificationTray] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [permission, setPermission] = useState<NotificationPermission>(getNotificationPermission());
  const [isTestSent, setIsTestSent] = useState(false);
  const trayRef = useRef<HTMLDivElement>(null);
  const userMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (trayRef.current && !trayRef.current.contains(e.target as Node)) {
        setShowNotificationTray(false);
      }
      if (userMenuRef.current && !userMenuRef.current.contains(e.target as Node)) {
        setShowUserMenu(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleRequestPermission = async () => {
    const res = await requestNotificationPermission();
    setPermission(res);
    if (res === 'granted') {
      playChime('alert');
      sendPushNotification('MANDIDEALS Operations', 'Push notifications enabled for MandiDeals employee work reminders!');
    }
  };

  const handleSendTestNotification = () => {
    setIsTestSent(true);
    playChime('reminder');
    sendPushNotification(
      'MANDIDEALS Shift Reminder',
      'Test notification: Your shift task reminder is active with chime audio.'
    );
    setTimeout(() => setIsTestSent(false), 3000);
  };

  const scheduledReminders = tasks.filter(
    (t) => !t.completed && t.reminderTime && new Date(t.reminderTime) > new Date()
  );

  const unreadCount = notifications.filter((n) => !n.read).length;

  const isSuperAdmin = checkIsSuperAdmin(currentUser);

  return (
    <header className="sticky top-0 z-[60] w-full border-b border-neutral-200/90 bg-white/95 backdrop-blur-md dark:border-neutral-800/90 dark:bg-neutral-900/95 transition-colors">
      {syncError && (
        <div className="bg-red-600 text-white text-[10px] sm:text-xs py-1.5 px-3 sm:px-6 flex items-center justify-between gap-3 animate-in fade-in slide-in-from-top duration-300">
          <div className="flex items-center gap-2 min-w-0">
            <Database className="w-3.5 h-3.5 shrink-0" />
            <span className="font-bold truncate">
              {syncError}
            </span>
          </div>
          <button 
            onClick={onClearSyncError}
            className="shrink-0 hover:bg-white/20 p-1 rounded-md transition-colors cursor-pointer"
            title="Dismiss error"
          >
            <X className="w-3 h-3" />
          </button>
        </div>
      )}
      <div className="flex h-14 w-full items-center justify-between px-3 sm:px-5 lg:px-6">
        
        {/* Mobile Menu Toggle (Only visible on mobile) */}
        {onToggleSidebar && (
          <button
            onClick={onToggleSidebar}
            className="md:hidden p-2 -ml-2 text-neutral-500 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-white transition-colors cursor-pointer"
            aria-label="Toggle Navigation Menu"
          >
            {isSidebarOpen ? <X className="h-5 w-5" /> : <LayoutGrid className="h-5 w-5" />}
          </button>
        )}

        {/* Brand: MANDIDEALS & Dynamic Company Logo */}
        <div className="flex items-center gap-2.5 shrink-0">
          {/* Clickable Brand Logo & Name */}
          <button
            type="button"
            onClick={() => onNavigatePage('tasks')}
            className="flex items-center gap-2 text-left focus:outline-none group shrink-0 cursor-pointer"
            title="Go to MANDIDEALS Task Board"
          >
            <div className="relative shrink-0">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white shadow-2xs overflow-hidden border border-neutral-200/90 dark:border-neutral-700/80 p-0.5 shrink-0 transition-transform group-hover:scale-[1.02]">
                {companyLogo ? (
                  <img
                    src={companyLogo}
                    alt="MANDIDEALS Logo"
                    className="max-h-full max-w-full object-contain block m-auto"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center rounded-lg bg-emerald-600 text-white font-black text-xs tracking-wider">
                    MD
                  </div>
                )}
              </div>
              {isSuperAdmin && (
                <div
                  onClick={(e) => {
                    e.stopPropagation();
                    onOpenChangeLogo();
                  }}
                  className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center shadow-2xs border border-white dark:border-neutral-900 cursor-pointer hover:scale-110 transition"
                  title="CEO: Change Company Logo"
                >
                  <Crown className="w-2 h-2 stroke-[2.5]" />
                </div>
              )}
            </div>

            <div className="shrink-0 flex flex-col justify-center min-w-0">
              <span className="text-sm sm:text-base font-black tracking-tight text-neutral-900 dark:text-neutral-100 uppercase select-none leading-none">
                MANDIDEALS
              </span>
              <p className="text-[10px] text-neutral-500 dark:text-neutral-400 font-medium whitespace-nowrap leading-tight mt-0.5 truncate max-w-[120px] sm:max-w-none">
                CEO: Sabyasachi · 12h
              </p>
            </div>
          </button>

          {/* Sibling Shift Badge Button with 12-Hour Timing (Updated by Sabyasachi) */}
          <button
            type="button"
            onClick={() => {
              if (isSuperAdmin && onOpenUpdateShift) {
                onOpenUpdateShift();
              }
            }}
            className={`hidden md:inline-flex items-center gap-1.5 h-7.5 px-2 rounded-lg font-mono text-[11px] font-bold tracking-tight leading-none whitespace-nowrap select-none transition-all shadow-2xs shrink-0 ${
              isSuperAdmin
                ? 'bg-emerald-50 text-emerald-900 dark:bg-emerald-950 dark:text-emerald-200 hover:bg-emerald-100 dark:hover:bg-emerald-900 cursor-pointer border border-emerald-300 dark:border-emerald-700'
                : 'bg-emerald-50 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
            }`}
            title={
              isSuperAdmin
                ? "CEO Authority: Click to Update Work Shift (12-Hour Timing)"
                : `Work Shift: ${companyShift?.startTime12 || '10:30 AM'} – ${companyShift?.endTime12 || '06:30 PM'} (Updated by Sabyasachi, CEO)`
            }
          >
            <Clock className="w-3 h-3 text-emerald-600 dark:text-emerald-400 shrink-0" />
            <span>{companyShift?.startTime12 || '10:30 AM'} – {companyShift?.endTime12 || '06:30 PM'}</span>
            <span className="font-sans font-extrabold text-[9px] text-emerald-700 dark:text-emerald-300 bg-emerald-200/70 dark:bg-emerald-800/80 px-1 py-0.2 rounded">
              Sabyasachi
            </span>
            {isSuperAdmin && (
              <span className="font-sans font-bold text-amber-600 dark:text-amber-400 text-[10px] ml-0.5 underline">
                Edit
              </span>
            )}
          </button>
        </div>

        {/* Navigation link tabs: Tasks, Notices, Profiles */}
        <nav className="hidden lg:flex items-center p-0.5 rounded-xl bg-neutral-100/90 dark:bg-neutral-800/70 border border-neutral-200/80 dark:border-neutral-700/60 mx-2 gap-0.5 shadow-2xs">
          <button
            onClick={() => onNavigatePage('tasks')}
            className={`flex items-center gap-1.5 h-7.5 px-2.5 rounded-lg text-xs font-semibold transition-all cursor-pointer whitespace-nowrap select-none shrink-0 ${
              activePage === 'tasks'
                ? 'bg-white text-neutral-900 shadow-2xs dark:bg-neutral-900 dark:text-white font-bold'
                : 'text-neutral-500 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-white hover:bg-white/40 dark:hover:bg-neutral-700/40'
            }`}
          >
            <LayoutGrid className="w-3.5 h-3.5 shrink-0" />
            <span>Tasks</span>
          </button>

          <button
            onClick={() => onNavigatePage('attendance')}
            className={`flex items-center gap-1.5 h-7.5 px-2.5 rounded-lg text-xs font-semibold transition-all cursor-pointer whitespace-nowrap select-none shrink-0 ${
              activePage === 'attendance'
                ? 'bg-white text-neutral-900 shadow-2xs dark:bg-neutral-900 dark:text-white font-bold'
                : 'text-neutral-500 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-white hover:bg-white/40 dark:hover:bg-neutral-700/40'
            }`}
          >
            <Clock className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
            <span>Attendance</span>
          </button>

          {isSuperAdmin && (
            <button
              onClick={() => onNavigatePage('performance')}
              className={`flex items-center gap-1.5 h-7.5 px-2.5 rounded-lg text-xs font-semibold transition-all cursor-pointer whitespace-nowrap select-none shrink-0 ${
                activePage === 'performance'
                  ? 'bg-white text-neutral-900 shadow-2xs dark:bg-neutral-900 dark:text-white font-bold'
                  : 'text-neutral-500 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-white hover:bg-white/40 dark:hover:bg-neutral-700/40'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
              <span>Performance</span>
            </button>
          )}

          <button
            onClick={() => onNavigatePage('notices')}
            className={`flex items-center gap-1.5 h-7.5 px-2.5 rounded-lg text-xs font-semibold transition-all cursor-pointer whitespace-nowrap select-none shrink-0 ${
              activePage === 'notices'
                ? 'bg-white text-neutral-900 shadow-2xs dark:bg-neutral-900 dark:text-white font-bold'
                : 'text-neutral-500 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-white hover:bg-white/40 dark:hover:bg-neutral-700/40'
            }`}
          >
            <Megaphone className="w-3.5 h-3.5 text-amber-500 shrink-0" />
            <span>Notices</span>
            {noticesCount > 0 && (
              <span className="font-mono text-[10px] font-bold text-amber-600 dark:text-amber-400">
                ({noticesCount})
              </span>
            )}
          </button>

          <button
            onClick={() => {
              onOpenProfileForEmployee(currentUser);
            }}
            className={`flex items-center gap-1.5 h-7.5 px-2.5 rounded-lg text-xs font-semibold transition-all cursor-pointer whitespace-nowrap select-none shrink-0 ${
              activePage === 'profile'
                ? 'bg-white text-neutral-900 shadow-2xs dark:bg-neutral-900 dark:text-white font-bold'
                : 'text-neutral-500 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-white hover:bg-white/40 dark:hover:bg-neutral-700/40'
            }`}
          >
            <User className="w-3.5 h-3.5 shrink-0" />
            <span>{isSuperAdmin ? 'Workspaces' : 'Profile'}</span>
          </button>
        </nav>

          {/* Center: Search input & Sync Status */}
          <div className="hidden md:flex flex-1 max-w-sm mx-3 items-center gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-neutral-400 dark:text-neutral-500 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder={isSuperAdmin ? "Search deliverables or staff..." : "Search deliverables..."}
                className="w-full h-8 rounded-lg bg-neutral-100/90 dark:bg-neutral-800/80 border border-neutral-200/60 dark:border-neutral-700/60 focus:border-neutral-300 dark:focus:border-neutral-600 pl-8 pr-7 text-xs text-neutral-900 dark:text-neutral-100 placeholder:text-neutral-400 dark:placeholder:text-neutral-500 focus:outline-none focus:bg-white dark:focus:bg-neutral-900 transition-all shadow-2xs"
              />
              {searchQuery && (
                <button
                  onClick={() => onSearchChange('')}
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-0.5 text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-200 transition rounded"
                  title="Clear search"
                >
                  <X className="h-3 w-3" />
                </button>
              )}
            </div>

            {/* DB Sync Indicator */}
            <div 
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest border transition-all ${
                syncQueueLength > 0 
                  ? 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/30 dark:text-amber-400 dark:border-amber-900/50' 
                  : 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/30 dark:text-emerald-400 dark:border-emerald-900/50'
              }`}
              title={syncQueueLength > 0 ? `${syncQueueLength} actions pending sync to GMD Cloud` : 'All logs synced to GMD Cloud'}
            >
              <Database className={`w-3 h-3 ${syncQueueLength > 0 ? 'animate-pulse' : ''}`} />
              <span className="hidden xl:inline">{syncQueueLength > 0 ? `Syncing ${syncQueueLength}...` : 'Synced'}</span>
              <div className={`w-1.5 h-1.5 rounded-full ${syncQueueLength > 0 ? 'bg-amber-500' : 'bg-emerald-500'}`} />
            </div>
          </div>

        {/* Right Action Icons & Controls */}
        <div className="flex items-center gap-1.5 shrink-0">
          
          {/* Export Work Log to TSV/Sheet */}
          <button
            onClick={onExportCsv}
            className="hidden sm:inline-flex items-center gap-1.5 h-8 px-2.5 rounded-lg border border-neutral-200/90 dark:border-neutral-800 bg-white hover:bg-neutral-50 dark:bg-neutral-900 dark:hover:bg-neutral-800/80 text-xs font-semibold text-neutral-700 dark:text-neutral-200 transition-all shadow-2xs hover:shadow-xs active:scale-[0.98] cursor-pointer whitespace-nowrap select-none shrink-0"
            title={isSuperAdmin ? "Export Company-Wide Work Logs (TSV)" : "Export My Deliverables (TSV)"}
          >
            <FileSpreadsheet className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
            <span className="hidden xl:inline">{isSuperAdmin ? 'Export TSV' : 'Export Logs'}</span>
          </button>

          {/* Push Notification Center Tray Button */}
          <div className="relative" ref={trayRef}>
            <button
              onClick={() => setShowNotificationTray(!showNotificationTray)}
              className={`relative flex h-8 w-8 items-center justify-center rounded-lg border transition-all shadow-2xs active:scale-[0.98] cursor-pointer select-none shrink-0 ${
                showNotificationTray
                  ? 'border-neutral-900 bg-neutral-900 text-white dark:border-white dark:bg-white dark:text-neutral-950 shadow-xs'
                  : 'border-neutral-200/90 bg-white text-neutral-600 hover:text-neutral-900 hover:bg-neutral-50 dark:border-neutral-800 dark:bg-neutral-900 dark:text-neutral-300 dark:hover:text-white dark:hover:bg-neutral-800/80'
              }`}
              title="Work Reminders & Push Alerts"
              aria-label="Push Reminders"
            >
              <Bell className="h-3.5 w-3.5" />
              {(unreadCount > 0 || scheduledReminders.length > 0) && (
                <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-amber-500 ring-2 ring-white dark:ring-neutral-900" />
              )}
            </button>

            {/* Notification Dropdown Panel */}
            {showNotificationTray && (
              <div className="absolute right-0 mt-2 w-80 sm:w-96 rounded-2xl border border-neutral-200 bg-white p-4 shadow-xl dark:border-neutral-800 dark:bg-neutral-900 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                <div className="flex items-center justify-between pb-3 border-b border-neutral-100 dark:border-neutral-800">
                  <div className="flex items-center gap-2">
                    <BellRing className="h-4 w-4 text-amber-500" />
                    <span className="text-xs font-semibold text-neutral-900 dark:text-neutral-100">
                      MANDIDEALS Work Alerts
                    </span>
                  </div>
                  {notifications.length > 0 && (
                    <button
                      onClick={onClearNotifications}
                      className="text-[11px] font-medium text-neutral-500 hover:text-neutral-800 dark:text-neutral-400 dark:hover:text-neutral-200"
                    >
                      Clear all
                    </button>
                  )}
                </div>

                <div className="mt-3 rounded-xl bg-neutral-50 dark:bg-neutral-800/50 p-3 border border-neutral-200/60 dark:border-neutral-700/60 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-neutral-600 dark:text-neutral-400 font-medium">
                      Push Notifications:
                    </span>
                    <span
                      className={`font-semibold text-[11px] ${
                        permission === 'granted'
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : permission === 'denied'
                          ? 'text-rose-500'
                          : 'text-amber-600 dark:text-amber-400'
                      }`}
                    >
                      {permission === 'granted'
                        ? '● Active & Enabled'
                        : permission === 'denied'
                        ? '● Blocked in Browser'
                        : '○ Permission Required'}
                    </span>
                  </div>

                  {permission !== 'granted' ? (
                    <button
                      onClick={handleRequestPermission}
                      className="mt-2.5 w-full rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-700 transition"
                    >
                      Enable Shift Reminders
                    </button>
                  ) : (
                    <button
                      onClick={handleSendTestNotification}
                      disabled={isTestSent}
                      className="mt-2.5 flex items-center justify-center gap-1.5 w-full rounded-lg border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 px-3 py-1.5 text-xs font-medium text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-700 transition"
                    >
                      <Volume2 className="h-3.5 w-3.5" />
                      <span>{isTestSent ? 'Notification Sent!' : 'Test Notification Chime'}</span>
                    </button>
                  )}
                </div>

                {/* Upcoming Scheduled Reminders */}
                <div className="mt-3">
                  <span className="text-[11px] font-semibold text-neutral-500 dark:text-neutral-400 block mb-1.5">
                    Upcoming Shift Reminders ({scheduledReminders.length})
                  </span>
                  {scheduledReminders.length === 0 ? (
                    <p className="text-xs text-neutral-400 dark:text-neutral-500 py-2 italic text-center">
                      No upcoming task reminders scheduled.
                    </p>
                  ) : (
                    <div className="max-h-40 overflow-y-auto space-y-1.5 pr-1">
                      {scheduledReminders.slice(0, 5).map((task) => (
                        <div
                          key={task.id}
                          className="flex items-center justify-between rounded-lg p-2 bg-neutral-50/70 dark:bg-neutral-800/40 text-xs"
                        >
                          <div className="min-w-0 flex-1 pr-2">
                            <p className="font-medium text-neutral-900 dark:text-neutral-100 truncate">
                              {task.title}
                            </p>
                            <span className="text-[10px] text-neutral-500 dark:text-neutral-400 flex items-center gap-1 font-mono">
                              <Clock className="h-3 w-3" />
                              {task.employeeName} · {formatTimeSlot(task.startTime, task.endTime)}
                            </span>
                          </div>
                          <button
                            onClick={() => onCompleteTask(task.id)}
                            className="p-1 rounded text-neutral-400 hover:text-emerald-600 transition"
                            title="Mark as done"
                          >
                            <Check className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {notifications.length > 0 && (
                  <div className="mt-3 pt-2 border-t border-neutral-100 dark:border-neutral-800">
                    <span className="text-[11px] font-semibold text-neutral-500 dark:text-neutral-400 block mb-1.5">
                      Recent Alerts
                    </span>
                    <div className="max-h-36 overflow-y-auto space-y-1.5 pr-1">
                      {notifications.slice(0, 4).map((item) => (
                        <div
                          key={item.id}
                          className="p-2 rounded-lg border border-neutral-100 dark:border-neutral-800/80 bg-white dark:bg-neutral-800/30 text-xs"
                        >
                          <div className="flex items-start justify-between">
                            <span className="font-medium text-neutral-800 dark:text-neutral-200">
                              {item.taskTitle}
                            </span>
                            <span className="text-[10px] text-neutral-400 font-mono">
                              {new Date(item.triggeredAt).toLocaleTimeString([], {
                                hour: '2-digit',
                                minute: '2-digit',
                              })}
                            </span>
                          </div>
                          <div className="mt-1 flex items-center gap-2">
                            <button
                              onClick={() => onSnoozeTask(item.taskId, 10)}
                              className="text-[10px] font-medium text-amber-600 dark:text-amber-400 hover:underline"
                            >
                              Snooze 10m
                            </button>
                            <span className="text-neutral-300 dark:text-neutral-700">·</span>
                            <button
                              onClick={() => onCompleteTask(item.taskId)}
                              className="text-[10px] font-medium text-emerald-600 dark:text-emerald-400 hover:underline"
                            >
                              Mark Done
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Theme Selector: Sleek Segmented Control */}
          <div className="hidden sm:flex h-8 items-center rounded-lg border border-neutral-200/90 bg-neutral-100/80 p-0.5 dark:border-neutral-800 dark:bg-neutral-800/80 shadow-2xs shrink-0">
            <button
              onClick={() => onThemeChange('light')}
              className={`h-6.5 w-6.5 flex items-center justify-center rounded-md transition-all cursor-pointer ${
                theme === 'light'
                  ? 'bg-white text-neutral-900 shadow-2xs dark:bg-neutral-700 dark:text-white'
                  : 'text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200'
              }`}
              title="Light Mode"
              aria-label="Light Mode"
            >
              <Sun className="h-3 w-3" />
            </button>
            <button
              onClick={() => onThemeChange('dark')}
              className={`h-6.5 w-6.5 flex items-center justify-center rounded-md transition-all cursor-pointer ${
                theme === 'dark'
                  ? 'bg-white text-neutral-900 shadow-2xs dark:bg-neutral-900 dark:text-white'
                  : 'text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200'
              }`}
              title="Dark Mode"
              aria-label="Dark Mode"
            >
              <Moon className="h-3 w-3" />
            </button>
            <button
              onClick={() => onThemeChange('system')}
              className={`h-6.5 w-6.5 flex items-center justify-center rounded-md transition-all cursor-pointer ${
                theme === 'system'
                  ? 'bg-white text-neutral-900 shadow-2xs dark:bg-neutral-900 dark:text-white'
                  : 'text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200'
              }`}
              title="System Theme"
              aria-label="System Theme"
            >
              <Laptop className="h-3 w-3" />
            </button>
          </div>

          {/* Primary Action Button: + Add Work Log */}
          <button
            onClick={onOpenNewTask}
            className="flex h-8 items-center gap-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white px-2 sm:px-3 text-xs font-bold shadow-2xs hover:shadow-xs active:scale-[0.98] transition-all cursor-pointer whitespace-nowrap select-none shrink-0"
            title="Log Employee Work"
          >
            <Plus className="h-3.5 w-3.5 stroke-[2.5] shrink-0" />
            <span className="hidden sm:inline font-bold whitespace-nowrap">Add Work</span>
          </button>

          {/* User Profile Card & Dropdown */}
          <div className="relative" ref={userMenuRef}>
            <button
              onClick={() => setShowUserMenu(!showUserMenu)}
              className={`flex h-8 items-center gap-1.5 px-2 rounded-lg border transition-all shadow-2xs active:scale-[0.98] cursor-pointer ${
                showUserMenu
                  ? 'border-neutral-400 bg-neutral-100 dark:border-neutral-600 dark:bg-neutral-800'
                  : 'border-neutral-200/90 bg-white hover:bg-neutral-50 dark:border-neutral-800 dark:bg-neutral-900 dark:hover:bg-neutral-800/80'
              }`}
              title="Your Account & Profile"
            >
              <div className={`w-5 h-5 rounded-md flex items-center justify-center font-bold text-[10px] shrink-0 overflow-hidden shadow-2xs ${
                isSuperAdmin
                  ? 'bg-amber-500 text-slate-950 font-black'
                  : 'bg-neutral-900 dark:bg-neutral-100 text-white dark:text-neutral-900'
              }`}>
                {currentUser.avatar ? (
                  <img src={currentUser.avatar} alt={currentUser.name} className="w-full h-full object-cover" />
                ) : (
                  (currentUser.name || '?').charAt(0)
                )}
              </div>

              <div className="hidden lg:block text-left pr-0.5">
                <div className="flex items-center gap-1 leading-none">
                  <span className="text-xs font-bold text-neutral-900 dark:text-neutral-100">
                    {currentUser.name.split(' ')[0]}
                  </span>
                  {isSuperAdmin && (
                    <Crown className="w-2.5 h-2.5 text-amber-500 shrink-0" />
                  )}
                </div>
              </div>

              <ChevronDown className="w-3 h-3 text-neutral-400" />
            </button>

            {/* User Dropdown Menu */}
            {showUserMenu && (
              <div className="absolute right-0 mt-2 w-60 rounded-2xl border border-neutral-200 bg-white p-2 shadow-xl dark:border-neutral-800 dark:bg-neutral-900 z-50 animate-in fade-in duration-100 text-xs">
                
                <div className="px-3 py-2 border-b border-neutral-100 dark:border-neutral-800">
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-neutral-900 dark:text-neutral-100">
                      {currentUser.name}
                    </span>
                    {isSuperAdmin && (
                      <span className="px-1.5 py-0.2 rounded bg-amber-100 text-amber-900 text-[9px] font-black uppercase">Super Admin</span>
                    )}
                  </div>
                  <span className="text-[11px] text-neutral-400 truncate block">
                    {currentUser.email}
                  </span>
                </div>

                <div className="py-1">
                  <button
                    onClick={() => {
                      onOpenProfileForEmployee(currentUser);
                      setShowUserMenu(false);
                    }}
                    className="w-full text-left px-3 py-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 font-semibold text-neutral-800 dark:text-neutral-200 flex items-center gap-2"
                  >
                    <User className="w-3.5 h-3.5 text-emerald-600" />
                    <span>My Profile Page</span>
                  </button>

                  <button
                    onClick={() => {
                      onNavigatePage('notices');
                      setShowUserMenu(false);
                    }}
                    className="w-full text-left px-3 py-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 font-semibold text-neutral-800 dark:text-neutral-200 flex items-center gap-2"
                  >
                    <Megaphone className="w-3.5 h-3.5 text-amber-500" />
                    <span>Company Notice Board</span>
                  </button>

                  {/* CEO Exclusive actions */}
                  {isSuperAdmin && (
                    <>
                      <button
                        onClick={() => {
                          onOpenChangeLogo();
                          setShowUserMenu(false);
                        }}
                        className="w-full text-left px-3 py-2 rounded-lg hover:bg-amber-50 dark:hover:bg-amber-950/40 text-amber-900 dark:text-amber-300 font-bold flex items-center gap-2"
                      >
                        <ImageIcon className="w-3.5 h-3.5 text-amber-600" />
                        <span>Change Company Logo</span>
                      </button>
                    </>
                  )}
                </div>

                {onLogout && (
                  <div className="pt-1 border-t border-neutral-100 dark:border-neutral-800">
                    <button
                      onClick={() => {
                        setShowUserMenu(false);
                        onLogout();
                      }}
                      className="w-full text-left px-3 py-2 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/40 text-rose-600 dark:text-rose-400 font-semibold flex items-center gap-2 transition-colors"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                )}

              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
