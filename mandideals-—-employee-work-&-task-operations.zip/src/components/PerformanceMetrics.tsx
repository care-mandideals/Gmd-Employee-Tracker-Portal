import React, { useMemo, useState } from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Cell,
  Legend,
  LineChart,
  Line,
  AreaChart,
  Area
} from 'recharts';
import { TrendingUp, Users, Target, Activity, Zap, PieChart, Filter, Calendar } from 'lucide-react';
import { Task, Employee } from '../types/task';

interface PerformanceMetricsProps {
  tasks: Task[];
  employees: Employee[];
}

const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4'];

export const PerformanceMetrics: React.FC<PerformanceMetricsProps> = ({ tasks, employees }) => {
  const [selectedDept, setSelectedDept] = useState<string>('all');

  const departments = useMemo(() => {
    return Array.from(new Set(employees.map(e => e.department)));
  }, [employees]);

  const filteredTasks = useMemo(() => {
    if (selectedDept === 'all') return tasks;
    return tasks.filter(t => t.department === selectedDept);
  }, [tasks, selectedDept]);

  const departmentStats = useMemo(() => {
    const deptsToProcess = selectedDept === 'all' ? departments : [selectedDept];
    
    return deptsToProcess.map(dept => {
      const deptTasks = tasks.filter(t => t.department === dept);
      const totalTasks = deptTasks.length;
      const completedTasks = deptTasks.filter(t => t.completed).length;
      const completionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
      
      const totalDuration = deptTasks.reduce((acc, t) => acc + (t.durationHours || 0), 0);
      const avgDuration = totalTasks > 0 ? Number((totalDuration / totalTasks).toFixed(2)) : 0;
      
      const activeEmployees = employees.filter(e => e.department === dept && e.status === 'On Shift').length;
      const totalEmployees = employees.filter(e => e.department === dept).length;

      return {
        department: dept,
        completionRate,
        avgDuration,
        totalTasks,
        completedTasks,
        activeEmployees,
        totalEmployees
      };
    }).sort((a, b) => b.completionRate - a.completionRate);
  }, [tasks, employees, departments, selectedDept]);

  const totalCompleted = filteredTasks.filter(t => t.completed).length;
  const overallCompletionRate = filteredTasks.length > 0 ? Math.round((totalCompleted / filteredTasks.length) * 100) : 0;

  const weeklyTrendData = useMemo(() => {
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - (6 - i));
      return d.toISOString().split('T')[0];
    });

    return last7Days.map(date => {
      const dayTasks = filteredTasks.filter(t => t.createdAt && t.createdAt.startsWith(date));
      const completed = dayTasks.filter(t => t.completed).length;
      const rate = dayTasks.length > 0 ? Math.round((completed / dayTasks.length) * 100) : 0;
      
      const dayLabel = new Date(date).toLocaleDateString('en-US', { weekday: 'short' });
      
      return {
        day: dayLabel,
        fullDate: date,
        rate,
        tasks: dayTasks.length
      };
    });
  }, [filteredTasks]);

  return (
    <div className="flex-1 md:overflow-y-auto bg-neutral-50 dark:bg-neutral-950 p-4 sm:p-6 lg:p-8 space-y-6">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
          <div>
            <h1 className="text-2xl font-black tracking-tight text-neutral-900 dark:text-neutral-100 flex items-center gap-2 uppercase italic">
              <TrendingUp className="w-7 h-7 text-indigo-600" />
              Performance & Analytics
            </h1>
            <p className="text-sm text-neutral-500 dark:text-neutral-400 font-medium">
              {selectedDept === 'all' 
                ? 'Executive overview of operational efficiency and departmental goal attainment.'
                : `Performance insights for the ${selectedDept} department.`
              }
            </p>
          </div>

          <div className="flex items-center gap-3 bg-white dark:bg-neutral-900 p-2 rounded-2xl border border-neutral-200 dark:border-neutral-800 shadow-sm">
            <div className="p-2 rounded-xl bg-neutral-50 dark:bg-neutral-800 text-neutral-400">
              <Filter className="w-4 h-4" />
            </div>
            <select
              value={selectedDept}
              onChange={(e) => setSelectedDept(e.target.value)}
              className="bg-transparent text-sm font-bold text-neutral-900 dark:text-neutral-100 outline-none pr-8 cursor-pointer"
            >
              <option value="all">Company Wide</option>
              {departments.map(dept => (
                <option key={dept} value={dept}>{dept}</option>
              ))}
            </select>
          </div>
        </div>

        {/* High Level Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white dark:bg-neutral-900 p-6 rounded-[32px] border border-neutral-200 dark:border-neutral-800 shadow-sm space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-black uppercase tracking-widest text-neutral-400">Completion Rate</span>
              <div className="w-8 h-8 rounded-xl bg-emerald-100 dark:bg-emerald-950/30 flex items-center justify-center text-emerald-600">
                <Target className="w-4 h-4" />
              </div>
            </div>
            <div className="text-3xl font-black text-neutral-900 dark:text-neutral-100">{overallCompletionRate}%</div>
            <p className="text-[10px] text-neutral-400 font-bold uppercase">
              {selectedDept === 'all' ? 'Average across all teams' : 'Department achievement'}
            </p>
          </div>

          <div className="bg-white dark:bg-neutral-900 p-6 rounded-[32px] border border-neutral-200 dark:border-neutral-800 shadow-sm space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-black uppercase tracking-widest text-neutral-400">Total Deliverables</span>
              <div className="w-8 h-8 rounded-xl bg-blue-100 dark:bg-blue-950/30 flex items-center justify-center text-blue-600">
                <Zap className="w-4 h-4" />
              </div>
            </div>
            <div className="text-3xl font-black text-neutral-900 dark:text-neutral-100">{filteredTasks.length}</div>
            <p className="text-[10px] text-neutral-400 font-bold uppercase">
              {selectedDept === 'all' ? 'Work logs recorded today' : 'Logs in this department'}
            </p>
          </div>

          <div className="bg-white dark:bg-neutral-900 p-6 rounded-[32px] border border-neutral-200 dark:border-neutral-800 shadow-sm space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-black uppercase tracking-widest text-neutral-400">Active Staff</span>
              <div className="w-8 h-8 rounded-xl bg-amber-100 dark:bg-amber-950/30 flex items-center justify-center text-amber-600">
                <Users className="w-4 h-4" />
              </div>
            </div>
            <div className="text-3xl font-black text-neutral-900 dark:text-neutral-100">
              {employees.filter(e => (selectedDept === 'all' || e.department === selectedDept) && e.status === 'On Shift').length}
            </div>
            <p className="text-[10px] text-neutral-400 font-bold uppercase">
              {selectedDept === 'all' ? 'Employees currently on duty' : 'Members on shift'}
            </p>
          </div>

          <div className="bg-white dark:bg-neutral-900 p-6 rounded-[32px] border border-neutral-200 dark:border-neutral-800 shadow-sm space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-black uppercase tracking-widest text-neutral-400">Efficiency Index</span>
              <div className="w-8 h-8 rounded-xl bg-indigo-100 dark:bg-indigo-950/30 flex items-center justify-center text-indigo-600">
                <Activity className="w-4 h-4" />
              </div>
            </div>
            <div className="text-3xl font-black text-neutral-900 dark:text-neutral-100">84.2</div>
            <p className="text-[10px] text-neutral-400 font-bold uppercase">Protocol compliance score</p>
          </div>
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 gap-6">
          {/* Weekly Productivity Trend (NEW) */}
          <div className="bg-white dark:bg-neutral-900 p-8 rounded-[32px] border border-neutral-200 dark:border-neutral-800 shadow-sm space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30">
                  <Calendar className="w-5 h-5 text-emerald-600" />
                </div>
                <div>
                  <h3 className="text-sm font-black uppercase tracking-wider text-neutral-900 dark:text-neutral-100 italic">Weekly Productivity Trend</h3>
                  <p className="text-[10px] text-neutral-500 font-bold uppercase">7-Day Task Completion Rate (%)</p>
                </div>
              </div>
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-neutral-50 dark:bg-neutral-800 border border-neutral-100 dark:border-neutral-700">
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-[10px] font-black text-neutral-600 dark:text-neutral-400 uppercase tracking-widest">Live Feed</span>
              </div>
            </div>
            <div className="h-[350px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={weeklyTrendData} margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorRate" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e5e5" />
                  <XAxis 
                    dataKey="day" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fontSize: 11, fontWeight: 700, fill: '#888' }} 
                  />
                  <YAxis 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fontSize: 11, fontWeight: 700, fill: '#888' }} 
                    domain={[0, 100]}
                  />
                  <Tooltip 
                    formatter={(value: any) => [`${value}%`, 'Completion Rate']}
                    labelFormatter={(label, items) => {
                      if (items && items[0]) {
                        return `${items[0].payload.day} (${items[0].payload.fullDate})`;
                      }
                      return label;
                    }}
                    contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', fontWeight: 700, fontSize: '11px' }}
                    cursor={{ stroke: '#10b981', strokeWidth: 2 }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="rate" 
                    name="Completion %" 
                    stroke="#10b981" 
                    strokeWidth={4}
                    fillOpacity={1} 
                    fill="url(#colorRate)" 
                    animationDuration={2000}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <div className="flex items-center justify-between pt-4 border-t border-neutral-100 dark:border-neutral-800">
              <div className="flex items-center gap-6">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-1 rounded-full bg-emerald-500" />
                  <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest">Productivity Index</span>
                </div>
              </div>
              <span className="text-[10px] font-black text-neutral-400 uppercase italic">Operational Velocity Tracking</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Department Completion Rate */}
          <div className="bg-white dark:bg-neutral-900 p-8 rounded-[32px] border border-neutral-200 dark:border-neutral-800 shadow-sm space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-2xl bg-indigo-50 dark:bg-indigo-950/30">
                  <PieChart className="w-5 h-5 text-indigo-600" />
                </div>
                <h3 className="text-sm font-black uppercase tracking-wider text-neutral-900 dark:text-neutral-100 italic">Department Completion Rate (%)</h3>
              </div>
            </div>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={departmentStats} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e5e5" />
                  <XAxis 
                    dataKey="department" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fontSize: 10, fontWeight: 700, fill: '#888' }} 
                  />
                  <YAxis 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fontSize: 10, fontWeight: 700, fill: '#888' }} 
                    domain={[0, 100]}
                  />
                  <Tooltip 
                    contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', fontWeight: 700, fontSize: '11px' }}
                  />
                  <Bar 
                    dataKey="completionRate" 
                    name="Completion %" 
                    radius={[6, 6, 0, 0]}
                    barSize={40}
                  >
                    {departmentStats.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="flex items-center justify-center gap-6 pt-4 border-t border-neutral-100 dark:border-neutral-800">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-emerald-500" />
                <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest">Target Met</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-amber-500" />
                <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest">In Progress</span>
              </div>
            </div>
          </div>

          {/* Average Task Duration per Department */}
          <div className="bg-white dark:bg-neutral-900 p-8 rounded-[32px] border border-neutral-200 dark:border-neutral-800 shadow-sm space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-2xl bg-amber-50 dark:bg-amber-950/30">
                  <Activity className="w-5 h-5 text-amber-600" />
                </div>
                <h3 className="text-sm font-black uppercase tracking-wider text-neutral-900 dark:text-neutral-100 italic">Average Task Duration (Hrs)</h3>
              </div>
            </div>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={departmentStats} layout="vertical" margin={{ top: 10, right: 30, left: 10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e5e5e5" />
                  <XAxis type="number" hide />
                  <YAxis 
                    dataKey="department" 
                    type="category" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fontSize: 10, fontWeight: 700, fill: '#888' }} 
                    width={80}
                  />
                  <Tooltip 
                    formatter={(value: any) => [`${value} Hours`, 'Avg Duration']}
                    contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', fontWeight: 700, fontSize: '11px' }}
                  />
                  <Bar 
                    dataKey="avgDuration" 
                    radius={[0, 6, 6, 0]}
                    barSize={20}
                  >
                    {departmentStats.map((entry, index) => (
                      <Cell key={`cell-dur-${index}`} fill={COLORS[(index + 2) % COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="flex items-center justify-center gap-6 pt-4 border-t border-neutral-100 dark:border-neutral-800">
               <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest italic">Temporal Efficiency per Department</span>
            </div>
          </div>
        </div>

        {/* Detailed Department Table */}
        <div className="bg-white dark:bg-neutral-900 rounded-[32px] border border-neutral-200 dark:border-neutral-800 shadow-sm overflow-hidden">
          <div className="px-8 py-6 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
            <h3 className="text-sm font-black uppercase tracking-widest text-neutral-900 dark:text-neutral-100 italic">Departmental Efficiency Matrix</h3>
            <span className="px-3 py-1 rounded-full bg-indigo-50 dark:bg-indigo-950 text-indigo-600 text-[10px] font-bold uppercase">Real-time Data</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[800px] text-left border-collapse">
              <thead>
                <tr className="bg-neutral-50 dark:bg-neutral-800/50 text-[10px] font-black uppercase tracking-widest text-neutral-500">
                  <th className="px-8 py-4">Department</th>
                  <th className="px-8 py-4 text-center">Staff On Duty</th>
                  <th className="px-8 py-4 text-center">Task Load</th>
                  <th className="px-8 py-4 text-center">Completion</th>
                  <th className="px-8 py-4 text-center">Avg Duration</th>
                  <th className="px-8 py-4 text-right">Trend</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800">
                {departmentStats.map((stat, idx) => (
                  <tr key={stat.department} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-800/30 transition-colors">
                    <td className="px-8 py-5">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-xl flex items-center justify-center font-black text-white text-[10px]" style={{ backgroundColor: COLORS[idx % COLORS.length] }}>
                          {stat.department.charAt(0)}
                        </div>
                        <span className="text-sm font-bold text-neutral-900 dark:text-neutral-100">{stat.department}</span>
                      </div>
                    </td>
                    <td className="px-8 py-5 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <span className="text-sm font-black text-neutral-900 dark:text-neutral-100">{stat.activeEmployees}</span>
                        <span className="text-[10px] text-neutral-400 font-bold uppercase">/ {stat.totalEmployees}</span>
                      </div>
                    </td>
                    <td className="px-8 py-5 text-center">
                      <span className="text-sm font-black text-indigo-600">{stat.totalTasks}</span>
                    </td>
                    <td className="px-8 py-5 text-center">
                      <div className="flex flex-col items-center gap-1">
                        <span className={`text-sm font-black ${stat.completionRate > 75 ? 'text-emerald-600' : stat.completionRate > 40 ? 'text-amber-600' : 'text-rose-600'}`}>
                          {stat.completionRate}%
                        </span>
                        <div className="w-16 bg-neutral-100 dark:bg-neutral-800 h-1 rounded-full overflow-hidden">
                          <div 
                            className={`h-full rounded-full ${stat.completionRate > 75 ? 'bg-emerald-500' : stat.completionRate > 40 ? 'bg-amber-500' : 'bg-rose-500'}`}
                            style={{ width: `${stat.completionRate}%` }}
                          />
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-5 text-center">
                      <span className="text-sm font-mono font-black text-neutral-700 dark:text-neutral-300">{stat.avgDuration}h</span>
                    </td>
                    <td className="px-8 py-5 text-right">
                      <div className={`inline-flex items-center gap-1 text-[10px] font-black uppercase ${idx % 2 === 0 ? 'text-emerald-600' : 'text-amber-600'}`}>
                        {idx % 2 === 0 ? 'Steady' : 'Improving'}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* CEO Master Activity Log (Direct view of what everyone is doing) */}
        <div className="bg-neutral-900 rounded-[40px] p-8 border border-neutral-800 shadow-2xl space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-black text-white uppercase italic tracking-tighter flex items-center gap-2">
                <Activity className="w-5 h-5 text-emerald-500" />
                Live Operational Activity Log
              </h3>
              <p className="text-[11px] text-neutral-500 font-bold uppercase tracking-widest mt-1">Real-time work stream monitoring across all members</p>
            </div>
          </div>

          <div className="space-y-3">
            {tasks.slice(0, 10).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).map((task) => (
              <div key={task.id} className="flex items-center justify-between p-4 rounded-2xl bg-neutral-800/40 border border-neutral-700/50 hover:border-emerald-500/30 transition-all group">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-neutral-700 flex items-center justify-center font-black text-white text-xs">
                    {task.employeeName.charAt(0)}
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-neutral-100 group-hover:text-emerald-400 transition-colors">{task.title}</h4>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-[10px] font-black text-emerald-500 uppercase tracking-tighter">{task.employeeName}</span>
                      <span className="text-neutral-600">·</span>
                      <span className="text-[10px] font-bold text-neutral-400 uppercase">{task.department}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-right hidden sm:block">
                    <span className="text-[10px] font-mono font-bold text-neutral-500 block">{task.startTime} – {task.endTime}</span>
                    <span className={`text-[9px] font-black uppercase px-1.5 py-0.2 rounded mt-1 inline-block ${
                      task.completed ? 'bg-emerald-950 text-emerald-400' : 'bg-amber-950 text-amber-400'
                    }`}>
                      {task.completed ? 'Signed Off' : 'Active'}
                    </span>
                  </div>
                  <div className={`w-2 h-10 rounded-full ${task.completed ? 'bg-emerald-500' : 'bg-amber-500'} shadow-[0_0_8px_rgba(16,185,129,0.2)]`} />
                </div>
              </div>
            ))}
            {tasks.length === 0 && (
              <div className="py-12 text-center text-neutral-600 font-bold uppercase tracking-widest text-xs">
                No active operational logs detected in the system.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
