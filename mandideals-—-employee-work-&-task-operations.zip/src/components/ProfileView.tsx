import React, { useState } from 'react';
import {
  Crown,
  User,
  Building2,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Clock,
  CheckCircle2,
  Flame,
  ShieldCheck,
  Camera,
  Pencil,
  Plus,
  ArrowLeft,
  FileSpreadsheet,
  X,
  Check,
  Trash2,
  Megaphone,
  Pin,
  PinOff,
  AlertCircle,
  Sparkles,
  ChevronDown
} from 'lucide-react';
import { Employee, Task, TaskPriority, CompanyNotice, NoticePriority, TaskStatus, LeaveRequest } from '../types/task';
import { formatTimeSlot, calculateDurationHours } from '../data/initialTasks';
import { TaskItem } from './TaskItem';
import { TaskDetailWideModal } from './TaskDetailWideModal';

interface ProfileViewProps {
  currentLoggedInUser: Employee;
  viewingEmployee: Employee;
  onSelectViewingEmployee: (emp: Employee) => void;
  employees: Employee[];
  tasks: Task[];
  departments: string[];
  onUpdateEmployee: (updated: Employee) => void;
  onBackToTasks: () => void;
  onOpenNewTaskForEmployee: (empName: string) => void;
  onToggleComplete: (id: string) => void;
  onDeleteTask: (id: string) => void;
  onEditTask: (task: Task) => void;
  onQuickSnooze: (id: string, minutes: number) => void;
  onToggleSubtask: (taskId: string, subtaskId: string) => void;
  notices?: CompanyNotice[];
  onAddNotice?: (notice: Omit<CompanyNotice, 'id' | 'createdAt'>) => void;
  onEditNotice?: (id: string, updated: Partial<Omit<CompanyNotice, 'id' | 'createdAt'>>) => void;
  onDeleteNotice?: (id: string) => void;
  onTogglePinNotice?: (id: string) => void;
  onUpdateStatus?: (id: string, status: TaskStatus) => void;
  onUpdateDescription?: (id: string, description: string) => void;
  onAddSubtask?: (taskId: string, title: string) => void;
  onUpdateRating?: (id: string, rating: number) => void;
  leaveRequests?: LeaveRequest[];
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  currentLoggedInUser,
  viewingEmployee,
  onSelectViewingEmployee,
  employees,
  tasks,
  departments,
  onUpdateEmployee,
  onBackToTasks,
  onOpenNewTaskForEmployee,
  onToggleComplete,
  onDeleteTask,
  onEditTask,
  onQuickSnooze,
  onToggleSubtask,
  notices = [],
  onAddNotice,
  onEditNotice,
  onDeleteNotice,
  onTogglePinNotice,
  onUpdateStatus,
  onUpdateDescription,
  onAddSubtask,
  onUpdateRating,
  leaveRequests = [],
}) => {
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [isPhotoModalOpen, setIsPhotoModalOpen] = useState(false);
  const [photoUrlInput, setPhotoUrlInput] = useState('');
  const [selectedTaskForDetail, setSelectedTaskForDetail] = useState<Task | null>(null);

  // Form states for editing profile
  const [editName, setEditName] = useState(viewingEmployee.name);
  const [editRole, setEditRole] = useState(viewingEmployee.role);
  const [editDepartment, setEditDepartment] = useState(viewingEmployee.department);
  const [editPhone, setEditPhone] = useState(viewingEmployee.phone || '');
  const [editLocation, setEditLocation] = useState(viewingEmployee.location || '');
  const [editBio, setEditBio] = useState(viewingEmployee.bio || '');
  const [editStatus, setEditStatus] = useState(viewingEmployee.status);
  const [statusFilter, setStatusFilter] = useState<'all' | 'Done' | 'In Progress'>('all');

  // Notice management states (Direct Add, Update, Delete in Sabyasachi profile)
  const [isNoticeModalOpen, setIsNoticeModalOpen] = useState(false);
  const [editingNotice, setEditingNotice] = useState<CompanyNotice | null>(null);
  const [noticeTitle, setNoticeTitle] = useState('');
  const [noticeContent, setNoticeContent] = useState('');
  const [noticePriority, setNoticePriority] = useState<NoticePriority>('urgent');
  const [noticePinned, setNoticePinned] = useState(true);
  const [deleteConfirmNoticeId, setDeleteConfirmNoticeId] = useState<string | null>(null);

  // Can this user edit this profile?
  // Super Admin check: guaranteed true for Sabyasachi
  const isCurrentSuperAdmin = Boolean(
    currentLoggedInUser.isSuperAdmin ||
    currentLoggedInUser.accessLevel === 'SUPER_ADMIN' ||
    currentLoggedInUser.email?.toLowerCase() === 'sabya@mandideals.com' ||
    currentLoggedInUser.name?.toLowerCase().includes('sabya')
  );

  const canEdit = isCurrentSuperAdmin || currentLoggedInUser.id === viewingEmployee.id;

  const isSuperAdminUser = Boolean(
    viewingEmployee.isSuperAdmin ||
    viewingEmployee.accessLevel === 'SUPER_ADMIN' ||
    viewingEmployee.email?.toLowerCase() === 'sabya@mandideals.com' ||
    viewingEmployee.name?.toLowerCase().includes('sabya')
  );

  const handleOpenAddNotice = () => {
    setEditingNotice(null);
    setNoticeTitle('');
    setNoticeContent('');
    setNoticePriority('urgent');
    setNoticePinned(true);
    setIsNoticeModalOpen(true);
  };

  const handleOpenEditNotice = (notice: CompanyNotice) => {
    setEditingNotice(notice);
    setNoticeTitle(notice.title);
    setNoticeContent(notice.content);
    setNoticePriority(notice.priority);
    setNoticePinned(Boolean(notice.pinned));
    setIsNoticeModalOpen(true);
  };

  const handleSaveNotice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noticeTitle.trim() || !noticeContent.trim()) return;

    if (editingNotice) {
      onEditNotice?.(editingNotice.id, {
        title: noticeTitle.trim(),
        content: noticeContent.trim(),
        priority: noticePriority,
        pinned: noticePinned,
      });
    } else {
      onAddNotice?.({
        title: noticeTitle.trim(),
        content: noticeContent.trim(),
        authorName: currentLoggedInUser.name,
        authorRole: isCurrentSuperAdmin ? 'CEO & Super Admin' : currentLoggedInUser.role,
        priority: noticePriority,
        pinned: noticePinned,
      });
    }

    setIsNoticeModalOpen(false);
    setEditingNotice(null);
    setNoticeTitle('');
    setNoticeContent('');
  };

  const handleDeleteNoticeClick = (id: string) => {
    onDeleteNotice?.(id);
    setDeleteConfirmNoticeId(null);
  };

  const getNoticePriorityBadge = (p: NoticePriority) => {
    switch (p) {
      case 'urgent':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-rose-100 text-rose-800 dark:bg-rose-950/70 dark:text-rose-300 border border-rose-300 dark:border-rose-800">
            <Flame className="w-3 h-3 text-rose-500" />
            <span>Urgent Mandi Directive</span>
          </span>
        );
      case 'announcement':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-amber-100 text-amber-800 dark:bg-amber-950/70 dark:text-amber-300 border border-amber-300 dark:border-amber-800">
            <Megaphone className="w-3 h-3 text-amber-600" />
            <span>Official Announcement</span>
          </span>
        );
      case 'policy':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-indigo-100 text-indigo-800 dark:bg-indigo-950/70 dark:text-indigo-300 border border-indigo-300 dark:border-indigo-800">
            <ShieldCheck className="w-3 h-3 text-indigo-600" />
            <span>Company Policy</span>
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-emerald-100 text-emerald-800 dark:bg-emerald-950/70 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
            <span>Operational Update</span>
          </span>
        );
    }
  };

  // Tasks for this employee
  const employeeTasks = tasks.filter(
    (t) => (t.employeeName || '').toLowerCase() === (viewingEmployee.name || '').toLowerCase()
  );

  const completedCount = employeeTasks.filter((t) => t.completed).length;
  const inProgressCount = employeeTasks.filter((t) => !t.completed).length;
  const totalHoursLogged = employeeTasks.reduce(
    (acc, t) => acc + (t.durationHours || calculateDurationHours(t.startTime, t.endTime)),
    0
  );
  const urgentCount = employeeTasks.filter((t) => !t.completed && (t.priority === 'urgent' || t.priority === 'high')).length;

  const filteredTasks = employeeTasks.filter((t) => {
    if (statusFilter === 'all') return true;
    if (statusFilter === 'Done') return t.completed;
    return !t.completed;
  });

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: Employee = {
      ...viewingEmployee,
      name: editName.trim(),
      role: editRole.trim(),
      department: editDepartment,
      phone: editPhone.trim(),
      location: editLocation.trim(),
      bio: editBio.trim(),
      status: editStatus,
    };
    onUpdateEmployee(updated);
    setIsEditingProfile(false);
  };

  const handleSavePhoto = (e: React.FormEvent) => {
    e.preventDefault();
    if (photoUrlInput.trim()) {
      onUpdateEmployee({
        ...viewingEmployee,
        avatar: photoUrlInput.trim(),
      });
      setPhotoUrlInput('');
      setIsPhotoModalOpen(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (uploadEvent) => {
        const result = uploadEvent.target?.result as string;
        if (result) {
          onUpdateEmployee({
            ...viewingEmployee,
            avatar: result,
          });
          setIsPhotoModalOpen(false);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Export this employee's individual work log as TSV
  const handleExportMemberSheet = () => {
    const headers = [
      'Status',
      'Deliverable / Task Title',
      'Start Time',
      'End Time',
      'Duration (Hours)',
      'Date',
      'Priority',
      'Department',
    ];

    const rows = employeeTasks.map((t) => [
      t.completed ? 'Completed' : 'In Progress',
      `"${t.title.replace(/"/g, '""')}"`,
      t.startTime,
      t.endTime,
      (t.durationHours || calculateDurationHours(t.startTime, t.endTime)).toFixed(2),
      t.dueDate || '',
      t.priority,
      t.department,
    ]);

    const csvContent = [headers.join('\t'), ...rows.map((r) => r.join('\t'))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/tab-separated-values;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${viewingEmployee.name.replace(/\s+/g, '_')}_work_logs_${new Date().toISOString().split('T')[0]}.tsv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="flex-1 md:overflow-y-auto px-4 sm:px-6 lg:px-8 py-6 max-w-6xl mx-auto w-full space-y-6 animate-in fade-in duration-150">
      
      {/* Top Breadcrumb & Switcher Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-neutral-200/80 dark:border-neutral-800/80">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToTasks}
            className="flex items-center gap-1.5 h-9 px-3 rounded-xl border border-neutral-200/90 dark:border-neutral-800 bg-white hover:bg-neutral-50 dark:bg-neutral-900 dark:hover:bg-neutral-800 text-xs font-semibold text-neutral-700 dark:text-neutral-200 transition-all shadow-2xs hover:shadow-xs active:scale-[0.98] cursor-pointer"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            <span>Back to Work Board</span>
          </button>

          <span className="text-neutral-300 dark:text-neutral-700">/</span>

          <span className="text-xs font-semibold text-neutral-500 dark:text-neutral-400">
            {isCurrentSuperAdmin ? 'All Member Workspaces' : 'My Personal Workspace'}
          </span>
        </div>

        {/* Member Selector Switcher (Exclusively available for Super Admin) */}
        {isCurrentSuperAdmin ? (
          <div className="flex items-center gap-2">
            <span className="text-xs font-medium text-neutral-500 dark:text-neutral-400 hidden sm:inline">
              Switch Member Workspace:
            </span>
            <div className="relative">
              <select
                value={viewingEmployee.id}
                onChange={(e) => {
                  const selected = employees.find((emp) => emp.id === e.target.value);
                  if (selected) {
                    onSelectViewingEmployee(selected);
                    setEditName(selected.name);
                    setEditRole(selected.role);
                    setEditDepartment(selected.department);
                    setEditPhone(selected.phone || '');
                    setEditLocation(selected.location || '');
                    setEditBio(selected.bio || '');
                    setEditStatus(selected.status);
                  }
                }}
                className="h-9 appearance-none rounded-xl border border-neutral-200/90 dark:border-neutral-800 bg-white dark:bg-neutral-900 pl-3 pr-8 text-xs font-semibold text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-1 focus:ring-emerald-500 shadow-2xs hover:bg-neutral-50 dark:hover:bg-neutral-800/60 cursor-pointer transition-all"
              >
                {employees.map((emp) => (
                  <option key={emp.id} value={emp.id}>
                    {emp.name} {emp.isSuperAdmin ? '(CEO)' : `(${emp.role})`} · Workspace
                  </option>
                ))}
              </select>
              <ChevronDown className="pointer-events-none absolute right-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-neutral-400" />
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-1.5 text-xs font-medium text-emerald-800 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 px-2.5 py-1 rounded-xl border border-emerald-200 dark:border-emerald-800">
            <User className="w-3.5 h-3.5 text-emerald-600" />
            <span>My Private Workspace</span>
          </div>
        )}
      </div>

      {!isCurrentSuperAdmin && !isSuperAdminUser && (
        <div className="rounded-2xl border border-amber-200/80 bg-amber-50/70 p-3 text-xs text-amber-900 dark:border-amber-900/60 dark:bg-amber-950/30 dark:text-amber-300 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="font-bold">🔒 Member Workspace Privacy:</span>
            <span>All company member workspaces are confidential and shown only to Super Admin (Sabyasachi).</span>
          </div>
          <span className="font-semibold text-[10px] px-2 py-0.5 rounded bg-amber-200/80 dark:bg-amber-900 text-amber-900 dark:text-amber-200">
            Self View Only
          </span>
        </div>
      )}

      {/* 1. Main Executive Profile Banner Card */}
      <div className="rounded-3xl border border-neutral-200/90 dark:border-neutral-800/90 bg-white dark:bg-neutral-900 p-6 sm:p-8 shadow-xs relative overflow-hidden">
        
        {/* Subtle decorative gradient top bar */}
        <div className={`absolute top-0 left-0 right-0 h-1.5 ${
          isSuperAdminUser
            ? 'bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600'
            : 'bg-gradient-to-r from-emerald-500 to-indigo-600'
        }`} />

        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          
          {/* Avatar and Basic Details */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5">
            
            {/* Avatar Photo with Change Button */}
            <div className="relative group">
              <div className={`w-20 h-20 sm:w-24 sm:h-24 rounded-3xl flex items-center justify-center font-extrabold text-2xl sm:text-3xl text-white shadow-md overflow-hidden border-2 ${
                isSuperAdminUser
                  ? 'border-amber-400 bg-gradient-to-tr from-amber-600 to-yellow-500 text-slate-950 font-black'
                  : 'border-emerald-500 bg-neutral-900 dark:bg-neutral-800 text-white'
              }`}>
                {viewingEmployee.avatar ? (
                  <img
                    src={viewingEmployee.avatar}
                    alt={viewingEmployee.name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  (viewingEmployee.name || '?').charAt(0)
                )}
              </div>

              {canEdit && (
                <button
                  onClick={() => setIsPhotoModalOpen(true)}
                  className="absolute -bottom-1 -right-1 p-2 rounded-xl bg-white dark:bg-neutral-800 text-neutral-700 dark:text-neutral-200 border border-neutral-200 dark:border-neutral-700 shadow-xs hover:bg-neutral-100 dark:hover:bg-neutral-700 transition"
                  title="Change Profile Photo"
                >
                  <Camera className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Profile Text Details */}
            <div className="space-y-1.5">
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black tracking-tight text-neutral-900 dark:text-neutral-100">
                  {viewingEmployee.name}
                </h1>

                {/* Badges */}
                {isSuperAdminUser && (
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-gradient-to-r from-amber-400 to-yellow-400 text-slate-950 font-black text-[11px] shadow-2xs border border-amber-300 uppercase tracking-wider">
                    <Crown className="w-3.5 h-3.5 stroke-[2.5]" />
                    <span>Super Admin · CEO</span>
                  </span>
                )}

                <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider border ${
                  viewingEmployee.status === 'On Shift'
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800'
                    : 'bg-neutral-100 text-neutral-700 border-neutral-200 dark:bg-neutral-800 dark:text-neutral-400'
                }`}>
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  {viewingEmployee.status}
                </span>
              </div>

              <p className="text-xs sm:text-sm font-semibold text-neutral-600 dark:text-neutral-300">
                {viewingEmployee.role}
              </p>

              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-neutral-500 dark:text-neutral-400">
                <span className="flex items-center gap-1.5">
                  <Building2 className="w-3.5 h-3.5 text-neutral-400" />
                  {viewingEmployee.department}
                </span>
                <span className="flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-neutral-400" />
                  {viewingEmployee.email}
                </span>
                {viewingEmployee.phone && (
                  <span className="flex items-center gap-1.5 font-mono">
                    <Phone className="w-3.5 h-3.5 text-neutral-400" />
                    {viewingEmployee.phone}
                  </span>
                )}
              </div>
            </div>

          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-2 self-stretch md:self-auto justify-end">
            <button
              type="button"
              onClick={() => onOpenNewTaskForEmployee(viewingEmployee.name)}
              className="flex-1 md:flex-none flex items-center justify-center gap-2 h-9 px-3.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-semibold shadow-xs hover:shadow-sm active:scale-[0.98] transition-all cursor-pointer whitespace-nowrap select-none shrink-0"
            >
              <Plus className="w-4 h-4 stroke-[2.5] shrink-0" />
              <span>Log Work for {viewingEmployee.name.split(' ')[0]}</span>
            </button>

            {(isSuperAdminUser || isCurrentSuperAdmin) && (
              <button
                type="button"
                onClick={handleOpenAddNotice}
                className="flex items-center gap-1.5 h-9 px-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 text-xs font-bold shadow-xs hover:shadow-sm active:scale-[0.98] transition-all cursor-pointer whitespace-nowrap select-none shrink-0"
                title="Post Company Notice broadcasted to everyone"
              >
                <Megaphone className="w-3.5 h-3.5 stroke-[2.2] shrink-0" />
                <span>+ Post Notice</span>
              </button>
            )}

            {canEdit && (
              <button
                type="button"
                onClick={() => setIsEditingProfile(!isEditingProfile)}
                className="flex items-center gap-1.5 h-9 px-3.5 rounded-xl border border-neutral-200/90 dark:border-neutral-800 bg-white hover:bg-neutral-50 dark:bg-neutral-900 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-200 text-xs font-semibold shadow-2xs hover:shadow-xs active:scale-[0.98] transition-all cursor-pointer whitespace-nowrap select-none shrink-0"
              >
                <Pencil className="w-3.5 h-3.5 shrink-0" />
                <span>{isEditingProfile ? 'Cancel Edit' : 'Edit Profile'}</span>
              </button>
            )}

            <button
              type="button"
              onClick={handleExportMemberSheet}
              className="h-9 w-9 flex items-center justify-center rounded-xl border border-neutral-200/90 dark:border-neutral-800 bg-white hover:bg-neutral-50 dark:bg-neutral-900 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-200 shadow-2xs hover:shadow-xs active:scale-[0.98] transition-all cursor-pointer whitespace-nowrap shrink-0"
              title="Export this member's shift logs to Sheet"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
            </button>
          </div>

        </div>

        {/* Bio & Additional Metadata */}
        {viewingEmployee.bio && (
          <div className="mt-5 pt-4 border-t border-neutral-100 dark:border-neutral-800 text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed">
            <span className="font-bold text-neutral-900 dark:text-neutral-100 block mb-0.5">
              Responsibilities & Scope:
            </span>
            {viewingEmployee.bio}
          </div>
        )}

        {/* Shift and Office Details */}
        <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-3 bg-neutral-50/70 dark:bg-neutral-800/40 p-3 rounded-2xl border border-neutral-100 dark:border-neutral-800 text-xs">
          <div>
            <span className="text-[10px] uppercase font-bold text-neutral-400 block">Shift Timing</span>
            <span className="font-mono font-semibold text-neutral-800 dark:text-neutral-200">
              {viewingEmployee.shift || '10:30 AM – 06:30 PM'}
            </span>
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-neutral-400 block">Office Location</span>
            <span className="font-semibold text-neutral-800 dark:text-neutral-200">
              {viewingEmployee.location || 'Central Mandi Complex'}
            </span>
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-neutral-400 block">Joined MandiDeals</span>
            <span className="font-mono font-semibold text-neutral-800 dark:text-neutral-200">
              {viewingEmployee.joinedDate || '01-Jan-2024'}
            </span>
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-neutral-400 block">Access Authority</span>
            <span className="font-bold text-emerald-700 dark:text-emerald-400">
              {isSuperAdminUser ? '👑 Super Admin Control' : `${viewingEmployee.accessLevel} Authority`}
            </span>
          </div>
        </div>

        {/* INLINE EDIT PROFILE FORM */}
        {isEditingProfile && (
          <form onSubmit={handleSaveProfile} className="mt-5 pt-5 border-t border-neutral-200 dark:border-neutral-800 space-y-3 animate-in fade-in duration-100">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-800 dark:text-neutral-200">
                Update Profile Details for {viewingEmployee.name}
              </h3>
              <span className="text-[11px] text-neutral-400">
                {currentLoggedInUser.isSuperAdmin ? '👑 CEO Master Edit Access' : 'Member Self-Service'}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-neutral-600 dark:text-neutral-400 mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 px-3 py-1.5 text-xs text-neutral-900 dark:text-neutral-100"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-neutral-600 dark:text-neutral-400 mb-1">
                  Designation / Role Title
                </label>
                <input
                  type="text"
                  required
                  value={editRole}
                  onChange={(e) => setEditRole(e.target.value)}
                  className="w-full rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 px-3 py-1.5 text-xs text-neutral-900 dark:text-neutral-100"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-neutral-600 dark:text-neutral-400 mb-1">
                  Department
                </label>
                <select
                  value={editDepartment}
                  onChange={(e) => setEditDepartment(e.target.value)}
                  className="w-full rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 px-3 py-1.5 text-xs text-neutral-900 dark:text-neutral-100"
                >
                  {departments.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-neutral-600 dark:text-neutral-400 mb-1">
                  Phone
                </label>
                <input
                  type="text"
                  value={editPhone}
                  onChange={(e) => setEditPhone(e.target.value)}
                  className="w-full rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 px-3 py-1.5 text-xs text-neutral-900 dark:text-neutral-100 font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-neutral-600 dark:text-neutral-400 mb-1">
                  Office Location
                </label>
                <input
                  type="text"
                  value={editLocation}
                  onChange={(e) => setEditLocation(e.target.value)}
                  className="w-full rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 px-3 py-1.5 text-xs text-neutral-900 dark:text-neutral-100"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-neutral-600 dark:text-neutral-400 mb-1">
                Responsibilities Bio
              </label>
              <textarea
                rows={2}
                value={editBio}
                onChange={(e) => setEditBio(e.target.value)}
                className="w-full rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 px-3 py-1.5 text-xs text-neutral-900 dark:text-neutral-100"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsEditingProfile(false)}
                className="px-3.5 py-1.5 text-xs font-semibold text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 rounded-xl bg-neutral-900 dark:bg-emerald-600 hover:bg-neutral-800 text-white text-xs font-bold transition shadow-xs"
              >
                Save Changes
              </button>
            </div>
          </form>
        )}

        {/* 1b. Leave & Absence History (Personal Tracking) */}
        {!isEditingProfile && (
          <div className="mt-5 pt-4 border-t border-neutral-100 dark:border-neutral-800 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                <h3 className="text-sm font-bold text-neutral-900 dark:text-neutral-100 uppercase tracking-tight">Personal Leave History</h3>
              </div>
              <span className="text-[10px] font-bold text-neutral-400 bg-neutral-100 dark:bg-neutral-800 px-2 py-0.5 rounded-full uppercase tracking-widest">Employee Personal Log</span>
            </div>

            {leaveRequests.filter(r => r.employeeId === viewingEmployee.id).length === 0 ? (
              <div className="py-6 px-4 text-center rounded-2xl bg-neutral-50/50 dark:bg-neutral-800/20 border border-dashed border-neutral-200 dark:border-neutral-800">
                <p className="text-xs text-neutral-500 dark:text-neutral-400 font-medium italic">No leave requests logged in your profile history.</p>
              </div>
            ) : (
              <div className="grid gap-3 sm:grid-cols-2">
                {leaveRequests
                  .filter(r => r.employeeId === viewingEmployee.id)
                  .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                  .map((req) => (
                    <div key={req.id} className="p-3.5 rounded-2xl border border-neutral-200/80 dark:border-neutral-800 bg-neutral-50/50 dark:bg-neutral-900 shadow-2xs space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-[11px] font-bold text-neutral-800 dark:text-neutral-200">{req.startDate} to {req.endDate}</span>
                        <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider ${
                          req.status === 'approved' 
                            ? 'bg-emerald-100 text-emerald-900 dark:bg-emerald-950 dark:text-emerald-300' 
                            : req.status === 'rejected'
                            ? 'bg-rose-100 text-rose-900 dark:bg-rose-950 dark:text-rose-300'
                            : 'bg-amber-100 text-amber-900 dark:bg-amber-950 dark:text-amber-300 animate-pulse'
                        }`}>
                          {req.status}
                        </span>
                      </div>
                      <p className="text-[11px] text-neutral-500 dark:text-neutral-400 leading-snug italic">"{req.reason}"</p>
                      <div className="pt-1 text-[9px] text-neutral-400 flex items-center justify-between">
                        <span>Submitted {new Date(req.createdAt).toLocaleDateString()}</span>
                        {req.status === 'pending' && <span className="font-bold text-amber-600">Pending CEO Approval</span>}
                        {req.status === 'approved' && <span className="font-bold text-emerald-600">Authorized by Sabyasachi</span>}
                      </div>
                    </div>
                  ))}
              </div>
            )}
          </div>
        )}

      </div>

      {/* 2. Company Notices & Executive Directives Management (Sabyasachi Profile) */}
      {(isSuperAdminUser || isCurrentSuperAdmin) && (
        <div className="rounded-3xl border border-amber-300/80 dark:border-amber-700/60 bg-gradient-to-br from-amber-50/40 via-white to-amber-50/20 dark:from-neutral-900 dark:via-neutral-900 dark:to-neutral-800/80 p-6 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-amber-200/60 dark:border-neutral-800">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold shadow-xs shrink-0">
                <Megaphone className="w-5 h-5 stroke-[2.2]" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-base font-extrabold text-neutral-900 dark:text-neutral-100">
                    Company Notices & Executive Directives
                  </h2>
                  <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 dark:bg-amber-950 dark:text-amber-300 text-[10px] font-black uppercase font-mono border border-amber-300 dark:border-amber-700">
                    {notices.length} Active
                  </span>
                  <span className="px-2 py-0.5 rounded-full bg-slate-900 text-amber-300 dark:bg-amber-400 dark:text-slate-950 text-[10px] font-extrabold uppercase tracking-wider">
                    👑 Sabyasachi Management
                  </span>
                </div>
                <p className="text-xs text-neutral-500 dark:text-neutral-400">
                  Broadcast corporate notices, APMC policies, and operational directives across MANDIDEALS
                </p>
              </div>
            </div>

            <button
              onClick={handleOpenAddNotice}
              className="flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-extrabold transition shadow-xs shrink-0 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
              <span>+ Post Notice</span>
            </button>
          </div>

          {/* Notices List */}
          {notices.length === 0 ? (
            <div className="p-6 rounded-2xl border border-dashed border-amber-300/60 dark:border-neutral-800 text-center space-y-2 bg-white/60 dark:bg-neutral-900/60">
              <p className="text-xs font-semibold text-neutral-600 dark:text-neutral-400">
                No active company notices posted yet. Post an executive directive broadcasted to all employees.
              </p>
              <button
                onClick={handleOpenAddNotice}
                className="text-xs font-bold text-amber-600 dark:text-amber-400 hover:underline cursor-pointer"
              >
                + Post your first notice
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {notices.map((notice) => (
                <div
                  key={notice.id}
                  className={`p-4 rounded-2xl border transition-all ${
                    notice.pinned
                      ? 'bg-amber-50/70 dark:bg-neutral-900 border-amber-300 dark:border-amber-700/80 shadow-2xs'
                      : 'bg-white dark:bg-neutral-900/90 border-neutral-200/80 dark:border-neutral-800'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                    <div className="space-y-1.5 flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        {notice.pinned && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-200/80 dark:bg-amber-900/60 text-amber-900 dark:text-amber-200">
                            <Pin className="w-3 h-3 text-amber-700 dark:text-amber-400 fill-amber-700 dark:fill-amber-400" />
                            <span>Pinned</span>
                          </span>
                        )}
                        {getNoticePriorityBadge(notice.priority)}
                        <span className="text-[11px] text-neutral-400 font-mono">
                          {new Date(notice.createdAt).toLocaleDateString('en-GB', {
                            day: '2-digit',
                            month: 'short',
                            year: 'numeric',
                          })}
                        </span>
                      </div>

                      <h3 className="text-sm font-bold text-neutral-900 dark:text-neutral-100">
                        {notice.title}
                      </h3>

                      <p className="text-xs text-neutral-600 dark:text-neutral-300 whitespace-pre-line leading-relaxed">
                        {notice.content}
                      </p>

                      <div className="pt-1 text-[11px] text-neutral-400 flex items-center gap-2">
                        <span>Issued by: <strong className="text-neutral-700 dark:text-neutral-300">{notice.authorName}</strong> ({notice.authorRole})</span>
                      </div>
                    </div>

                    {/* Notice Action Buttons: Pin, Edit, Delete */}
                    <div className="flex items-center gap-1.5 shrink-0 self-end sm:self-start">
                      {onTogglePinNotice && (
                        <button
                          onClick={() => onTogglePinNotice(notice.id)}
                          className={`p-1.5 rounded-xl border text-xs font-semibold transition cursor-pointer ${
                            notice.pinned
                              ? 'bg-amber-100 text-amber-900 border-amber-300 dark:bg-amber-950 dark:text-amber-300 dark:border-amber-800'
                              : 'border-neutral-200 dark:border-neutral-800 text-neutral-500 hover:bg-neutral-100 dark:hover:bg-neutral-800'
                          }`}
                          title={notice.pinned ? "Unpin notice" : "Pin notice to top"}
                        >
                          <Pin className={`w-3.5 h-3.5 ${notice.pinned ? 'fill-current' : ''}`} />
                        </button>
                      )}

                      <button
                        onClick={() => handleOpenEditNotice(notice)}
                        className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-800 text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-700 text-xs font-bold transition shadow-2xs cursor-pointer"
                        title="Update / Edit Notice"
                      >
                        <Pencil className="w-3.5 h-3.5 text-neutral-500" />
                        <span>Edit</span>
                      </button>

                      {deleteConfirmNoticeId === notice.id ? (
                        <div className="flex items-center gap-1 bg-rose-50 dark:bg-rose-950/80 p-1 rounded-xl border border-rose-200 dark:border-rose-900 animate-in fade-in duration-100">
                          <button
                            onClick={() => handleDeleteNoticeClick(notice.id)}
                            className="px-2 py-1 rounded-lg bg-rose-600 text-white text-[11px] font-bold hover:bg-rose-700 transition cursor-pointer"
                          >
                            Delete
                          </button>
                          <button
                            onClick={() => setDeleteConfirmNoticeId(null)}
                            className="px-1.5 py-1 text-[11px] text-neutral-500 hover:text-neutral-800 cursor-pointer"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => setDeleteConfirmNoticeId(notice.id)}
                          className="p-1.5 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-800 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition shadow-2xs cursor-pointer"
                          title="Delete Notice"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Hours Logged */}
        <div className="bg-white dark:bg-neutral-900 rounded-2xl p-4 sm:p-5 border border-neutral-200/90 dark:border-neutral-800 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-500 dark:text-neutral-400">
              Shift Hours Logged
            </span>
            <Clock className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl sm:text-3xl font-extrabold text-neutral-900 dark:text-neutral-100 font-mono">
              {totalHoursLogged.toFixed(1)}h
            </span>
            <span className="text-xs text-neutral-400">invested</span>
          </div>
          <p className="text-[11px] text-neutral-400 mt-2">
            MandiDeals Shift: 10:30 AM – 06:30 PM
          </p>
        </div>

        {/* Tasks Completed */}
        <div className="bg-white dark:bg-neutral-900 rounded-2xl p-4 sm:p-5 border border-neutral-200/90 dark:border-neutral-800 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-500 dark:text-neutral-400">
              Completed Tasks
            </span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl sm:text-3xl font-extrabold text-neutral-900 dark:text-neutral-100 font-mono">
              {completedCount}
            </span>
            <span className="text-xs text-neutral-400">/ {employeeTasks.length} total</span>
          </div>
          <div className="w-full bg-neutral-100 dark:bg-neutral-800 rounded-full h-1.5 mt-2.5 overflow-hidden">
            <div
              className="bg-emerald-600 dark:bg-emerald-500 h-1.5 rounded-full"
              style={{
                width: `${employeeTasks.length > 0 ? (completedCount / employeeTasks.length) * 100 : 0}%`,
              }}
            />
          </div>
        </div>

        {/* Active Items */}
        <div className="bg-white dark:bg-neutral-900 rounded-2xl p-4 sm:p-5 border border-neutral-200/90 dark:border-neutral-800 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-500 dark:text-neutral-400">
              In-Flight Tasks
            </span>
            <Flame className="w-4 h-4 text-amber-500" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl sm:text-3xl font-extrabold text-neutral-900 dark:text-neutral-100 font-mono">
              {inProgressCount}
            </span>
            <span className="text-xs text-neutral-400">pending sign-off</span>
          </div>
          <p className="text-[11px] text-amber-600 dark:text-amber-400 mt-2 font-medium">
            Currently active on shift
          </p>
        </div>

        {/* High Priority Items */}
        <div className="bg-white dark:bg-neutral-900 rounded-2xl p-4 sm:p-5 border border-neutral-200/90 dark:border-neutral-800 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-500 dark:text-neutral-400">
              Urgent & High
            </span>
            <ShieldCheck className="w-4 h-4 text-rose-500" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl sm:text-3xl font-extrabold text-rose-600 dark:text-rose-400 font-mono">
              {urgentCount}
            </span>
            <span className="text-xs text-neutral-400">key deliverables</span>
          </div>
          <p className="text-[11px] text-neutral-400 mt-2">
            Critical APMC operational focus
          </p>
        </div>

      </div>

      {/* 3. Dedicated Member Work Log List */}
      <div className="space-y-4">
        
        {/* Header & Filter Controls */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-neutral-900 dark:text-neutral-100 flex items-center gap-2">
              <Clock className="w-4 h-4 text-emerald-600" />
              <span>{viewingEmployee.name}'s Shift Deliverables</span>
            </h2>
            <span className="font-mono text-xs px-2 py-0.5 rounded-full bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 font-bold">
              {filteredTasks.length}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Filter by Status */}
            <div className="flex items-center rounded-xl border border-neutral-200/80 bg-white p-0.5 dark:border-neutral-800 dark:bg-neutral-900 text-xs shadow-2xs">
              <button
                onClick={() => setStatusFilter('all')}
                className={`px-2.5 py-1 rounded-lg font-medium transition ${
                  statusFilter === 'all'
                    ? 'bg-neutral-900 text-white dark:bg-neutral-100 dark:text-neutral-900 font-bold'
                    : 'text-neutral-500 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-neutral-100'
                }`}
              >
                All ({employeeTasks.length})
              </button>
              <button
                onClick={() => setStatusFilter('In Progress')}
                className={`px-2.5 py-1 rounded-lg font-medium transition ${
                  statusFilter === 'In Progress'
                    ? 'bg-neutral-900 text-white dark:bg-neutral-100 dark:text-neutral-900 font-bold'
                    : 'text-neutral-500 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-neutral-100'
                }`}
              >
                In Progress ({inProgressCount})
              </button>
              <button
                onClick={() => setStatusFilter('Done')}
                className={`px-2.5 py-1 rounded-lg font-medium transition ${
                  statusFilter === 'Done'
                    ? 'bg-neutral-900 text-white dark:bg-neutral-100 dark:text-neutral-900 font-bold'
                    : 'text-neutral-500 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-neutral-100'
                }`}
              >
                Completed ({completedCount})
              </button>
            </div>
          </div>
        </div>

        {/* Tasks List */}
        {filteredTasks.length === 0 ? (
          <div className="p-8 rounded-3xl border border-dashed border-neutral-300 dark:border-neutral-800 text-center space-y-2 bg-neutral-50/50 dark:bg-neutral-900/20">
            <p className="text-xs font-semibold text-neutral-700 dark:text-neutral-300">
              No tasks found for this filter.
            </p>
            <button
              onClick={() => onOpenNewTaskForEmployee(viewingEmployee.name)}
              className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline"
            >
              + Add a work log for {viewingEmployee.name}
            </button>
          </div>
        ) : (
          <div className="space-y-2.5">
            {filteredTasks.map((task) => (
              <TaskItem
                key={task.id}
                task={task}
                onToggleComplete={onToggleComplete}
                onDelete={onDeleteTask}
                onEdit={onEditTask}
                onQuickSnooze={onQuickSnooze}
                onToggleSubtask={onToggleSubtask}
                onOpenDetail={setSelectedTaskForDetail}
                onUpdateStatus={onUpdateStatus}
                isSuperAdmin={isCurrentSuperAdmin}
                onUpdateRating={onUpdateRating}
              />
            ))}
          </div>
        )}

      </div>

      {/* PHOTO UPLOAD / URL MODAL */}
      {isPhotoModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/60 backdrop-blur-xs">
          <div className="w-full max-w-sm rounded-3xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-neutral-100 dark:border-neutral-800">
              <h3 className="text-sm font-bold text-neutral-900 dark:text-neutral-100">
                Change Profile Photo
              </h3>
              <button
                onClick={() => setIsPhotoModalOpen(false)}
                className="p-1 rounded-lg text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* File Upload */}
            <div>
              <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                Upload Image File
              </label>
              <input
                type="file"
                accept="image/*"
                onChange={handleFileUpload}
                className="w-full text-xs text-neutral-500 file:mr-2 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-emerald-50 file:text-emerald-800 hover:file:bg-emerald-100 cursor-pointer"
              />
            </div>

            {/* URL Input */}
            <form onSubmit={handleSavePhoto} className="space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                  Or Paste Public Image URL
                </label>
                <input
                  type="url"
                  placeholder="https://example.com/photo.jpg"
                  value={photoUrlInput}
                  onChange={(e) => setPhotoUrlInput(e.target.value)}
                  className="w-full rounded-xl border border-neutral-300 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 px-3 py-1.5 text-xs text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setIsPhotoModalOpen(false)}
                  className="px-3 py-1.5 text-xs font-semibold text-neutral-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition"
                >
                  Update Photo
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* NOTICE ADD / EDIT MODAL FOR SABYASACHI */}
      {isNoticeModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/70 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="w-full max-w-lg rounded-3xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-100 dark:border-neutral-800">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold">
                  <Megaphone className="w-4 h-4 stroke-[2.5]" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-neutral-900 dark:text-neutral-100">
                    {editingNotice ? 'Update Company Notice' : 'Post New Company Notice'}
                  </h3>
                  <p className="text-[11px] text-neutral-400">
                    Broadcasted to all employees across MANDIDEALS
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  setIsNoticeModalOpen(false);
                  setEditingNotice(null);
                }}
                className="p-1 rounded-lg text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveNotice} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                  Notice Title *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. APMC Trading Floor Shift Timing Revised"
                  value={noticeTitle}
                  onChange={(e) => setNoticeTitle(e.target.value)}
                  className="w-full rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 px-3.5 py-2 text-xs text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-2 focus:ring-amber-500 font-medium"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                    Notice Category / Priority
                  </label>
                  <select
                    value={noticePriority}
                    onChange={(e) => setNoticePriority(e.target.value as NoticePriority)}
                    className="w-full rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 px-3 py-2 text-xs text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-2 focus:ring-amber-500 font-medium cursor-pointer"
                  >
                    <option value="urgent">🔥 Urgent Mandi Directive</option>
                    <option value="announcement">📢 Official Announcement</option>
                    <option value="operational">⚡ Operational Shift Update</option>
                    <option value="policy">📜 Company Policy Directive</option>
                  </select>
                </div>

                <div className="flex items-center pt-5">
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-neutral-700 dark:text-neutral-300 select-none">
                    <input
                      type="checkbox"
                      checked={noticePinned}
                      onChange={(e) => setNoticePinned(e.target.checked)}
                      className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500"
                    />
                    <span>Pin notice to top of banner</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                  Notice Content & Directive Details *
                </label>
                <textarea
                  required
                  rows={4}
                  placeholder="Detail the mandatory procedure, shift policy, or company update for staff..."
                  value={noticeContent}
                  onChange={(e) => setNoticeContent(e.target.value)}
                  className="w-full rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 px-3.5 py-2 text-xs text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-2 focus:ring-amber-500 font-normal leading-relaxed"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-neutral-100 dark:border-neutral-800">
                <button
                  type="button"
                  onClick={() => {
                    setIsNoticeModalOpen(false);
                    setEditingNotice(null);
                  }}
                  className="px-4 py-2 text-xs font-medium text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-extrabold transition shadow-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                  <span>{editingNotice ? 'Update Notice' : 'Post Notice'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* WIDE FORMAT TASK DETAIL MODAL */}
      <TaskDetailWideModal
        task={selectedTaskForDetail}
        isOpen={Boolean(selectedTaskForDetail)}
        onClose={() => setSelectedTaskForDetail(null)}
        onUpdateStatus={(id, newStatus) => {
          onUpdateStatus?.(id, newStatus);
          setSelectedTaskForDetail((prev) => (prev && prev.id === id ? { ...prev, status: newStatus, completed: newStatus === 'completed' } : prev));
        }}
        onUpdateDescription={(id, desc) => {
          onUpdateDescription?.(id, desc);
          setSelectedTaskForDetail((prev) => (prev && prev.id === id ? { ...prev, description: desc } : prev));
        }}
        onToggleSubtask={onToggleSubtask}
        onAddSubtask={onAddSubtask}
        onEditFullTask={(t) => {
          setSelectedTaskForDetail(null);
          onEditTask(t);
        }}
        onDeleteTask={(id) => {
          setSelectedTaskForDetail(null);
          onDeleteTask(id);
        }}
        isSuperAdmin={isCurrentSuperAdmin}
        onUpdateRating={(id, rating) => {
          if (onUpdateRating) {
            onUpdateRating(id, rating);
          }
          setSelectedTaskForDetail((prev) =>
            prev && prev.id === id ? { ...prev, rating } : prev
          );
        }}
      />

    </div>
  );
};
