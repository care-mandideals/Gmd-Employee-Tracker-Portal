import React, { useState } from 'react';
import {
  X,
  Crown,
  Camera,
  Image as ImageIcon,
  Check,
  ShieldAlert,
  RotateCcw
} from 'lucide-react';
import { DEFAULT_COMPANY_LOGO } from '../data/initialTasks';

interface CompanyLogoModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLogo: string;
  onSaveLogo: (newLogoUrl: string) => void;
  isCeo: boolean;
}

export const CompanyLogoModal: React.FC<CompanyLogoModalProps> = ({
  isOpen,
  onClose,
  currentLogo,
  onSaveLogo,
  isCeo,
}) => {
  const [logoInput, setLogoInput] = useState('');
  const [previewLogo, setPreviewLogo] = useState(currentLogo);
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        setErrorMsg('Image size should be under 2MB.');
        return;
      }
      const reader = new FileReader();
      reader.onload = (uploadEvent) => {
        const result = uploadEvent.target?.result as string;
        if (result) {
          setPreviewLogo(result);
          setErrorMsg('');
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const url = e.target.value;
    setLogoInput(url);
    if (url.trim()) {
      setPreviewLogo(url.trim());
      setErrorMsg('');
    }
  };

  const handleResetDefault = () => {
    setPreviewLogo(DEFAULT_COMPANY_LOGO);
    setLogoInput('');
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isCeo) {
      setErrorMsg('Permission denied: Only CEO (Super Admin) can change company branding.');
      return;
    }
    onSaveLogo(previewLogo);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/70 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        className="w-full max-w-md rounded-3xl border border-amber-300 dark:border-amber-700/80 bg-white dark:bg-neutral-900 p-6 shadow-2xl space-y-4"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-neutral-100 dark:border-neutral-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold">
              <Crown className="w-4 h-4 stroke-[2.5]" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-neutral-900 dark:text-neutral-100">
                Change MANDIDEALS Logo
              </h3>
              <p className="text-[11px] text-amber-600 dark:text-amber-400 font-semibold">
                CEO Super Admin Exclusive Authority
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Live Logo Preview Box */}
        <div className="flex flex-col items-center justify-center p-4 bg-neutral-50 dark:bg-neutral-800/50 rounded-2xl border border-neutral-200/80 dark:border-neutral-700/80 space-y-3">
          <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400">
            Live Navbar Preview (Zero Distortion)
          </span>

          {/* Mini navbar preview container */}
          <div className="w-full max-w-sm flex items-center gap-3 p-2.5 rounded-xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 shadow-2xs">
            <div className="h-11 w-11 rounded-xl bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 p-1 flex items-center justify-center shrink-0 overflow-hidden shadow-2xs">
              {previewLogo ? (
                <img
                  src={previewLogo}
                  alt="Company Logo Preview"
                  className="max-h-full max-w-full object-contain block m-auto"
                  onError={() => {
                    setErrorMsg('Could not load image from this URL. Please verify image source.');
                  }}
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center rounded-lg bg-emerald-600 font-black text-xs text-white">
                  MD
                </div>
              )}
            </div>

            <div className="shrink-0 leading-none">
              <div className="flex items-center gap-1.5 whitespace-nowrap">
                <span className="text-sm font-black text-neutral-900 dark:text-neutral-100 uppercase tracking-tight">
                  MANDIDEALS
                </span>
                <span className="px-1 py-0.5 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 font-mono text-[9px] font-bold">
                  Shift: 10:30–18:30
                </span>
              </div>
              <p className="text-[10px] text-neutral-500 dark:text-neutral-400 mt-1 whitespace-nowrap">
                Employee Work Logs & Task Operations
              </p>
            </div>
          </div>

          <span className="text-[10px] text-neutral-400 text-center">
            Logo automatically fits with proper aspect ratio containment so letters never get distorted.
          </span>
        </div>

        {errorMsg && (
          <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-xs text-rose-700 dark:text-rose-300">
            {errorMsg}
          </div>
        )}

        <form onSubmit={handleSave} className="space-y-3.5">
          {/* File Upload */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
              Upload New Logo File
            </label>
            <input
              type="file"
              accept="image/*"
              onChange={handleFileUpload}
              className="w-full text-xs text-neutral-500 file:mr-2.5 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-amber-100 dark:file:bg-amber-900/60 file:text-amber-900 dark:file:text-amber-200 hover:file:bg-amber-200 cursor-pointer"
            />
          </div>

          {/* URL Input */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
              Or Enter Public Image URL
            </label>
            <input
              type="url"
              placeholder="https://example.com/mandideals-logo.png"
              value={logoInput}
              onChange={handleUrlChange}
              className="w-full rounded-xl border border-neutral-300 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 px-3.5 py-2 text-xs text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>

          <div className="flex items-center justify-between pt-2">
            <button
              type="button"
              onClick={handleResetDefault}
              className="text-xs text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200 flex items-center gap-1"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset Default (MD)</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-3.5 py-1.5 text-xs font-medium text-neutral-600 hover:text-neutral-900 dark:text-neutral-400"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-extrabold shadow-xs transition flex items-center gap-1.5"
              >
                <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                <span>Save Logo</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
