import React, { useState } from 'react';
import { Clock, Calendar, Download, Filter, ArrowRight, User, CheckCircle2, AlertCircle, AlertTriangle, FileSpreadsheet, Star, LayoutDashboard, BarChart3, PieChart as PieChartIcon, RefreshCw, Pencil, Trash2, X, FileText, ShieldAlert } from 'lucide-react';
import { offlineSyncService } from '../services/OfflineSyncService';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer, 
  Cell,
  PieChart,
  Pie
} from 'recharts';
import { Employee, AttendanceLog, CompanyShift, Task, checkIsSuperAdmin } from '../types/task';
import { formatTo12Hour } from '../types/task';

interface AttendanceDashboardProps {
  currentUser: Employee;
  employees: Employee[];
  attendanceLogs: AttendanceLog[];
  tasks: Task[];
  companyShift?: CompanyShift;
  onExportLogs: (filters?: { startDate?: string; endDate?: string; employeeId?: string }) => void;
  onExportPdf: (filters?: { startDate?: string; endDate?: string; employeeId?: string }) => void;
  onUpdateAttendanceLog: (log: AttendanceLog) => void;
  onDeleteAttendanceLog: (id: string) => void;
  onInitiateDisciplinaryNote?: (employeeName: string, lateCount: number) => void;
}

export const AttendanceDashboard: React.FC<AttendanceDashboardProps> = ({
  currentUser,
  employees,
  attendanceLogs,
  tasks,
  companyShift,
  onExportLogs,
  onExportPdf,
  onUpdateAttendanceLog,
  onDeleteAttendanceLog,
  onInitiateDisciplinaryNote,
}) => {
  const [filterDate, setFilterDate] = useState(new Date().toISOString().split('T')[0]);
  const [filterEmployee, setFilterEmployee] = useState<string>('all');
  const [filterDept, setFilterDept] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<'all' | 'on-duty' | 'off-duty'>('all');
  const [showMonthlyReport, setShowMonthlyReport] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [reportStartDate, setReportStartDate] = useState<string>('');
  const [reportEndDate, setReportEndDate] = useState<string>('');

  // Edit State
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingLog, setEditingLog] = useState<AttendanceLog | null>(null);
  const [editPunchIn, setEditPunchIn] = useState('');
  const [editPunchOut, setEditPunchOut] = useState('');
  const [editIsLate, setEditIsLate] = useState(false);
  const [editDate, setEditDate] = useState('');
  const [editPunchInLat, setEditPunchInLat] = useState<number | string>('');
  const [editPunchInLng, setEditPunchInLng] = useState<number | string>('');
  const [editPunchOutLat, setEditPunchOutLat] = useState<number | string>('');
  const [editPunchOutLng, setEditPunchOutLng] = useState<number | string>('');

  // Export Modal State
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [exportStartDate, setExportStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [exportEndDate, setExportEndDate] = useState(new Date().toISOString().split('T')[0]);
  const [exportEmployeeId, setExportEmployeeId] = useState('all');

  const handleOpenEdit = (log: AttendanceLog) => {
    setEditingLog(log);
    // Format for datetime-local input
    const formatForInput = (iso?: string) => {
      if (!iso) return '';
      const d = new Date(iso);
      const pad = (n: number) => n.toString().padStart(2, '0');
      return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
    };
    setEditPunchIn(formatForInput(log.punchIn));
    setEditPunchOut(formatForInput(log.punchOut));
    setEditIsLate(log.isLate || false);
    setEditDate(log.date);
    setEditPunchInLat(log.punchInLat !== undefined ? log.punchInLat : '');
    setEditPunchInLng(log.punchInLng !== undefined ? log.punchInLng : '');
    setEditPunchOutLat(log.punchOutLat !== undefined ? log.punchOutLat : '');
    setEditPunchOutLng(log.punchOutLng !== undefined ? log.punchOutLng : '');
    setIsEditModalOpen(true);
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingLog) return;
    
    onUpdateAttendanceLog({
      ...editingLog,
      punchIn: new Date(editPunchIn).toISOString(),
      punchOut: editPunchOut ? new Date(editPunchOut).toISOString() : undefined,
      isLate: editIsLate,
      date: editDate,
      punchInLat: editPunchInLat !== '' ? Number(editPunchInLat) : undefined,
      punchInLng: editPunchInLng !== '' ? Number(editPunchInLng) : undefined,
      punchOutLat: editPunchOutLat !== '' ? Number(editPunchOutLat) : undefined,
      punchOutLng: editPunchOutLng !== '' ? Number(editPunchOutLng) : undefined
    });
    setIsEditModalOpen(false);
    setEditingLog(null);
  };

  const isSuperAdmin = checkIsSuperAdmin(currentUser);

  const departments = Array.from(new Set(employees.map(e => e.department)));

  const calculateDurationHours = (start: string, end?: string) => {
    if (!end) return 0;
    const diff = new Date(end).getTime() - new Date(start).getTime();
    return diff / (1000 * 60 * 60);
  };

  const calculateDuration = (start: string, end?: string) => {
    if (!end) return 'Active';
    const diff = new Date(end).getTime() - new Date(start).getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m`;
  };

  const months = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  const years = [2025, 2026, 2027];

  // Calculate Monthly/Custom Report for Super Admin
  const monthlyStats = employees.map(emp => {
    const logsInPeriod = attendanceLogs.filter(log => {
      if (reportStartDate || reportEndDate) {
        if (reportStartDate && log.date < reportStartDate) return false;
        if (reportEndDate && log.date > reportEndDate) return false;
        return log.employeeId === emp.id;
      } else {
        const logDate = new Date(log.date);
        return log.employeeId === emp.id && 
               logDate.getMonth() === selectedMonth && 
               logDate.getFullYear() === selectedYear;
      }
    });

    // Count unique days with at least one punch
    const uniqueDays = new Set(logsInPeriod.map(l => l.date)).size;
    const totalHours = logsInPeriod.reduce((acc, l) => acc + calculateDurationHours(l.punchIn, l.punchOut), 0);

    // Calculate Average Performance Rating & Completion Rates for tasks in this period
    const periodTasks = tasks.filter(t => {
      if ((t.employeeName || '').toLowerCase() !== (emp.name || '').toLowerCase()) return false;
      
      const tDate = t.dueDate ? new Date(t.dueDate) : new Date(t.createdAt);
      if (reportStartDate || reportEndDate) {
        if (reportStartDate && t.dueDate && t.dueDate < reportStartDate) return false;
        if (reportEndDate && t.dueDate && t.dueDate > reportEndDate) return false;
        return true;
      } else {
        return tDate.getMonth() === selectedMonth && tDate.getFullYear() === selectedYear;
      }
    });

    const completedTasksCount = periodTasks.filter(t => t.completed).length;
    const completionRate = periodTasks.length > 0 ? Math.round((completedTasksCount / periodTasks.length) * 100) : 0;

    const ratedTasks = periodTasks.filter(t => t.completed && t.rating);
    const avgRating = ratedTasks.length > 0 
      ? ratedTasks.reduce((acc, t) => acc + (t.rating || 0), 0) / ratedTasks.length 
      : 0;

    const lateCount = logsInPeriod.filter(l => l.isLate).length;

    return {
      ...emp,
      displayName: emp.name.split(' ')[0],
      daysPresent: uniqueDays,
      totalHours: totalHours,
      lateCount: lateCount,
      avgRating: avgRating,
      completionRate: completionRate,
      totalTasks: periodTasks.length,
      completedTasks: completedTasksCount
    };
  }).sort((a, b) => b.daysPresent - a.daysPresent);

  const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

  // Filter logs
  const filteredLogs = attendanceLogs.filter(log => {
    const matchesDate = !filterDate || log.date === filterDate;
    
    // Employee filter
    const matchesEmployee = filterEmployee === 'all' 
      ? (isSuperAdmin || log.employeeId === currentUser.id)
      : log.employeeId === filterEmployee;
    
    // Department filter
    const emp = employees.find(e => e.id === log.employeeId);
    const matchesDept = filterDept === 'all' || (emp && emp.department === filterDept);

    // Status filter
    const matchesStatus = filterStatus === 'all' 
      ? true 
      : filterStatus === 'on-duty' ? !log.punchOut : !!log.punchOut;
    
    // Non-admins only see their own
    if (!isSuperAdmin && log.employeeId !== currentUser.id) return false;

    return matchesDate && matchesEmployee && matchesDept && matchesStatus;
  }).sort((a, b) => new Date(b.punchIn).getTime() - new Date(a.punchIn).getTime());

  // Stats
  const userLogsToday = attendanceLogs.filter(l => l.employeeId === currentUser.id && l.date === new Date().toISOString().split('T')[0]);
  const totalUserHoursToday = userLogsToday.reduce((acc, log) => {
    if (!log.punchOut) return acc;
    const diff = new Date(log.punchOut).getTime() - new Date(log.punchIn).getTime();
    return acc + (diff / (1000 * 60 * 60));
  }, 0);

  const formatDateTime = (iso?: string) => {
    if (!iso) return '---';
    const date = new Date(iso);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });
  };

  // Group by day for a small chart/summary
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - i);
    return d.toISOString().split('T')[0];
  }).reverse();

  const dailyStats = last7Days.map(date => {
    const dayLogs = attendanceLogs.filter(l => l.employeeId === currentUser.id && l.date === date);
    const hours = dayLogs.reduce((acc, l) => acc + calculateDurationHours(l.punchIn, l.punchOut), 0);
    return { date, hours };
  });

  const maxHours = Math.max(...dailyStats.map(d => d.hours), 8);

  const pendingSyncCount = offlineSyncService.getQueueLength();

  // Daily Task Pulse calculation
  const todayStr = new Date().toISOString().split('T')[0];
  const todayTasks = tasks.filter(t => {
    const tDate = t.dueDate || t.createdAt.split('T')[0];
    return tDate === todayStr;
  });
  const completedToday = todayTasks.filter(t => t.completed).length;
  const taskPulsePercentage = todayTasks.length > 0 
    ? Math.round((completedToday / todayTasks.length) * 100) 
    : 0;

  return (
    <div className="flex-1 overflow-y-auto bg-neutral-50 dark:bg-neutral-950 p-4 sm:p-6 lg:p-8 space-y-6">
      <div className="max-w-6xl mx-auto space-y-6">
        
        {/* Sync Status Toast */}
        {pendingSyncCount > 0 && (
          <div className="bg-amber-500 text-white px-4 py-2 rounded-2xl flex items-center justify-between shadow-lg animate-bounce">
            <div className="flex items-center gap-2">
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span className="text-xs font-bold uppercase tracking-tight">{pendingSyncCount} records pending sync...</span>
            </div>
            <span className="text-[10px] font-medium italic opacity-90">Auto-syncing as connection allows</span>
          </div>
        )}

        {/* Header Section */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-black tracking-tight text-neutral-900 dark:text-neutral-100 flex items-center gap-2">
              <Clock className="w-7 h-7 text-emerald-600" />
              Attendance Control Center
            </h1>
            <p className="text-sm text-neutral-500 dark:text-neutral-400 font-medium">
              Enterprise arrival & departure tracking with strict geolocation protocols.
            </p>
          </div>
          
          <div className="flex items-center gap-4">
            {/* Daily Task Pulse Ring */}
            <div className="hidden lg:flex items-center gap-3 bg-white dark:bg-neutral-900 px-4 py-2 rounded-2xl border border-neutral-200 dark:border-neutral-800 shadow-sm">
              <div className="relative w-10 h-10">
                <svg className="w-full h-full" viewBox="0 0 36 36">
                  <path
                    className="text-neutral-100 dark:text-neutral-800"
                    stroke="currentColor"
                    strokeWidth="3.5"
                    fill="none"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  />
                  <path
                    className="text-emerald-500"
                    stroke="currentColor"
                    strokeWidth="3.5"
                    strokeDasharray={`${taskPulsePercentage}, 100`}
                    strokeLinecap="round"
                    fill="none"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-[10px] font-black text-neutral-900 dark:text-neutral-100">{taskPulsePercentage}%</span>
                </div>
              </div>
              <div className="flex flex-col">
                <span className="text-[9px] font-black uppercase tracking-widest text-neutral-400">Daily Task Pulse</span>
                <span className="text-[10px] font-bold text-emerald-600">{completedToday}/{todayTasks.length} Done</span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {isSuperAdmin && (
                <button
                  onClick={() => setShowMonthlyReport(!showMonthlyReport)}
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-bold transition shadow-xs ${
                    showMonthlyReport 
                      ? 'bg-indigo-600 text-white' 
                      : 'bg-white dark:bg-neutral-900 text-neutral-700 dark:text-neutral-200 border border-neutral-200 dark:border-neutral-800'
                  }`}
                >
                  <FileSpreadsheet className="w-4 h-4" />
                  {showMonthlyReport ? 'Back to Daily Logs' : 'Monthly Summary Report'}
                </button>
              )}
              <button
                onClick={() => setIsExportModalOpen(true)}
                className="flex items-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-bold shadow-sm transition"
              >
                <Download className="w-4 h-4" />
                Export .CSV
              </button>
            </div>
          </div>
        </div>

        {showMonthlyReport && isSuperAdmin ? (
          <div className="space-y-6 animate-in fade-in slide-in-from-top-4 duration-500">
            {/* Monthly/Custom Report Controls */}
            <div className="bg-white dark:bg-neutral-900 p-6 rounded-3xl border border-neutral-200/80 dark:border-neutral-800 shadow-2xs">
              <div className="flex flex-col lg:flex-row lg:items-center gap-6">
                <div className="flex-1 space-y-1">
                  <h2 className="text-lg font-black text-neutral-900 dark:text-neutral-100">Performance & Goal Analytics</h2>
                  <p className="text-xs text-neutral-500">Master summary of staff attendance and operational hours for {reportStartDate || reportEndDate ? 'custom period' : `${months[selectedMonth]} ${selectedYear}`}.</p>
                </div>
                
                <div className="flex flex-col sm:flex-row items-center gap-4">
                  {/* Month/Year Selection */}
                  <div className="flex items-center gap-2">
                    <div className="flex flex-col gap-1">
                      <span className="text-[9px] font-bold text-neutral-400 uppercase ml-1">By Month</span>
                      <div className="flex items-center gap-2">
                        <select
                          value={selectedMonth}
                          disabled={Boolean(reportStartDate || reportEndDate)}
                          onChange={(e) => setSelectedMonth(parseInt(e.target.value))}
                          className="h-10 rounded-xl bg-neutral-100 dark:bg-neutral-800 px-4 text-sm font-bold text-neutral-800 dark:text-neutral-200 focus:outline-none disabled:opacity-40"
                        >
                          {months.map((m, i) => (
                            <option key={m} value={i}>{m}</option>
                          ))}
                        </select>
                        <select
                          value={selectedYear}
                          disabled={Boolean(reportStartDate || reportEndDate)}
                          onChange={(e) => setSelectedYear(parseInt(e.target.value))}
                          className="h-10 rounded-xl bg-neutral-100 dark:bg-neutral-800 px-4 text-sm font-bold text-neutral-800 dark:text-neutral-200 focus:outline-none disabled:opacity-40"
                        >
                          {years.map(y => (
                            <option key={y} value={y}>{y}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                  </div>

                  <div className="w-px h-10 bg-neutral-200 dark:bg-neutral-800 hidden sm:block" />

                  {/* Custom Range Selection */}
                  <div className="flex items-center gap-2">
                    <div className="flex flex-col gap-1">
                      <span className="text-[9px] font-bold text-neutral-400 uppercase ml-1">Custom Date Range</span>
                      <div className="flex items-center gap-2">
                        <input
                          type="date"
                          value={reportStartDate}
                          onChange={(e) => setReportStartDate(e.target.value)}
                          className="h-10 rounded-xl bg-neutral-100 dark:bg-neutral-800 px-3 text-xs font-semibold text-neutral-800 dark:text-neutral-200 focus:outline-none"
                        />
                        <span className="text-neutral-400">to</span>
                        <input
                          type="date"
                          value={reportEndDate}
                          onChange={(e) => setReportEndDate(e.target.value)}
                          className="h-10 rounded-xl bg-neutral-100 dark:bg-neutral-800 px-3 text-xs font-semibold text-neutral-800 dark:text-neutral-200 focus:outline-none"
                        />
                        {(reportStartDate || reportEndDate) && (
                          <button
                            onClick={() => {
                              setReportStartDate('');
                              setReportEndDate('');
                            }}
                            className="p-2 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-lg transition-colors"
                            title="Clear Range"
                          >
                            <AlertCircle className="w-4 h-4 rotate-45" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* 📈 Visual Analytics Summary Section */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Attendance Frequency Bar Chart */}
              <div className="bg-white dark:bg-neutral-900 p-6 rounded-3xl border border-neutral-200/80 dark:border-neutral-800 shadow-2xl">
                <div className="flex items-center gap-2 mb-6">
                  <BarChart3 className="w-5 h-5 text-emerald-600" />
                  <h3 className="text-sm font-black uppercase tracking-wider text-neutral-900 dark:text-neutral-100">Attendance Frequency</h3>
                </div>
                <div className="h-[240px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={monthlyStats} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e5e5" />
                      <XAxis 
                        dataKey="displayName" 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{ fontSize: 11, fontWeight: 700, fill: '#888' }} 
                      />
                      <YAxis 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{ fontSize: 11, fontWeight: 700, fill: '#888' }} 
                      />
                      <Tooltip 
                        contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', fontWeight: 700, fontSize: '12px' }}
                      />
                      <Bar 
                        dataKey="daysPresent" 
                        name="Days Present" 
                        radius={[6, 6, 0, 0]}
                        barSize={32}
                      >
                        {monthlyStats.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                <div className="mt-4 text-[10px] text-center text-neutral-400 font-bold uppercase tracking-widest">
                  Days Present per Member
                </div>
              </div>

              {/* Task Completion Rate Bar Chart */}
              <div className="bg-white dark:bg-neutral-900 p-6 rounded-3xl border border-neutral-200/80 dark:border-neutral-800 shadow-2xl">
                <div className="flex items-center gap-2 mb-6">
                  <CheckCircle2 className="w-5 h-5 text-blue-600" />
                  <h3 className="text-sm font-black uppercase tracking-wider text-neutral-900 dark:text-neutral-100">Task Completion (%)</h3>
                </div>
                <div className="h-[240px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={monthlyStats} layout="vertical" margin={{ top: 10, right: 30, left: 10, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e5e5e5" />
                      <XAxis type="number" domain={[0, 100]} hide />
                      <YAxis 
                        dataKey="displayName" 
                        type="category" 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{ fontSize: 11, fontWeight: 700, fill: '#888' }} 
                        width={60}
                      />
                      <Tooltip 
                        formatter={(value: any) => [`${value}%`, 'Completion Rate']}
                        contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', fontWeight: 700, fontSize: '12px' }}
                      />
                      <Bar 
                        dataKey="completionRate" 
                        radius={[0, 6, 6, 0]}
                        barSize={16}
                      >
                        {monthlyStats.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.completionRate > 80 ? '#10b981' : entry.completionRate > 50 ? '#3b82f6' : '#f59e0b'} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                <div className="mt-4 text-[10px] text-center text-neutral-400 font-bold uppercase tracking-widest">
                  Overall Log Efficiency
                </div>
              </div>

              {/* Late Arrivals Frequency Bar Chart */}
              <div className="bg-white dark:bg-neutral-900 p-6 rounded-3xl border border-neutral-200/80 dark:border-neutral-800 shadow-2xl">
                <div className="flex items-center gap-2 mb-6">
                  <AlertTriangle className="w-5 h-5 text-rose-500" />
                  <h3 className="text-sm font-black uppercase tracking-wider text-neutral-900 dark:text-neutral-100">Late Arrivals Count</h3>
                </div>
                <div className="h-[240px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={monthlyStats} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e5e5" />
                      <XAxis 
                        dataKey="displayName" 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{ fontSize: 11, fontWeight: 700, fill: '#888' }} 
                      />
                      <YAxis 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{ fontSize: 11, fontWeight: 700, fill: '#888' }} 
                        allowDecimals={false}
                      />
                      <Tooltip 
                        contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', fontWeight: 700, fontSize: '12px' }}
                      />
                      <Bar 
                        dataKey="lateCount" 
                        name="Late Arrivals" 
                        radius={[6, 6, 0, 0]}
                        barSize={32}
                      >
                        {monthlyStats.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.lateCount > 3 ? '#ef4444' : entry.lateCount > 0 ? '#f59e0b' : '#10b981'} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                <div className="mt-4 text-[10px] text-center text-neutral-400 font-bold uppercase tracking-widest">
                  Protocol Violations Count
                </div>
              </div>
            </div>

            {/* Monthly Summary Table */}
            <div className="bg-white dark:bg-neutral-900 rounded-3xl border border-neutral-200/80 dark:border-neutral-800 shadow-2xs">
              <div className="overflow-x-auto scrollbar-thin scrollbar-thumb-neutral-200 dark:scrollbar-thumb-neutral-800">
                <table className="w-full min-w-[1000px] text-left border-collapse">
                <thead>
                  <tr className="bg-neutral-50 dark:bg-neutral-800/50 text-[10px] font-black uppercase tracking-widest text-neutral-500 border-b border-neutral-100 dark:border-neutral-800">
                    <th className="px-6 py-4">Employee Name</th>
                    <th className="px-6 py-4">Role & Department</th>
                    <th className="px-6 py-4 text-center">Days Present</th>
                    <th className="px-6 py-4 text-center text-rose-500">Late Arrivals</th>
                    <th className="px-6 py-4 text-center">Total Hours</th>
                    <th className="px-6 py-4 text-center">Task Completion</th>
                    <th className="px-6 py-4 text-center">Perf. Rating</th>
                    <th className="px-6 py-4 text-right">Attendance Score</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800">
                  {monthlyStats.map(stat => (
                    <tr key={stat.id} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-800/30 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950 flex items-center justify-center font-black text-indigo-600 text-sm">
                            {(stat.name || '?').charAt(0)}
                          </div>
                          <div>
                            <span className="text-sm font-black text-neutral-900 dark:text-neutral-100 block">{stat.name}</span>
                            <span className="text-[10px] text-neutral-400 font-bold uppercase">{stat.id}</span>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="space-y-0.5">
                          <span className="text-xs font-bold text-neutral-700 dark:text-neutral-300 block">{stat.role}</span>
                          <span className="text-[10px] text-neutral-400 font-medium">{stat.department}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <span className="text-base font-black text-neutral-900 dark:text-neutral-100">{stat.daysPresent}</span>
                        <span className="text-[10px] text-neutral-400 font-bold ml-1">Days</span>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <div className="flex flex-col items-center gap-1">
                          <span className={`text-base font-black ${stat.lateCount > 0 ? 'text-rose-500' : 'text-neutral-400'}`}>
                            {stat.lateCount || 0}
                          </span>
                          {stat.lateCount > 3 && (
                            <button
                              onClick={() => onInitiateDisciplinaryNote?.(stat.name, stat.lateCount)}
                              className="group relative flex items-center gap-1 px-2 py-0.5 rounded-full bg-rose-500 text-white text-[8px] font-black uppercase tracking-tighter animate-pulse hover:animate-none transition-all hover:scale-105 active:scale-95"
                              title="Extreme Punctuality Violation: Click to issue disciplinary note"
                            >
                              <ShieldAlert className="w-2.5 h-2.5" />
                              ALERT
                            </button>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <span className="text-sm font-mono font-black text-emerald-600">{stat.totalHours.toFixed(1)}h</span>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <div className="flex flex-col items-center gap-1">
                          <span className={`text-xs font-black ${stat.completionRate >= 80 ? 'text-emerald-600' : stat.completionRate >= 50 ? 'text-blue-600' : 'text-amber-600'}`}>
                            {stat.completionRate}%
                          </span>
                          <span className="text-[9px] text-neutral-400 font-bold uppercase">
                            {stat.completedTasks}/{stat.totalTasks}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <Star className={`w-3.5 h-3.5 ${stat.avgRating > 0 ? 'fill-amber-400 text-amber-400' : 'text-neutral-300'}`} />
                          <span className={`text-sm font-black ${stat.avgRating >= 4 ? 'text-emerald-600' : stat.avgRating >= 3 ? 'text-amber-600' : 'text-neutral-400'}`}>
                            {stat.avgRating > 0 ? stat.avgRating.toFixed(1) : 'N/A'}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex flex-col items-end gap-1.5">
                          {(() => {
                            // Calculate target based on duration
                            let targetDays = 26; // Default monthly
                            if (reportStartDate && reportEndDate) {
                              const diffTime = Math.abs(new Date(reportEndDate).getTime() - new Date(reportStartDate).getTime());
                              const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
                              // Approximate working days (total days * 6/7)
                              targetDays = Math.max(1, Math.floor(diffDays * 0.85));
                            }
                            const percentage = Math.min(100, Math.round((stat.daysPresent / targetDays) * 100));
                            
                            return (
                              <>
                                <div className="w-24 bg-neutral-100 dark:bg-neutral-800 rounded-full h-1.5 overflow-hidden">
                                  <div 
                                    className={`h-full rounded-full ${percentage > 80 ? 'bg-emerald-500' : percentage > 50 ? 'bg-amber-500' : 'bg-rose-500'}`}
                                    style={{ width: `${percentage}%` }}
                                  />
                                </div>
                                <span className="text-[10px] font-black uppercase tracking-tighter text-neutral-500">
                                  {percentage}% of {targetDays}d Goal
                                </span>
                              </>
                            );
                          })()}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ) : (
          <>
            {/* Analytics Section */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Main User Stats */}
              <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-white dark:bg-neutral-900 p-6 rounded-3xl border border-neutral-200/80 dark:border-neutral-800 shadow-2xs space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black uppercase tracking-widest text-neutral-400">Hours Logged Today</span>
                    <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">Protocol Active</span>
                  </div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-4xl font-black text-neutral-900 dark:text-neutral-100">{totalUserHoursToday.toFixed(1)}h</span>
                    <span className="text-sm text-neutral-500">of {companyShift?.durationHours || 12}h daily target</span>
                  </div>
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-[11px] font-bold">
                      <span className="text-neutral-500">Progress</span>
                      <span className="text-emerald-600">{Math.round((totalUserHoursToday / (companyShift?.durationHours || 12)) * 100)}%</span>
                    </div>
                    <div className="w-full bg-neutral-100 dark:bg-neutral-800 rounded-full h-2.5 overflow-hidden">
                      <div 
                        className="bg-emerald-500 h-full rounded-full transition-all duration-500 shadow-[0_0_8px_rgba(16,185,129,0.4)]"
                        style={{ width: `${Math.min(100, (totalUserHoursToday / (companyShift?.durationHours || 12)) * 100)}%` }}
                      />
                    </div>
                  </div>
                  <p className="text-[10px] text-neutral-400 leading-relaxed italic">
                    Overtime protocol automatically triggers after {companyShift?.durationHours || 12} hours.
                  </p>
                </div>

                <div className="bg-white dark:bg-neutral-900 p-6 rounded-3xl border border-neutral-200/80 dark:border-neutral-800 shadow-2xs space-y-4">
                  <span className="text-[10px] font-black uppercase tracking-widest text-neutral-400">Shift Availability</span>
                  <div className="flex items-center gap-3">
                    {currentUser.isPunchedIn ? (
                      <div className="flex items-center gap-3">
                        <div className="relative">
                          <div className="w-12 h-12 rounded-2xl bg-emerald-100 dark:bg-emerald-950/50 flex items-center justify-center text-emerald-600">
                            <Clock className="w-7 h-7" />
                          </div>
                          <div className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 border-2 border-white dark:border-neutral-900 rounded-full animate-ping" />
                          <div className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 border-2 border-white dark:border-neutral-900 rounded-full" />
                        </div>
                        <div>
                          <span className="text-lg font-black text-neutral-900 dark:text-neutral-100 block">On Shift</span>
                          <span className="text-xs text-emerald-600 font-bold uppercase tracking-tight">Active Operation</span>
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-2xl bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center text-neutral-400">
                          <Clock className="w-7 h-7" />
                        </div>
                        <div>
                          <span className="text-lg font-black text-neutral-900 dark:text-neutral-100 block">Off Duty</span>
                          <span className="text-xs text-neutral-400 font-bold uppercase tracking-tight">System Standby</span>
                        </div>
                      </div>
                    )}
                  </div>
                  <div className="pt-2 grid grid-cols-2 gap-2">
                    <div className="p-2 rounded-xl bg-neutral-50 dark:bg-neutral-800/50 border border-neutral-100 dark:border-neutral-800">
                      <span className="text-[9px] font-bold text-neutral-400 uppercase block">First In</span>
                      <span className="text-xs font-black text-neutral-800 dark:text-neutral-200">{filteredLogs.find(l => l.date === filterDate)?.punchIn ? formatDateTime(filteredLogs.find(l => l.date === filterDate)?.punchIn) : '--:--'}</span>
                    </div>
                    <div className="p-2 rounded-xl bg-neutral-50 dark:bg-neutral-800/50 border border-neutral-100 dark:border-neutral-800">
                      <span className="text-[9px] font-bold text-neutral-400 uppercase block">Last Out</span>
                      <span className="text-xs font-black text-neutral-800 dark:text-neutral-200">{filteredLogs.find(l => l.date === filterDate)?.punchOut ? formatDateTime(filteredLogs.find(l => l.date === filterDate)?.punchOut) : '--:--'}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Activity Mini-Chart (Last 7 Days) */}
              <div className="bg-white dark:bg-neutral-900 p-6 rounded-3xl border border-neutral-200/80 dark:border-neutral-800 shadow-2xs space-y-4">
                <span className="text-[10px] font-black uppercase tracking-widest text-neutral-400">Last 7 Days Activity</span>
                <div className="flex items-end justify-between h-32 gap-1 px-1">
                  {dailyStats.map((stat, i) => (
                    <div key={i} className="flex-1 flex flex-col items-center gap-1.5 group cursor-help">
                      <div className="relative w-full flex items-end justify-center h-full">
                        <div 
                          className="w-full bg-emerald-500/20 group-hover:bg-emerald-500/40 transition-colors rounded-t-md relative"
                          style={{ height: `${(stat.hours / maxHours) * 100}%` }}
                        >
                          {stat.hours > 0 && (
                            <div className="absolute -top-6 left-1/2 -translate-x-1/2 px-1.5 py-0.5 rounded bg-neutral-900 text-white text-[9px] font-bold opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10">
                              {stat.hours.toFixed(1)}h
                            </div>
                          )}
                        </div>
                      </div>
                      <span className="text-[9px] font-bold text-neutral-400 uppercase">{stat.date.split('-')[2]}</span>
                    </div>
                  ))}
                </div>
                <div className="flex items-center justify-between pt-2 border-t border-neutral-100 dark:border-neutral-800">
                  <span className="text-[10px] text-neutral-500 font-medium italic">Daily Log Hours</span>
                  <span className="text-[10px] font-bold text-emerald-600 uppercase">Weekly View</span>
                </div>
              </div>
            </div>

            {/* Daily Logs Filter Bar */}
            <div className="bg-white dark:bg-neutral-900 p-4 rounded-2xl border border-neutral-200/80 dark:border-neutral-800 shadow-sm flex flex-wrap items-center gap-4">
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-neutral-400" />
                <span className="text-xs font-bold text-neutral-500 uppercase">Filters:</span>
              </div>

              <div className="flex flex-col gap-1">
                <span className="text-[9px] font-bold text-neutral-400 uppercase ml-1">Date</span>
                <input
                  type="date"
                  value={filterDate}
                  onChange={(e) => setFilterDate(e.target.value)}
                  className="h-9 rounded-lg bg-neutral-100 dark:bg-neutral-800 px-3 text-xs font-bold focus:outline-none"
                />
              </div>

              {isSuperAdmin && (
                <>
                  <div className="flex flex-col gap-1">
                    <span className="text-[9px] font-bold text-neutral-400 uppercase ml-1">Employee</span>
                    <select
                      value={filterEmployee}
                      onChange={(e) => setFilterEmployee(e.target.value)}
                      className="h-9 rounded-lg bg-neutral-100 dark:bg-neutral-800 px-3 text-xs font-bold focus:outline-none"
                    >
                      <option value="all">All Members</option>
                      {employees.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
                    </select>
                  </div>

                  <div className="flex flex-col gap-1">
                    <span className="text-[9px] font-bold text-neutral-400 uppercase ml-1">Department</span>
                    <select
                      value={filterDept}
                      onChange={(e) => setFilterDept(e.target.value)}
                      className="h-9 rounded-lg bg-neutral-100 dark:bg-neutral-800 px-3 text-xs font-bold focus:outline-none"
                    >
                      <option value="all">All Departments</option>
                      {departments.map(d => <option key={d} value={d}>{d}</option>)}
                    </select>
                  </div>
                </>
              )}

              <div className="flex flex-col gap-1">
                <span className="text-[9px] font-bold text-neutral-400 uppercase ml-1">Shift Status</span>
                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value as any)}
                  className="h-9 rounded-lg bg-neutral-100 dark:bg-neutral-800 px-3 text-xs font-bold focus:outline-none"
                >
                  <option value="all">All Status</option>
                  <option value="on-duty">On Duty (Active)</option>
                  <option value="off-duty">Off Duty (Finished)</option>
                </select>
              </div>

              <button
                onClick={() => {
                  setFilterDate(new Date().toISOString().split('T')[0]);
                  setFilterEmployee('all');
                  setFilterDept('all');
                  setFilterStatus('all');
                }}
                className="mt-auto h-9 px-4 text-xs font-bold text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-lg transition-colors"
              >
                Reset
              </button>
            </div>

            {/* Protocol Banner */}
            <div className="bg-gradient-to-r from-emerald-600 to-teal-700 p-1 rounded-2xl shadow-md">
              <div className="bg-white/10 backdrop-blur-sm px-6 py-4 rounded-xl flex flex-col md:flex-row items-center justify-between gap-4 border border-white/20">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center text-white">
                    <AlertCircle className="w-6 h-6" />
                  </div>
                  <div className="text-white">
                    <h3 className="text-sm font-bold uppercase tracking-wider">Shift Timing Protocol</h3>
                    <p className="text-xs text-white/80">Default 12-Hour Daily Roster: <strong>{companyShift?.startTime12 || '10:30 AM'} to {companyShift?.endTime12 || '06:30 PM'}</strong></p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-right hidden sm:block">
                    <span className="text-[10px] text-white/60 uppercase font-black block">Logged by</span>
                    <span className="text-xs font-bold text-white">Sabyasachi (CEO)</span>
                  </div>
                  <ArrowRight className="w-5 h-5 text-white/40" />
                </div>
              </div>
            </div>

            {/* Logs Table */}
            <div className="bg-white dark:bg-neutral-900 rounded-3xl border border-neutral-200/80 dark:border-neutral-800 shadow-2xs">
              <div className="overflow-x-auto scrollbar-thin scrollbar-thumb-neutral-200 dark:scrollbar-thumb-neutral-800">
                <table className="w-full min-w-[900px] text-left border-collapse">
                  <thead>
                    <tr className="bg-neutral-50 dark:bg-neutral-800/50 text-[10px] font-black uppercase tracking-widest text-neutral-500 border-b border-neutral-100 dark:border-neutral-800">
                      <th className="px-6 py-4">Employee</th>
                      <th className="px-6 py-4 text-center">Date</th>
                      <th className="px-6 py-4 text-center">Arrival (In)</th>
                      <th className="px-6 py-4 text-center">Departure (Out)</th>
                      <th className="px-6 py-4 text-center">Location (Lat/Lng)</th>
                      <th className="px-6 py-4 text-center">Total Duration</th>
                      <th className="px-6 py-4 text-right">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800">
                    {filteredLogs.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="px-6 py-12 text-center">
                          <div className="flex flex-col items-center gap-2 text-neutral-400">
                            <AlertCircle className="w-10 h-10 stroke-1" />
                            <p className="text-sm font-medium">No attendance logs found for the selected criteria.</p>
                          </div>
                        </td>
                      </tr>
                    ) : (
                      filteredLogs.map((log) => (
                        <tr key={log.id} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-800/30 transition-colors">
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-lg bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center font-bold text-xs text-neutral-700 dark:text-neutral-300">
                                {(log.employeeName || '?').charAt(0)}
                              </div>
                              <span className="text-sm font-bold text-neutral-900 dark:text-neutral-100">{log.employeeName}</span>
                            </div>
                          </td>
                          <td className="px-6 py-4 text-center text-sm font-mono text-neutral-500">
                            {log.date}
                          </td>
                          <td className="px-6 py-4 text-center">
                            <div className="flex flex-col items-center gap-1">
                              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 text-xs font-bold font-mono">
                                {formatDateTime(log.punchIn)}
                              </span>
                              {log.isLate && (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-rose-100 dark:bg-rose-950 text-[10px] font-black uppercase tracking-tight text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-800 animate-pulse mt-1">
                                  <AlertTriangle className="w-3 h-3" />
                                  LATE ARRIVAL
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="px-6 py-4 text-center">
                            {log.punchOut ? (
                              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 dark:bg-amber-950 text-amber-700 dark:text-amber-300 text-xs font-bold font-mono">
                                {formatDateTime(log.punchOut)}
                              </span>
                            ) : (
                              <span className="text-[10px] font-black text-neutral-400 uppercase tracking-widest italic">In Progress</span>
                            )}
                          </td>
                          <td className="px-6 py-4 text-center">
                            <div className="flex flex-col gap-1 items-center">
                              {log.punchInLat !== undefined && log.punchInLng !== undefined ? (
                                <div className="flex flex-col text-[9px] text-neutral-500 font-mono">
                                  <span className="text-[8px] font-bold text-neutral-400 uppercase">In:</span>
                                  <span>{Number(log.punchInLat).toFixed(4)}, {Number(log.punchInLng).toFixed(4)}</span>
                                </div>
                              ) : (
                                <div className="flex flex-col text-[8px] text-neutral-300 font-bold uppercase italic">
                                  <span>In: N/A</span>
                                  <span className="text-[7px] font-medium lowercase">(Check Browser Permission)</span>
                                </div>
                              )}
                              {log.punchOutLat !== undefined && log.punchOutLng !== undefined ? (
                                <div className="flex flex-col text-[9px] text-neutral-500 font-mono">
                                  <span className="text-[8px] font-bold text-neutral-400 uppercase">Out:</span>
                                  <span>{Number(log.punchOutLat).toFixed(4)}, {Number(log.punchOutLng).toFixed(4)}</span>
                                </div>
                              ) : log.punchOut ? (
                                <div className="flex flex-col text-[8px] text-neutral-300 font-bold uppercase italic">
                                  <span>Out: N/A</span>
                                  <span className="text-[7px] font-medium lowercase">(Check Browser Permission)</span>
                                </div>
                              ) : null}
                            </div>
                          </td>
                          <td className="px-6 py-4 text-center text-sm font-black text-neutral-800 dark:text-neutral-200 font-mono">
                            {calculateDuration(log.punchIn, log.punchOut)}
                          </td>
                          <td className="px-6 py-4 text-right">
                            <div className="flex items-center justify-end gap-2">
                              {log.punchOut ? (
                                <div className="inline-flex items-center gap-1 text-emerald-600 font-bold text-[10px] uppercase tracking-wider">
                                  <CheckCircle2 className="w-3 h-3" />
                                  Completed
                                </div>
                              ) : (
                                <div className="inline-flex items-center gap-1 text-amber-600 font-bold text-[10px] uppercase tracking-wider">
                                  <div className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
                                  Active
                                </div>
                              )}
                              
                              {isSuperAdmin && (
                                <div className="flex items-center gap-1 ml-2 pl-2 border-l border-neutral-200 dark:border-neutral-800">
                                  <button
                                    onClick={() => handleOpenEdit(log)}
                                    className="p-1.5 rounded-lg text-neutral-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 transition cursor-pointer"
                                    title="Edit Attendance Record"
                                  >
                                    <Pencil className="w-3.5 h-3.5" />
                                  </button>
                                  <button
                                    onClick={() => {
                                      if (confirm('Executive Directive: Are you sure you want to PERMANENTLY DELETE this attendance log? This action cannot be undone.')) {
                                        onDeleteAttendanceLog(log.id);
                                      }
                                    }}
                                    className="p-1.5 rounded-lg text-neutral-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition cursor-pointer"
                                    title="Delete Attendance Record"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}
      </div>
      {/* 📥 Export Attendance Modal */}
      {isExportModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-neutral-950/80 backdrop-blur-sm" onClick={() => setIsExportModalOpen(false)} />
          <div className="relative w-full max-w-md bg-white dark:bg-neutral-900 rounded-[32px] border border-neutral-200 dark:border-neutral-800 shadow-2xl p-8 animate-in zoom-in-95 duration-300">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-emerald-100 dark:bg-emerald-950/30 flex items-center justify-center text-emerald-600">
                  <Download className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-neutral-900 dark:text-neutral-100 uppercase italic">Export Attendance</h3>
                  <p className="text-xs text-neutral-500 font-medium">Generate filtered CSV report</p>
                </div>
              </div>
              <button 
                onClick={() => setIsExportModalOpen(false)}
                className="p-2 rounded-xl hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
              >
                <X className="w-5 h-5 text-neutral-400" />
              </button>
            </div>

            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-neutral-400 uppercase tracking-widest ml-1">Start Date</label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-neutral-400" />
                    <input 
                      type="date"
                      value={exportStartDate}
                      onChange={(e) => setExportStartDate(e.target.value)}
                      className="w-full pl-9 pr-4 h-11 rounded-2xl bg-neutral-50 dark:bg-neutral-800 border border-neutral-100 dark:border-neutral-800 text-xs font-bold focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                    />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-neutral-400 uppercase tracking-widest ml-1">End Date</label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-neutral-400" />
                    <input 
                      type="date"
                      value={exportEndDate}
                      onChange={(e) => setExportEndDate(e.target.value)}
                      className="w-full pl-9 pr-4 h-11 rounded-2xl bg-neutral-50 dark:bg-neutral-800 border border-neutral-100 dark:border-neutral-800 text-xs font-bold focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                    />
                  </div>
                </div>
              </div>

              {isSuperAdmin && (
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-neutral-400 uppercase tracking-widest ml-1">Select Employee</label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-neutral-400" />
                    <select
                      value={exportEmployeeId}
                      onChange={(e) => setExportEmployeeId(e.target.value)}
                      className="w-full pl-9 pr-4 h-11 rounded-2xl bg-neutral-50 dark:bg-neutral-800 border border-neutral-100 dark:border-neutral-800 text-xs font-bold focus:outline-none focus:ring-2 focus:ring-emerald-500/20 appearance-none"
                    >
                      <option value="all">All Employees</option>
                      {employees.map(emp => (
                        <option key={emp.id} value={emp.id}>{emp.name}</option>
                      ))}
                    </select>
                  </div>
                </div>
              )}

              <div className="pt-4 flex flex-col gap-3">
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => {
                      onExportLogs({
                        startDate: exportStartDate,
                        endDate: exportEndDate,
                        employeeId: exportEmployeeId
                      });
                      setIsExportModalOpen(false);
                    }}
                    className="w-full py-4 rounded-[20px] bg-indigo-600 text-white font-black uppercase tracking-widest text-xs shadow-xl shadow-indigo-600/20 hover:bg-indigo-500 transition-all active:scale-95 flex items-center justify-center gap-2"
                  >
                    <FileSpreadsheet className="w-4 h-4" />
                    CSV
                  </button>
                  <button
                    onClick={() => {
                      onExportPdf({
                        startDate: exportStartDate,
                        endDate: exportEndDate,
                        employeeId: exportEmployeeId
                      });
                      setIsExportModalOpen(false);
                    }}
                    className="w-full py-4 rounded-[20px] bg-rose-600 text-white font-black uppercase tracking-widest text-xs shadow-xl shadow-rose-600/20 hover:bg-rose-500 transition-all active:scale-95 flex items-center justify-center gap-2"
                  >
                    <FileText className="w-4 h-4" />
                    PDF
                  </button>
                </div>
                <button
                  onClick={() => setIsExportModalOpen(false)}
                  className="w-full py-4 rounded-[20px] bg-neutral-100 dark:bg-neutral-800 text-neutral-500 dark:text-neutral-400 font-black uppercase tracking-widest text-xs hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-all"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit Attendance Modal */}
      {isEditModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/70 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-md bg-white dark:bg-neutral-900 rounded-3xl border border-neutral-200 dark:border-neutral-800 shadow-2xl overflow-hidden">
            <div className="p-6 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-indigo-600" />
                <h3 className="text-lg font-black text-neutral-900 dark:text-neutral-100">Edit Attendance Record</h3>
              </div>
              <button onClick={() => setIsEditModalOpen(false)} className="p-2 text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-100 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <form onSubmit={handleSaveEdit} className="p-6 space-y-4">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-neutral-400 uppercase ml-1">Staff Member</label>
                <div className="w-full h-11 rounded-xl bg-neutral-100 dark:bg-neutral-800 px-4 flex items-center text-sm font-bold text-neutral-500">
                  {editingLog?.employeeName}
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-neutral-400 uppercase ml-1">Log Date</label>
                <input
                  type="date"
                  value={editDate}
                  onChange={(e) => setEditDate(e.target.value)}
                  className="w-full h-11 rounded-xl bg-neutral-100 dark:bg-neutral-800 px-4 text-sm font-medium text-neutral-900 dark:text-neutral-100 outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-neutral-400 uppercase ml-1">Punch In Time</label>
                  <input
                    type="datetime-local"
                    value={editPunchIn}
                    onChange={(e) => setEditPunchIn(e.target.value)}
                    className="w-full h-11 rounded-xl bg-neutral-100 dark:bg-neutral-800 px-4 text-xs font-medium text-neutral-900 dark:text-neutral-100 outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-neutral-400 uppercase ml-1">Punch Out Time</label>
                  <input
                    type="datetime-local"
                    value={editPunchOut}
                    onChange={(e) => setEditPunchOut(e.target.value)}
                    className="w-full h-11 rounded-xl bg-neutral-100 dark:bg-neutral-800 px-4 text-xs font-medium text-neutral-900 dark:text-neutral-100 outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-neutral-400 uppercase ml-1">Punch In Lat</label>
                  <input
                    type="number"
                    step="any"
                    value={editPunchInLat}
                    onChange={(e) => setEditPunchInLat(e.target.value)}
                    placeholder="Latitude"
                    className="w-full h-11 rounded-xl bg-neutral-100 dark:bg-neutral-800 px-4 text-xs font-medium text-neutral-900 dark:text-neutral-100 outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-neutral-400 uppercase ml-1">Punch In Lng</label>
                  <input
                    type="number"
                    step="any"
                    value={editPunchInLng}
                    onChange={(e) => setEditPunchInLng(e.target.value)}
                    placeholder="Longitude"
                    className="w-full h-11 rounded-xl bg-neutral-100 dark:bg-neutral-800 px-4 text-xs font-medium text-neutral-900 dark:text-neutral-100 outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-neutral-400 uppercase ml-1">Punch Out Lat</label>
                  <input
                    type="number"
                    step="any"
                    value={editPunchOutLat}
                    onChange={(e) => setEditPunchOutLat(e.target.value)}
                    placeholder="Latitude"
                    className="w-full h-11 rounded-xl bg-neutral-100 dark:bg-neutral-800 px-4 text-xs font-medium text-neutral-900 dark:text-neutral-100 outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-neutral-400 uppercase ml-1">Punch Out Lng</label>
                  <input
                    type="number"
                    step="any"
                    value={editPunchOutLng}
                    onChange={(e) => setEditPunchOutLng(e.target.value)}
                    placeholder="Longitude"
                    className="w-full h-11 rounded-xl bg-neutral-100 dark:bg-neutral-800 px-4 text-xs font-medium text-neutral-900 dark:text-neutral-100 outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div className="flex items-center gap-3 p-3 rounded-2xl bg-neutral-50 dark:bg-neutral-800/50 border border-neutral-100 dark:border-neutral-800">
                <input
                  type="checkbox"
                  id="editIsLate"
                  checked={editIsLate}
                  onChange={(e) => setEditIsLate(e.target.checked)}
                  className="w-4 h-4 rounded text-rose-600 focus:ring-rose-500 cursor-pointer"
                />
                <label htmlFor="editIsLate" className="text-xs font-bold text-neutral-700 dark:text-neutral-300 cursor-pointer">
                  Mark as LATE ARRIVAL (Protocol Violation)
                </label>
              </div>

              <div className="pt-4 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsEditModalOpen(false)}
                  className="px-6 py-2.5 rounded-xl text-sm font-bold text-neutral-500 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-8 py-2.5 rounded-xl bg-indigo-600 text-white text-sm font-black shadow-lg hover:bg-indigo-700 transition active:scale-95 cursor-pointer"
                >
                  Save Modifications
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
