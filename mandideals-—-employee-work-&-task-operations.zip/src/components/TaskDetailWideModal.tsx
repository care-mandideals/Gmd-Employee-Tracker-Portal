import React, { useState } from 'react';
import {
  X,
  Clock,
  Calendar,
  User,
  Building2,
  Check,
  CheckCircle2,
  ListTodo,
  Pencil,
  Trash2,
  Bell,
  Copy,
  CheckCheck,
  Flame,
  FileText,
  StickyNote,
  AlertCircle,
  Plus,
  ArrowRight,
  Sparkles,
  Star
} from 'lucide-react';
import { Task, TaskPriority, TaskStatus, getTaskCategory } from '../types/task';
import { formatTimeSlot } from '../data/initialTasks';
import { playChime } from '../services/notificationService';

interface TaskDetailWideModalProps {
  task: Task | null;
  isOpen: boolean;
  onClose: () => void;
  onUpdateStatus: (id: string, status: TaskStatus) => void;
  onUpdateDescription: (id: string, description: string) => void;
  onToggleSubtask: (taskId: string, subtaskId: string) => void;
  onAddSubtask?: (taskId: string, title: string) => void;
  onEditFullTask: (task: Task) => void;
  onDeleteTask: (id: string) => void;
  isSuperAdmin?: boolean;
  onUpdateRating?: (id: string, rating: number) => void;
}

export const TaskDetailWideModal: React.FC<TaskDetailWideModalProps> = ({
  task,
  isOpen,
  onClose,
  onUpdateStatus,
  onUpdateDescription,
  onToggleSubtask,
  onAddSubtask,
  onEditFullTask,
  onDeleteTask,
  isSuperAdmin,
  onUpdateRating,
}) => {
  const [isEditingNote, setIsEditingNote] = useState(false);
  const [noteDraft, setNoteDraft] = useState('');
  const [copied, setCopied] = useState(false);
  const [newSubtaskInput, setNewSubtaskInput] = useState('');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  if (!isOpen || !task) return null;

  const currentCategory = getTaskCategory(task);

  const handleStartEditNote = () => {
    setNoteDraft(task.description || '');
    setIsEditingNote(true);
  };

  const handleSaveNote = () => {
    onUpdateDescription(task.id, noteDraft.trim());
    setIsEditingNote(false);
  };

  const handleCopyNote = async () => {
    if (!task.description) return;
    try {
      await navigator.clipboard.writeText(task.description);
      setCopied(true);
      playChime('complete');
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy note', err);
    }
  };

  const handleCategoryChange = (newStatus: TaskStatus) => {
    onUpdateStatus(task.id, newStatus);
  };

  const handleCreateSubtask = (e: React.FormEvent) => {
    e.preventDefault();
    if (newSubtaskInput.trim() && onAddSubtask) {
      onAddSubtask(task.id, newSubtaskInput.trim());
      setNewSubtaskInput('');
    }
  };

  const noteWordCount = task.description ? task.description.trim().split(/\s+/).filter(Boolean).length : 0;
  const noteCharCount = task.description ? task.description.length : 0;

  const completedSubtasks = (task.subtasks || []).filter((s) => s.completed).length;
  const totalSubtasks = (task.subtasks || []).length;
  const subtaskProgress = totalSubtasks > 0 ? Math.round((completedSubtasks / totalSubtasks) * 100) : 0;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-neutral-950/75 backdrop-blur-md overflow-y-auto animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        className="w-full max-w-4xl lg:max-w-5xl rounded-3xl border border-neutral-200/90 dark:border-neutral-800 bg-white dark:bg-neutral-900 shadow-2xl overflow-hidden my-auto flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* 1. TOP HEADER & BREADCRUMBS */}
        <div className="px-6 py-4 border-b border-neutral-200/80 dark:border-neutral-800/80 bg-neutral-50/70 dark:bg-neutral-850/60 flex items-center justify-between gap-3 shrink-0">
          <div className="flex flex-wrap items-center gap-2 text-xs font-semibold text-neutral-500 dark:text-neutral-400">
            <span className="flex items-center gap-1">
              <Building2 className="w-3.5 h-3.5 text-neutral-400" />
              {task.department}
            </span>
            <span className="text-neutral-300 dark:text-neutral-700">/</span>
            <span className="flex items-center gap-1 font-bold text-neutral-800 dark:text-neutral-200">
              <User className="w-3.5 h-3.5 text-emerald-600" />
              {task.employeeName}
            </span>
            <span className="text-neutral-300 dark:text-neutral-700">/</span>
            <span className="font-mono text-neutral-400 text-[11px]">
              Task #{task.id.slice(-6)}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => onEditFullTask(task)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-xs font-bold text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-750 transition shadow-2xs cursor-pointer"
              title="Open full edit form"
            >
              <Pencil className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Edit Task</span>
            </button>

            {showDeleteConfirm ? (
              <div className="flex items-center gap-1 bg-rose-50 dark:bg-rose-950 p-1 rounded-xl border border-rose-200 dark:border-rose-900 animate-in zoom-in duration-150">
                <button
                  onClick={() => {
                    onDeleteTask(task.id);
                    onClose();
                  }}
                  className="px-2.5 py-1 rounded-lg bg-rose-600 text-white text-xs font-bold hover:bg-rose-700 transition cursor-pointer"
                >
                  Confirm Delete
                </button>
                <button
                  onClick={() => setShowDeleteConfirm(false)}
                  className="px-2 py-1 text-xs text-neutral-500 hover:text-neutral-800 cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            ) : (
              <button
                onClick={() => setShowDeleteConfirm(true)}
                className="p-1.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition shadow-2xs cursor-pointer"
                title="Delete this task"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}

            <button
              onClick={onClose}
              className="p-1.5 rounded-xl text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition cursor-pointer"
              title="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* 2. THREE-CATEGORY STATUS SWITCHER BAR (To Do, In Progress, Completed) */}
        <div className="px-6 py-3.5 bg-neutral-100/70 dark:bg-neutral-900 border-b border-neutral-200/90 dark:border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-xs font-extrabold uppercase tracking-wider text-neutral-500 dark:text-neutral-400">
              Category & Status:
            </span>
            <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-black uppercase tracking-wider ${
              currentCategory === 'todo'
                ? 'bg-blue-100 text-blue-900 dark:bg-blue-950 dark:text-blue-300 border border-blue-300 dark:border-blue-800'
                : currentCategory === 'in_progress'
                ? 'bg-amber-100 text-amber-900 dark:bg-amber-950 dark:text-amber-300 border border-amber-300 dark:border-amber-800'
                : 'bg-emerald-100 text-emerald-900 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800'
            }`}>
              {currentCategory === 'todo' && '📋 To Do'}
              {currentCategory === 'in_progress' && '⚡ In Progress'}
              {currentCategory === 'completed' && '✅ Completed'}
            </span>
          </div>

          {/* Interactive 3-Category buttons */}
          <div className="flex items-center gap-1.5 bg-white dark:bg-neutral-800 p-1 rounded-2xl border border-neutral-200 dark:border-neutral-700 shadow-2xs self-start sm:self-auto">
            <button
              onClick={() => handleCategoryChange('todo')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                currentCategory === 'todo'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-700'
              }`}
            >
              <ListTodo className="w-3.5 h-3.5" />
              <span>To Do</span>
            </button>

            <button
              onClick={() => handleCategoryChange('in_progress')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                currentCategory === 'in_progress'
                  ? 'bg-amber-500 text-slate-950 shadow-xs'
                  : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-700'
              }`}
            >
              <Flame className="w-3.5 h-3.5" />
              <span>In Progress</span>
            </button>

            <button
              onClick={() => handleCategoryChange('completed')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                currentCategory === 'completed'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-700'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Completed</span>
            </button>
          </div>
        </div>

        {/* 3. MAIN WIDE CONTENT BODY (Scrollable) */}
        <div className="overflow-y-auto p-6 sm:p-8 flex-1">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* LEFT / PRIMARY COLUMN (Title, Notes Box, Subtasks) */}
            <div className="lg:col-span-8 space-y-6">
              
              {/* Task Title */}
              <div className="space-y-2">
                <h1 className="text-xl sm:text-2xl font-black text-neutral-900 dark:text-neutral-100 tracking-tight leading-snug">
                  {task.title}
                </h1>
                
                <div className="flex flex-wrap items-center gap-3 text-xs text-neutral-500 dark:text-neutral-400">
                  <span className="font-semibold text-neutral-700 dark:text-neutral-300">
                    Logged by {task.employeeName} {task.employeeRole ? `(${task.employeeRole})` : ''}
                  </span>
                  <span>·</span>
                  <span>Created {new Date(task.createdAt).toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}</span>
                </div>
              </div>

              {/* CORE NOTE SECTION: Prominently displayed in wide format */}
              <div className="rounded-3xl border-2 border-amber-300/80 dark:border-amber-700/70 bg-gradient-to-br from-amber-50/60 via-amber-50/20 to-white dark:from-neutral-850 dark:via-neutral-900 dark:to-neutral-900 p-5 sm:p-6 shadow-xs space-y-3.5">
                <div className="flex items-center justify-between gap-3 pb-3 border-b border-amber-200/70 dark:border-neutral-800">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold shadow-2xs">
                      <StickyNote className="w-4 h-4 stroke-[2.2]" />
                    </div>
                    <div>
                      <h2 className="text-sm font-black text-neutral-900 dark:text-neutral-100 uppercase tracking-wider">
                        Task Note & Deliverable Details
                      </h2>
                      <p className="text-[11px] text-neutral-500 dark:text-neutral-400">
                        {noteWordCount > 0
                          ? `${noteWordCount} words · ${noteCharCount} characters`
                          : 'No note pasted yet for this task'}
                      </p>
                    </div>
                  </div>

                  {/* Note Action Buttons */}
                  <div className="flex items-center gap-1.5">
                    {task.description && !isEditingNote && (
                      <button
                        onClick={handleCopyNote}
                        className="flex items-center gap-1 px-3 py-1.5 rounded-xl border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-700 text-xs font-bold transition shadow-2xs cursor-pointer"
                        title="Copy note text to clipboard"
                      >
                        {copied ? (
                          <>
                            <CheckCheck className="w-3.5 h-3.5 text-emerald-600" />
                            <span className="text-emerald-600">Copied!</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5 text-neutral-500" />
                            <span>Copy Note</span>
                          </>
                        )}
                      </button>
                    )}

                    {!isEditingNote && (
                      <button
                        onClick={handleStartEditNote}
                        className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-extrabold transition shadow-xs cursor-pointer"
                      >
                        <Pencil className="w-3.5 h-3.5" />
                        <span>{task.description ? 'Edit Note' : '+ Paste Note'}</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Note Content Display / Inline Editor */}
                {isEditingNote ? (
                  <div className="space-y-3 animate-in fade-in duration-100">
                    <textarea
                      rows={6}
                      value={noteDraft}
                      onChange={(e) => setNoteDraft(e.target.value)}
                      placeholder="Paste instructions, trading lot notes, farmer handover details, or deliverable work logs..."
                      className="w-full rounded-2xl border border-amber-400 dark:border-amber-600 bg-white dark:bg-neutral-900 p-4 text-sm sm:text-base text-neutral-900 dark:text-neutral-100 leading-relaxed font-sans focus:outline-none focus:ring-2 focus:ring-amber-500"
                      autoFocus
                    />
                    <div className="flex items-center justify-end gap-2">
                      <button
                        type="button"
                        onClick={() => setIsEditingNote(false)}
                        className="px-3.5 py-1.5 text-xs font-semibold text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        onClick={handleSaveNote}
                        className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-neutral-900 dark:bg-amber-500 text-white dark:text-slate-950 text-xs font-extrabold shadow-xs hover:bg-neutral-800 transition cursor-pointer"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Save Note</span>
                      </button>
                    </div>
                  </div>
                ) : task.description ? (
                  /* Prominent, readable note card with full formatting */
                  <div className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200/90 dark:border-neutral-800 text-sm sm:text-base text-neutral-800 dark:text-neutral-100 leading-relaxed font-sans whitespace-pre-wrap select-text max-h-[380px] overflow-y-auto shadow-2xs">
                    {task.description}
                  </div>
                ) : (
                  /* Clean Empty State */
                  <div className="py-8 px-4 text-center rounded-2xl border border-dashed border-amber-300 dark:border-neutral-800 bg-white/60 dark:bg-neutral-900/40 space-y-2">
                    <p className="text-xs font-semibold text-neutral-600 dark:text-neutral-400">
                      No notes or deliverable instructions pasted yet.
                    </p>
                    <button
                      onClick={handleStartEditNote}
                      className="text-xs font-bold text-amber-600 dark:text-amber-400 hover:underline cursor-pointer"
                    >
                      + Paste note or handover details now
                    </button>
                  </div>
                )}
              </div>

              {/* Subtasks / Checklist Section */}
              <div className="rounded-3xl border border-neutral-200/90 dark:border-neutral-800 bg-white dark:bg-neutral-900 p-5 sm:p-6 space-y-4 shadow-xs">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-900 dark:text-neutral-100">
                      Deliverable Subtasks & Checklist
                    </h3>
                    <span className="font-mono text-xs px-2 py-0.5 rounded-full bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300 font-bold">
                      {completedSubtasks} / {totalSubtasks}
                    </span>
                  </div>

                  {totalSubtasks > 0 && (
                    <span className="text-xs font-mono font-bold text-emerald-600 dark:text-emerald-400">
                      {subtaskProgress}% done
                    </span>
                  )}
                </div>

                {/* Progress bar */}
                {totalSubtasks > 0 && (
                  <div className="w-full bg-neutral-100 dark:bg-neutral-800 rounded-full h-1.5 overflow-hidden">
                    <div
                      className="bg-emerald-600 h-1.5 rounded-full transition-all duration-300"
                      style={{ width: `${subtaskProgress}%` }}
                    />
                  </div>
                )}

                {/* Subtask items list */}
                <div className="space-y-2">
                  {(task.subtasks || []).map((subtask) => (
                    <label
                      key={subtask.id}
                      className="flex items-start gap-3 p-2.5 rounded-xl border border-neutral-100 dark:border-neutral-800 hover:bg-neutral-50 dark:hover:bg-neutral-850/60 transition cursor-pointer select-none"
                    >
                      <input
                        type="checkbox"
                        checked={subtask.completed}
                        onChange={() => onToggleSubtask(task.id, subtask.id)}
                        className="mt-0.5 h-4 w-4 rounded border-neutral-300 text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                      />
                      <span
                        className={`text-xs sm:text-sm ${
                          subtask.completed
                            ? 'line-through text-neutral-400 dark:text-neutral-500'
                            : 'text-neutral-800 dark:text-neutral-200 font-medium'
                        }`}
                      >
                        {subtask.title}
                      </span>
                    </label>
                  ))}
                </div>

                {/* Add new subtask input */}
                {onAddSubtask && (
                  <form onSubmit={handleCreateSubtask} className="flex items-center gap-2 pt-1">
                    <input
                      type="text"
                      placeholder="Add subtask item (e.g. Verify moisture certificate)..."
                      value={newSubtaskInput}
                      onChange={(e) => setNewSubtaskInput(e.target.value)}
                      className="flex-1 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 px-3.5 py-1.5 text-xs text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    />
                    <button
                      type="submit"
                      disabled={!newSubtaskInput.trim()}
                      className="flex items-center gap-1 px-3.5 py-1.5 rounded-xl bg-neutral-900 dark:bg-emerald-600 disabled:opacity-50 text-white text-xs font-bold hover:bg-neutral-800 transition cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add</span>
                    </button>
                  </form>
                )}
              </div>

            </div>

            {/* RIGHT / SIDEBAR COLUMN (Metadata, Staff, Shift Slot, Priority, Category Quick Move) */}
            <div className="lg:col-span-4 space-y-5">
              
              {/* Card 1: Shift Time & Execution */}
              <div className="rounded-3xl border border-neutral-200/90 dark:border-neutral-800 bg-white dark:bg-neutral-900 p-5 space-y-3.5 shadow-xs">
                <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-400 block">
                  Shift Timing & Slot
                </span>

                <div className="p-3.5 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/40 border border-emerald-200/80 dark:border-emerald-900/60 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-emerald-900 dark:text-emerald-300 font-semibold flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-emerald-600" />
                      Slot Duration
                    </span>
                    <span className="font-mono font-bold text-emerald-800 dark:text-emerald-200">
                      {task.durationHours ? `${task.durationHours.toFixed(1)} hrs` : '1.0 hr'}
                    </span>
                  </div>

                  <div className="font-mono text-base font-extrabold text-emerald-950 dark:text-emerald-200 tracking-tight">
                    {formatTimeSlot(task.startTime, task.endTime)}
                  </div>
                </div>

                <div className="space-y-2 text-xs">
                  <div className="flex items-center justify-between py-1 border-b border-neutral-100 dark:border-neutral-800">
                    <span className="text-neutral-500 flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-neutral-400" />
                      Due Date
                    </span>
                    <span className="font-mono font-semibold text-neutral-800 dark:text-neutral-200">
                      {task.dueDate || 'Unscheduled'}
                    </span>
                  </div>

                  <div className="flex items-center justify-between py-1 border-b border-neutral-100 dark:border-neutral-800">
                    <span className="text-neutral-500">Priority Level</span>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider ${
                      task.priority === 'urgent'
                        ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                        : task.priority === 'high'
                        ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                        : 'bg-neutral-100 text-neutral-700 dark:bg-neutral-800 dark:text-neutral-300'
                    }`}>
                      {task.priority}
                    </span>
                  </div>

                  {task.reminderTime && (
                    <div className="flex items-center justify-between py-1">
                      <span className="text-neutral-500 flex items-center gap-1.5">
                        <Bell className="w-3.5 h-3.5 text-amber-500" />
                        Reminder Alert
                      </span>
                      <span className="font-mono text-[11px] text-amber-600 dark:text-amber-400 font-semibold">
                        {new Date(task.reminderTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {/* Card 2: Assigned Staff Personnel */}
              <div className="rounded-3xl border border-neutral-200/90 dark:border-neutral-800 bg-white dark:bg-neutral-900 p-5 space-y-3 shadow-xs">
                <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-400 block">
                  Assigned Staff Personnel
                </span>

                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-neutral-900 dark:bg-neutral-800 text-white flex items-center justify-center font-bold text-sm shadow-2xs">
                    {(task.employeeName || '?').charAt(0)}
                  </div>
                  <div className="min-w-0 flex-1">
                    <h4 className="text-xs sm:text-sm font-bold text-neutral-900 dark:text-neutral-100 truncate">
                      {task.employeeName}
                    </h4>
                    <p className="text-[11px] text-neutral-500 dark:text-neutral-400 truncate">
                      {task.department}
                    </p>
                  </div>
                </div>
              </div>

              {/* Card 3: Performance Evaluation (Super Admin Only) */}
              {(isSuperAdmin || task.rating) && (
                <div className="rounded-3xl border-2 border-amber-300 dark:border-amber-700 bg-white dark:bg-neutral-900 p-5 space-y-3 shadow-xs">
                  <span className="text-[11px] font-black uppercase tracking-wider text-amber-600 dark:text-amber-400 block">
                    Performance Evaluation
                  </span>

                  <div className="flex flex-col gap-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <button
                            key={star}
                            disabled={!isSuperAdmin || !task.completed}
                            onClick={() => onUpdateRating?.(task.id, star)}
                            className={`${isSuperAdmin && task.completed ? 'cursor-pointer hover:scale-110' : 'cursor-default'} transition-all`}
                          >
                            <Star
                              className={`h-6 w-6 ${
                                star <= (task.rating || 0)
                                  ? 'fill-amber-400 text-amber-400'
                                  : 'text-neutral-200 dark:text-neutral-800'
                              }`}
                            />
                          </button>
                        ))}
                      </div>
                      {task.rating && (
                        <span className="text-xl font-black text-amber-600">
                          {task.rating.toFixed(1)}
                        </span>
                      )}
                    </div>
                    
                    {!task.completed && isSuperAdmin && (
                      <p className="text-[10px] text-neutral-400 italic">
                        Mark task as completed to enable performance rating.
                      </p>
                    )}
                    
                    {task.completed && isSuperAdmin && (
                      <p className="text-[10px] text-neutral-500 font-medium leading-tight">
                        As Super Admin, you can rate the quality and efficiency of this deliverable.
                      </p>
                    )}
                  </div>
                </div>
              )}

              {/* Card 3: Quick Action Progression */}
              <div className="rounded-3xl border border-neutral-200/90 dark:border-neutral-800 bg-neutral-50/70 dark:bg-neutral-850/60 p-5 space-y-3 shadow-xs">
                <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-400 block">
                  Workflow Progression
                </span>

                {currentCategory === 'todo' && (
                  <button
                    onClick={() => handleCategoryChange('in_progress')}
                    className="w-full flex items-center justify-center gap-2 py-2.5 px-3 rounded-2xl bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-black transition shadow-xs cursor-pointer"
                  >
                    <span>Start Work (Move to In Progress)</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                )}

                {currentCategory === 'in_progress' && (
                  <button
                    onClick={() => handleCategoryChange('completed')}
                    className="w-full flex items-center justify-center gap-2 py-2.5 px-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black transition shadow-xs cursor-pointer"
                  >
                    <Check className="w-4 h-4 stroke-[2.5]" />
                    <span>Mark Completed & Sign Off</span>
                  </button>
                )}

                {currentCategory === 'completed' && (
                  <button
                    onClick={() => handleCategoryChange('in_progress')}
                    className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-2xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-xs font-semibold text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-750 transition cursor-pointer"
                  >
                    <span>Reopen Deliverable</span>
                  </button>
                )}
              </div>

            </div>

          </div>
        </div>

        {/* 4. FOOTER BAR */}
        <div className="px-6 py-3.5 border-t border-neutral-200/80 dark:border-neutral-800 bg-neutral-50/80 dark:bg-neutral-850/80 flex items-center justify-between text-xs text-neutral-500 dark:text-neutral-400 shrink-0">
          <div>
            {task.completed && task.completedAt && (
              <span className="text-emerald-600 dark:text-emerald-400 font-semibold">
                Completed on {new Date(task.completedAt).toLocaleString([], { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}
              </span>
            )}
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-neutral-200/80 dark:bg-neutral-700 hover:bg-neutral-300 dark:hover:bg-neutral-600 text-neutral-800 dark:text-neutral-200 font-semibold transition cursor-pointer"
          >
            Close View
          </button>
        </div>

      </div>
    </div>
  );
};
