import React from 'react';
import { Bell, Check, Clock, X } from 'lucide-react';
import { Task } from '../types/task';

interface ActiveReminderBannerProps {
  activeTask: Task | null;
  onDismiss: () => void;
  onSnooze: (taskId: string, minutes: number) => void;
  onComplete: (taskId: string) => void;
}

export const ActiveReminderBanner: React.FC<ActiveReminderBannerProps> = ({
  activeTask,
  onDismiss,
  onSnooze,
  onComplete,
}) => {
  if (!activeTask) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 max-w-sm w-full rounded-2xl border border-amber-300/80 bg-white dark:border-amber-700/80 dark:bg-neutral-900 p-4 shadow-2xl animate-in slide-in-from-bottom-5 duration-200">
      <div className="flex items-start gap-3">
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-amber-500 text-white shadow-xs">
          <Bell className="h-5 w-5 animate-bounce" />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400 uppercase tracking-wider">
              Task Reminder Alert
            </span>
            <button
              onClick={onDismiss}
              className="text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-200 p-0.5"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>

          <h4 className="mt-1 text-xs font-semibold text-neutral-900 dark:text-neutral-100 truncate">
            {activeTask.title}
          </h4>

          {activeTask.description && (
            <p className="mt-0.5 text-[11px] text-neutral-500 dark:text-neutral-400 line-clamp-1">
              {activeTask.description}
            </p>
          )}

          {/* Action Buttons */}
          <div className="mt-3 flex items-center gap-2">
            <button
              onClick={() => onComplete(activeTask.id)}
              className="flex-1 flex items-center justify-center gap-1 rounded-lg bg-emerald-600 px-2.5 py-1.5 text-[11px] font-semibold text-white hover:bg-emerald-700 transition"
            >
              <Check className="h-3 w-3" />
              <span>Mark Done</span>
            </button>
            <button
              onClick={() => onSnooze(activeTask.id, 10)}
              className="flex items-center justify-center gap-1 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-800 px-2.5 py-1.5 text-[11px] font-medium text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-700 transition"
            >
              <Clock className="h-3 w-3" />
              <span>Snooze 10m</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
