import React, { useState } from 'react';
import {
  Megaphone,
  Pin,
  ChevronRight,
  Flame,
  X,
  ShieldAlert
} from 'lucide-react';
import { CompanyNotice } from '../types/task';

interface NoticeBannerProps {
  notices: CompanyNotice[];
  onOpenNoticesView: () => void;
}

export const NoticeBanner: React.FC<NoticeBannerProps> = ({
  notices,
  onOpenNoticesView,
}) => {
  const [dismissedId, setDismissedId] = useState<string | null>(null);

  // Get the most relevant active notice (pinned first, then latest)
  const activeNotice = notices
    .filter((n) => n.id !== dismissedId)
    .sort((a, b) => {
      if (a.pinned && !b.pinned) return -1;
      if (!a.pinned && b.pinned) return 1;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    })[0];

  if (!activeNotice) return null;

  const isUrgent = activeNotice.priority === 'urgent';

  return (
    <div className={`mx-4 sm:mx-6 lg:mx-8 mt-4 rounded-2xl border transition shadow-xs flex items-center justify-between gap-3 px-4 py-3 ${
      isUrgent
        ? 'bg-rose-50/90 dark:bg-rose-950/40 border-rose-300 dark:border-rose-800 text-rose-950 dark:text-rose-200'
        : 'bg-gradient-to-r from-amber-50/90 via-amber-50/60 to-yellow-50/80 dark:from-amber-950/40 dark:via-neutral-900 dark:to-neutral-900 border-amber-300/80 dark:border-amber-800 text-amber-950 dark:text-amber-200'
    }`}>
      <div className="flex items-center gap-3 min-w-0 flex-1">
        <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 shadow-2xs ${
          isUrgent
            ? 'bg-rose-600 text-white'
            : 'bg-amber-500 text-slate-950'
        }`}>
          {isUrgent ? <Flame className="w-4 h-4" /> : <Megaphone className="w-4 h-4" />}
        </div>

        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-extrabold uppercase tracking-wider px-1.5 py-0.2 rounded bg-black/10 dark:bg-white/10">
              Company Notice · {activeNotice.authorName}
            </span>
            {activeNotice.pinned && (
              <span className="text-[10px] font-bold flex items-center gap-0.5 text-amber-700 dark:text-amber-400">
                <Pin className="w-2.5 h-2.5" /> Pinned
              </span>
            )}
          </div>
          <p className="text-xs font-bold text-neutral-900 dark:text-neutral-100 truncate mt-0.5">
            {activeNotice.title}
          </p>
          <p className="text-[11px] text-neutral-600 dark:text-neutral-300 line-clamp-1">
            {activeNotice.content}
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2 shrink-0">
        <button
          onClick={onOpenNoticesView}
          className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-white dark:bg-neutral-800 text-neutral-900 dark:text-neutral-100 text-xs font-bold shadow-2xs hover:bg-neutral-50 dark:hover:bg-neutral-700 transition border border-neutral-200 dark:border-neutral-700"
        >
          <span>Read All Notices ({notices.length})</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>

        <button
          onClick={() => setDismissedId(activeNotice.id)}
          className="p-1 rounded-lg text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200"
          title="Dismiss this notice preview"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
