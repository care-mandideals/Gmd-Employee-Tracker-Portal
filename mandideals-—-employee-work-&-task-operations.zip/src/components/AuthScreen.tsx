import React, { useState } from 'react';
import {
  Crown,
  Code,
  Users,
  LogIn,
  UserPlus,
  Mail,
  Lock,
  ArrowRight,
  Eye,
  EyeOff
} from 'lucide-react';
import { Employee } from '../types/task';

interface AuthScreenProps {
  onLogin: (email: string, password: string) => Promise<void>;
  onRegister: (newEmp: Employee) => void;
  onResetPassword: (email: string, newPassword: string) => Promise<void>;
  employees: Employee[];
  departments: string[];
  companyLogo?: string;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({
  onLogin,
  onRegister,
  onResetPassword,
  employees,
  departments,
  companyLogo,
}) => {
  const [authMode, setAuthMode] = useState<'login' | 'register' | 'forgot'>('login');
  const [email, setEmail] = useState(() => localStorage.getItem('md_remember_email') || '');
  const [password, setPassword] = useState(() => localStorage.getItem('md_remember_pass') || '');
  const [showPassword, setShowPassword] = useState(false);
  const [showRegPassword, setShowRegPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Forgot Password / OTP States
  const [forgotEmail, setForgotEmail] = useState('');
  const [otpStep, setOtpStep] = useState<'email' | 'otp' | 'reset'>('email');
  const [sentOtp, setSentOtp] = useState('');
  const [userOtp, setUserOtp] = useState('');
  const [newPassword, setNewPassword] = useState('');

  // Register Fields
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regRole, setRegRole] = useState('');
  const [regDept, setRegDept] = useState(departments[0] || 'Business Development & Tech');
  const [regPhone, setRegPhone] = useState('');

  const handleSendOtp = async () => {
    setErrorMsg('');
    if (!forgotEmail.trim()) {
      setErrorMsg('Please enter your work email.');
      return;
    }

    const matched = employees.find(e => e.email.toLowerCase() === forgotEmail.trim().toLowerCase());
    if (!matched) {
      setErrorMsg('Email not found in executive records.');
      return;
    }

    setIsSubmitting(true);
    try {
      const otp = Math.floor(100000 + Math.random() * 900000).toString();
      const response = await fetch('/api/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: forgotEmail.trim(), otp, name: matched.name })
      });

      if (!response.ok) throw new Error('Failed to send email. Please check server logs.');

      setSentOtp(otp);
      setOtpStep('otp');
    } catch (err: any) {
      setErrorMsg('Error sending OTP. Verify server configuration.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleVerifyOtp = () => {
    if (userOtp === sentOtp) {
      setOtpStep('reset');
    } else {
      setErrorMsg('Invalid OTP. Please try again.');
    }
  };

  const handleResetPassword = async () => {
    if (!newPassword.trim()) {
      setErrorMsg('Please enter a new password.');
      return;
    }
    setIsSubmitting(true);
    try {
      await onResetPassword(forgotEmail, newPassword.trim());
      setErrorMsg('Password updated successfully! You can now log in.');
      setAuthMode('login');
      setOtpStep('email');
    } catch (err) {
      setErrorMsg('Reset failed. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setIsSubmitting(true);

    try {
      await onLogin(email.trim(), password);
      // Remember credentials on success
      localStorage.setItem('md_remember_email', email.trim());
      localStorage.setItem('md_remember_pass', password);
    } catch (err: any) {
      let msg = err.message || 'Login failed. Please check credentials or authorization status.';
      
      // Hint for demo users
      if (msg.toLowerCase().includes('password') || msg.toLowerCase().includes('not found')) {
        const defaultEmails = ['sabya@mandideals.com', 'hr@mandideals.com'];
        if (defaultEmails.includes(email.trim().toLowerCase())) {
          msg += ' [Hint: Use default credentials like Sabya@123 or Hr@123]';
        }
      }
      
      setErrorMsg(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!regName.trim() || !regEmail.trim() || !regPassword.trim()) {
      setErrorMsg('Please fill in all mandatory fields.');
      return;
    }

    const exists = employees.some(
      (e) => e.email.toLowerCase() === regEmail.trim().toLowerCase()
    );
    if (exists) {
      setErrorMsg('An employee with this email already exists.');
      return;
    }

    const newEmp: Employee = {
      id: `emp-${Date.now()}`,
      name: regName.trim(),
      email: regEmail.trim().toLowerCase(),
      password: regPassword,
      role: regRole.trim() || 'Operations Specialist',
      department: regDept,
      phone: regPhone.trim() || '+91 98000 00000',
      location: 'Central Mandi Complex',
      joinedDate: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }).replace(/ /g, '-'),
      shift: '10:30 AM – 06:30 PM',
      accessLevel: 'STAFF',
      isSuperAdmin: false,
      status: 'Active',
      isAuthorized: false,
      bio: `MANDIDEALS staff member in the ${regDept} department.`,
    };

    onRegister(newEmp);
    setAuthMode('login');
    setErrorMsg('Registration submitted! Please wait for Super Admin approval before logging in.');
  };

  return (
    <div className="fixed inset-0 w-full h-full overflow-y-auto bg-gradient-to-br from-neutral-50 via-white to-emerald-50/40 dark:from-neutral-950 dark:via-neutral-900 dark:to-emerald-950/20 text-neutral-900 dark:text-neutral-100 selection:bg-emerald-100 dark:selection:bg-emerald-900/30">
      <div className="min-h-full w-full flex flex-col items-center justify-center p-4 sm:p-8">
        <div className="max-w-md w-full bg-white dark:bg-neutral-900 border border-neutral-200/90 dark:border-neutral-800 rounded-3xl p-6 sm:p-8 shadow-xl shadow-neutral-200/30 dark:shadow-neutral-950/40 relative transition-colors">
        
        {/* Top Decorative Accent */}
        <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-amber-500 via-emerald-500 to-indigo-600 rounded-t-3xl"></div>

        {/* Company Header */}
        <div className="text-center space-y-2 mb-6 pt-2">
          <div className="w-16 h-16 rounded-2xl bg-neutral-900 dark:bg-neutral-100 text-white dark:text-neutral-900 border-2 border-emerald-500 flex items-center justify-center mx-auto shadow-md font-bold text-lg tracking-wider overflow-hidden">
            {companyLogo ? (
              <img src={companyLogo} alt="Logo" className="w-full h-full object-cover" />
            ) : (
              "MD"
            )}
          </div>
          <div>
            <h1 className="text-2xl font-extrabold tracking-tight text-neutral-900 dark:text-neutral-100 uppercase">
              MANDIDEALS
            </h1>
            <p className="text-[10px] text-neutral-500 dark:text-neutral-400 font-bold uppercase tracking-widest mt-1">
              Enterprise Operations & Staff Portal
            </p>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex p-1 bg-neutral-100 dark:bg-neutral-800 rounded-xl mb-5 text-[11px] font-black uppercase tracking-wider">
          <button
            type="button"
            onClick={() => {
              setAuthMode('login');
              setErrorMsg('');
            }}
            className={`flex-1 py-2.5 rounded-lg transition flex items-center justify-center gap-2 ${
              authMode === 'login'
                ? 'bg-white text-neutral-900 shadow-sm dark:bg-neutral-700 dark:text-white'
                : 'text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200'
            }`}
          >
            <LogIn className="w-3.5 h-3.5" />
            <span>Login</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setAuthMode('register');
              setErrorMsg('');
            }}
            className={`flex-1 py-2.5 rounded-lg transition flex items-center justify-center gap-2 ${
              authMode === 'register'
                ? 'bg-white text-neutral-900 shadow-sm dark:bg-neutral-700 dark:text-white'
                : 'text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200'
            }`}
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>Join Staff</span>
          </button>
        </div>

        {/* Error Message */}
        {errorMsg && (
          <div className="mb-5 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-[11px] font-bold text-rose-700 dark:text-rose-300 animate-in fade-in slide-in-from-top-1">
            {errorMsg}
          </div>
        )}

        {/* Forms */}
        <div className="pb-2">
          {authMode === 'login' ? (
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-[10px] font-black uppercase tracking-widest text-neutral-500 dark:text-neutral-400 mb-1.5 ml-1">
                  Work Email
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-neutral-400 absolute left-4 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="e.g. sabya@mandideals.com"
                    className="w-full bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-2xl pl-11 pr-4 py-3 text-sm text-neutral-900 dark:text-neutral-100 placeholder:text-neutral-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-black uppercase tracking-widest text-neutral-500 dark:text-neutral-400 mb-1.5 ml-1">
                  Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-neutral-400 absolute left-4 top-1/2 -translate-y-1/2" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-2xl pl-11 pr-11 py-3 text-sm text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3.5 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600 transition"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                <div className="flex justify-end mt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setAuthMode('forgot');
                      setErrorMsg('');
                    }}
                    className="text-[10px] font-bold text-emerald-600 hover:text-emerald-700 dark:text-emerald-400 uppercase tracking-wider transition"
                  >
                    Forgot Password?
                  </button>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 rounded-2xl bg-neutral-900 dark:bg-emerald-600 hover:bg-neutral-800 dark:hover:bg-emerald-700 text-white text-sm font-black uppercase tracking-widest shadow-lg transition flex items-center justify-center gap-2 group mt-6"
              >
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                <span>Enter Dashboard</span>
              </button>
            </form>
          ) : authMode === 'register' ? (
            <form onSubmit={handleRegisterSubmit} className="space-y-4">
              <div>
                <label className="block text-[10px] font-black uppercase tracking-widest text-neutral-500 dark:text-neutral-400 mb-1.5 ml-1">
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  value={regName}
                  onChange={(e) => setRegName(e.target.value)}
                  placeholder="Staff Member Name"
                  className="w-full bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-2xl px-4 py-2.5 text-sm font-bold text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-neutral-500 dark:text-neutral-400 mb-1.5 ml-1">
                    Department
                  </label>
                  <select
                    value={regDept}
                    onChange={(e) => setRegDept(e.target.value)}
                    className="w-full bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-2xl px-3 py-2.5 text-xs font-bold text-neutral-800 dark:text-neutral-200 focus:outline-none"
                  >
                    {departments.map((dept) => (
                      <option key={dept} value={dept}>{dept}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-neutral-500 dark:text-neutral-400 mb-1.5 ml-1">
                    Role Title
                  </label>
                  <input
                    type="text"
                    required
                    value={regRole}
                    onChange={(e) => setRegRole(e.target.value)}
                    placeholder="Designation"
                    className="w-full bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-2xl px-3 py-2.5 text-xs font-bold text-neutral-900 dark:text-neutral-100 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-black uppercase tracking-widest text-neutral-500 dark:text-neutral-400 mb-1.5 ml-1">
                  Work Email Address
                </label>
                <input
                  type="email"
                  required
                  value={regEmail}
                  onChange={(e) => setRegEmail(e.target.value)}
                  placeholder="email@mandideals.com"
                  className="w-full bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-2xl px-4 py-2.5 text-sm font-bold text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-neutral-500 dark:text-neutral-400 mb-1.5 ml-1">
                    Set Password
                  </label>
                  <div className="relative">
                    <input
                      type={showRegPassword ? 'text' : 'password'}
                      required
                      value={regPassword}
                      onChange={(e) => setRegPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-2xl px-4 py-2.5 text-sm text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition"
                    />
                    <button
                      type="button"
                      onClick={() => setShowRegPassword(!showRegPassword)}
                      className="absolute right-3.5 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600 transition"
                    >
                      {showRegPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-neutral-500 dark:text-neutral-400 mb-1.5 ml-1">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    value={regPhone}
                    onChange={(e) => setRegPhone(e.target.value)}
                    placeholder="+91..."
                    className="w-full bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-2xl px-4 py-2.5 text-xs font-bold text-neutral-900 dark:text-neutral-100 focus:outline-none"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-black uppercase tracking-widest shadow-lg shadow-emerald-500/20 transition flex items-center justify-center gap-2 mt-6"
              >
                <UserPlus className="w-4 h-4" />
                <span>Register Account</span>
              </button>
            </form>
          ) : (
            <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
              <div className="text-center mb-4">
                <h2 className="text-sm font-black text-neutral-800 dark:text-neutral-200 uppercase tracking-wider">Account Recovery</h2>
                <p className="text-[10px] text-neutral-500 mt-1">
                  {otpStep === 'email' && "Enter your work email to receive a secure OTP code."}
                  {otpStep === 'otp' && `Enter the 6-digit code sent to ${forgotEmail}`}
                  {otpStep === 'reset' && "Create a new secure password for your account."}
                </p>
              </div>

              {otpStep === 'email' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-black uppercase tracking-widest text-neutral-500 dark:text-neutral-400 mb-1.5 ml-1">Work Email</label>
                    <input
                      type="email"
                      value={forgotEmail}
                      onChange={(e) => setForgotEmail(e.target.value)}
                      placeholder="e.g. sabyasachi.baral@mandideals.com"
                      className="w-full bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-2xl px-4 py-3 text-sm font-bold focus:ring-2 focus:ring-emerald-500 outline-none"
                    />
                  </div>
                  <button
                    onClick={handleSendOtp}
                    disabled={isSubmitting}
                    className="w-full py-3.5 rounded-2xl bg-neutral-900 dark:bg-neutral-100 text-white dark:text-neutral-900 text-sm font-black uppercase tracking-widest shadow-lg hover:scale-[1.02] transition active:scale-95 disabled:opacity-50"
                  >
                    {isSubmitting ? "Sending..." : "Send Verification Code"}
                  </button>
                </div>
              )}

              {otpStep === 'otp' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-black uppercase tracking-widest text-neutral-500 dark:text-neutral-400 mb-1.5 ml-1">Verification OTP</label>
                    <input
                      type="text"
                      maxLength={6}
                      value={userOtp}
                      onChange={(e) => setUserOtp(e.target.value)}
                      placeholder="000000"
                      className="w-full bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-2xl px-4 py-3 text-center text-2xl font-black tracking-[0.5em] focus:ring-2 focus:ring-emerald-500 outline-none"
                    />
                  </div>
                  <button
                    onClick={handleVerifyOtp}
                    className="w-full py-3.5 rounded-2xl bg-emerald-600 text-white text-sm font-black uppercase tracking-widest shadow-lg hover:scale-[1.02] transition"
                  >
                    Verify & Continue
                  </button>
                </div>
              )}

              {otpStep === 'reset' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-black uppercase tracking-widest text-neutral-500 dark:text-neutral-400 mb-1.5 ml-1">New Password</label>
                    <input
                      type="password"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-2xl px-4 py-3 text-sm font-bold focus:ring-2 focus:ring-emerald-500 outline-none"
                    />
                  </div>
                  <button
                    onClick={handleResetPassword}
                    className="w-full py-3.5 rounded-2xl bg-amber-500 text-white text-sm font-black uppercase tracking-widest shadow-lg hover:scale-[1.02] transition"
                  >
                    Update Password
                  </button>
                </div>
              )}

              <button
                type="button"
                onClick={() => {
                  setAuthMode('login');
                  setOtpStep('email');
                }}
                className="w-full py-2 text-[11px] font-bold text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200 uppercase tracking-widest transition"
              >
                Back to Login
              </button>
            </div>
          )}
        </div>

        <div className="mt-6 pt-4 border-t border-neutral-100 dark:border-neutral-800 text-center">
          <p className="text-[9px] text-neutral-400 font-bold uppercase tracking-[0.2em]">
            Executive Governance · MANDIDEALS 2026
          </p>
        </div>
        </div>
      </div>
    </div>
  );
};
