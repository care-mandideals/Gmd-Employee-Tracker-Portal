import React, { useState } from 'react';
import {
  Plus,
  Calendar,
  Clock,
  Bell,
  ArrowUpDown,
  Filter,
  CheckCircle2,
  ListTodo,
  Layers,
  Inbox,
  Flame,
  Trash2,
  Table as TableIcon,
  User,
  Building2,
  Maximize2,
  StickyNote,
  ArrowRight,
  Pencil,
  ChevronDown,
  Star
} from 'lucide-react';
import { Task, TaskPriority, ViewFilter, Employee, TaskStatus, getTaskCategory, CompanyShift } from '../types/task';
import { TaskItem } from './TaskItem';
import { TaskDetailWideModal } from './TaskDetailWideModal';
import { calculateDurationHours, formatTimeSlot } from '../data/initialTasks';

interface TaskBoardProps {
  currentView: ViewFilter;
  tasks: Task[];
  departments: string[];
  employees: Employee[];
  selectedPriority: string | null;
  searchQuery: string;
  companyShift?: CompanyShift;
  onOpenUpdateShift?: () => void;
  onToggleComplete: (id: string) => void;
  onDelete: (id: string) => void;
  onEdit: (task: Task) => void;
  onQuickSnooze: (id: string, minutes: number) => void;
  onToggleSubtask: (taskId: string, subtaskId: string) => void;
  onQuickAdd: (
    title: string,
    priority: TaskPriority,
    employeeName: string,
    department: string,
    startTime: string,
    endTime: string,
    dueDate?: string,
    reminderTime?: string
  ) => void;
  onClearCompleted: () => void;
  currentUser?: Employee;
  isSuperAdmin?: boolean;
  onUpdateStatus?: (id: string, status: TaskStatus) => void;
  onUpdateDescription?: (id: string, description: string) => void;
  onAddSubtask?: (taskId: string, title: string) => void;
  onUpdateRating?: (id: string, rating: number) => void;
}

export const TaskBoard: React.FC<TaskBoardProps> = ({
  currentView,
  tasks,
  departments,
  employees,
  selectedPriority,
  searchQuery,
  companyShift,
  onOpenUpdateShift,
  onToggleComplete,
  onDelete,
  onEdit,
  onQuickSnooze,
  onToggleSubtask,
  onQuickAdd,
  onClearCompleted,
  currentUser,
  isSuperAdmin = false,
  onUpdateStatus,
  onUpdateDescription,
  onAddSubtask,
  onUpdateRating,
}) => {
  const [quickTitle, setQuickTitle] = useState('');
  const [quickStatus, setQuickStatus] = useState<TaskStatus>('in_progress');
  const [quickEmployee, setQuickEmployee] = useState(
    !isSuperAdmin && currentUser
      ? currentUser.name
      : currentView.startsWith('emp:')
      ? currentView.replace('emp:', '')
      : employees[0]?.name || 'Sandip Sahoo'
  );
  const [quickDept, setQuickDept] = useState(
    !isSuperAdmin && currentUser?.department
      ? currentUser.department
      : currentView.startsWith('dept:')
      ? currentView.replace('dept:', '')
      : departments[0] || 'Business Development & Tech'
  );
  const [quickStartTime, setQuickStartTime] = useState('10:30');
  const [quickEndTime, setQuickEndTime] = useState('11:30');
  const [quickPriority, setQuickPriority] = useState<TaskPriority>('medium');
  const [quickHasReminder, setQuickHasReminder] = useState(false);
  const [sortBy, setSortBy] = useState<'time' | 'dueDate' | 'priority' | 'employee' | 'title'>('time');
  const [viewMode, setViewMode] = useState<'list' | 'board' | 'table'>('list');
  const [selectedCategory, setSelectedCategory] = useState<'all' | TaskStatus>('all');
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [isClearingConfirm, setIsClearingConfirm] = useState(false);
  const [selectedTaskForDetail, setSelectedTaskForDetail] = useState<Task | null>(null);
  const [adminFilterEmployee, setAdminFilterEmployee] = useState<string>('all');
  const [adminFilterStartDate, setAdminFilterStartDate] = useState<string>('');
  const [adminFilterEndDate, setAdminFilterEndDate] = useState<string>('');

  const todayStr = new Date().toISOString().split('T')[0];

  // Base view-filtered tasks (before category sub-filter)
  const viewScopedTasks = tasks.filter((task) => {
    // 1. Super Admin Filters (If active)
    if (isSuperAdmin) {
      if (adminFilterEmployee !== 'all' && task.employeeName !== adminFilterEmployee) return false;
      if (adminFilterStartDate && task.dueDate && task.dueDate < adminFilterStartDate) return false;
      if (adminFilterEndDate && task.dueDate && task.dueDate > adminFilterEndDate) return false;
    }

    // 2. Search Query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matches =
        (task.title || '').toLowerCase().includes(q) ||
        (task.description && task.description.toLowerCase().includes(q)) ||
        (task.employeeName || '').toLowerCase().includes(q) ||
        (task.department || '').toLowerCase().includes(q) ||
        (task.startTime || '').includes(q) ||
        (task.endTime || '').includes(q);
      if (!matches) return false;
    }

    // 2. Priority Filter
    if (selectedPriority && task.priority !== selectedPriority) {
      return false;
    }

    // 3. View Filter
    if (currentView === 'all') {
      return true;
    } else if (currentView === 'today') {
      return task.dueDate === todayStr || (task.dueDate && task.dueDate < todayStr && !task.completed);
    } else if (currentView === 'upcoming') {
      return !task.completed && task.dueDate && task.dueDate > todayStr;
    } else if (currentView === 'reminders') {
      return !task.completed && Boolean(task.reminderTime);
    } else if (currentView === 'completed') {
      return task.completed;
    } else if (currentView.startsWith('emp:')) {
      const empName = currentView.replace('emp:', '');
      return task.employeeName === empName;
    } else if (currentView.startsWith('dept:')) {
      const deptName = currentView.replace('dept:', '');
      return task.department === deptName;
    }

    return true;
  });

  // Calculate live counts for the 3 categories
  const todoCount = viewScopedTasks.filter((t) => getTaskCategory(t) === 'todo').length;
  const inProgressCount = viewScopedTasks.filter((t) => getTaskCategory(t) === 'in_progress').length;
  const completedCount = viewScopedTasks.filter((t) => getTaskCategory(t) === 'completed').length;
  const allCount = viewScopedTasks.length;

  // Filter tasks based on selected 3-category tab (if not 'all')
  const filteredTasks = viewScopedTasks.filter((task) => {
    if (selectedCategory !== 'all') {
      return getTaskCategory(task) === selectedCategory;
    }
    return true;
  });

  // Sort tasks
  const sortedTasks = [...filteredTasks].sort((a, b) => {
    if (a.completed !== b.completed) {
      return a.completed ? 1 : -1;
    }

    if (sortBy === 'time') {
      return (a.startTime || '00:00').localeCompare(b.startTime || '00:00');
    } else if (sortBy === 'dueDate') {
      if (!a.dueDate) return 1;
      if (!b.dueDate) return -1;
      return a.dueDate.localeCompare(b.dueDate);
    } else if (sortBy === 'priority') {
      const weight: Record<TaskPriority, number> = { urgent: 4, high: 3, medium: 2, low: 1 };
      return weight[b.priority] - weight[a.priority];
    } else if (sortBy === 'employee') {
      return a.employeeName.localeCompare(b.employeeName);
    } else {
      return a.title.localeCompare(b.title);
    }
  });

  const handleQuickSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickTitle.trim()) return;

    let reminder: string | undefined = undefined;
    if (quickHasReminder) {
      reminder = new Date(Date.now() + 30 * 60 * 1000).toISOString();
    }

    const assignedEmployee = (!isSuperAdmin && currentUser) ? currentUser.name : quickEmployee;

    onQuickAdd(
      quickTitle.trim(),
      quickPriority,
      assignedEmployee,
      quickDept,
      quickStartTime,
      quickEndTime,
      todayStr,
      reminder
    );

    setQuickTitle('');
    setQuickHasReminder(false);
  };

  const getViewDetails = () => {
    if (!isSuperAdmin) {
      switch (currentView) {
        case 'all':
          return {
            title: `My Workspace (${currentUser?.name || 'Deliverables'})`,
            desc: 'Your private daily roster and logged operations. All other member workspaces are restricted to Super Admin (Sabyasachi).'
          };
        case 'today':
          return {
            title: `My Today's Shift (${companyShift?.startTime12 || '10:30 AM'} – ${companyShift?.endTime12 || '06:30 PM'})`,
            desc: `Your personal deliverables and shift operations scheduled for today · Shift Updated by Sabyasachi (CEO)`
          };
        case 'upcoming':
          return {
            title: 'My Upcoming Operations',
            desc: 'Your scheduled deliverables for upcoming business days'
          };
        case 'reminders':
          return {
            title: 'My Shift Reminders & Timers',
            desc: 'Your personal tasks configured with timed browser push notifications'
          };
        case 'completed':
          return {
            title: 'My Completed Deliverables',
            desc: 'Your signed-off and finalized personal work records'
          };
        default:
          if (currentView.startsWith('dept:')) {
            const dept = currentView.replace('dept:', '');
            return { title: `My ${dept} Stream`, desc: `Your personal deliverables assigned in the ${dept} stream` };
          }
          return { title: 'My Private Workspace', desc: 'Your personal deliverables at MANDIDEALS' };
      }
    }

    switch (currentView) {
      case 'all':
        return {
          title: 'All Member Workspaces · Master View (Sabyasachi)',
          desc: 'Master overview of all company member workspaces, shift logs, and active deliverables'
        };
      case 'today':
        return {
          title: `All Members Today's Shift (${companyShift?.startTime12 || '10:30 AM'} – ${companyShift?.endTime12 || '06:30 PM'})`,
          desc: `Active deliverables and tasks assigned for today across all company member workspaces · Shift Updated by Sabyasachi (CEO)`
        };
      case 'upcoming':
        return {
          title: 'All Members Upcoming Operations',
          desc: 'Scheduled work logs for upcoming business days across all member workspaces'
        };
      case 'reminders':
        return {
          title: 'Company Shift Reminders & Timers',
          desc: 'All member tasks configured with timed browser push notifications'
        };
      case 'completed':
        return {
          title: 'All Members Completed Deliverables',
          desc: 'Signed-off and finalized employee work records across all member workspaces'
        };
      default:
        if (currentView.startsWith('emp:')) {
          const emp = currentView.replace('emp:', '');
          return {
            title: `${emp}'s Workspace (Super Admin Inspection)`,
            desc: `Tasks, shift slots, and logged deliverables assigned to ${emp}`
          };
        }
        if (currentView.startsWith('dept:')) {
          const dept = currentView.replace('dept:', '');
          return {
            title: `${dept} Department Workspace`,
            desc: `Operational deliverables for the ${dept} stream across all members`
          };
        }
        return { title: 'MANDIDEALS Enterprise Workspaces', desc: 'Enterprise member workspace tracking' };
    }
  };

  const { title: viewTitle, desc: viewDesc } = getViewDetails();

  const totalInView = filteredTasks.length;
  const completedInView = filteredTasks.filter((t) => t.completed).length;
  const totalHoursInView = filteredTasks.reduce(
    (acc, t) => acc + (t.durationHours || calculateDurationHours(t.startTime, t.endTime)),
    0
  );
  const progressPct = totalInView > 0 ? Math.round((completedInView / totalInView) * 100) : 0;

  return (
    <div className="flex-1 md:overflow-y-auto px-2 sm:px-6 lg:px-8 py-3 md:py-6 max-w-6xl mx-auto w-full space-y-4 md:space-y-6">
      
      {/* 1. Header Banner & View Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-neutral-200/80 dark:border-neutral-800/80">
        <div>
          <div className="flex items-center gap-1.5 flex-wrap">
            <h1 className="text-lg sm:text-2xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100">
              {viewTitle}
            </h1>
            {isSuperAdmin ? (
              <span className="px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-900 dark:bg-amber-950/70 dark:text-amber-300 text-[9px] font-black uppercase tracking-wider border border-amber-300 dark:border-amber-700">
                CEO All
              </span>
            ) : (
              <span className="px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-900 dark:bg-emerald-950/70 dark:text-emerald-300 text-[9px] font-bold border border-emerald-300 dark:border-emerald-700">
                🔒 My Log
              </span>
            )}
          </div>
          <p className="text-[10px] sm:text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
            {viewDesc}
          </p>
        </div>

        {/* Shift Hours & View Mode Controls */}
        <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap">
          
          {/* Shift Hours & 12-Hour Timing Badge (Updated by Sabyasachi) */}
          <button
            type="button"
            onClick={() => {
              if (isSuperAdmin && onOpenUpdateShift) {
                onOpenUpdateShift();
              }
            }}
            className={`flex h-9 items-center gap-2 rounded-xl border border-emerald-300/90 dark:border-emerald-800/90 bg-emerald-50/90 dark:bg-emerald-950/60 px-3 shadow-2xs whitespace-nowrap select-none transition-all ${
              isSuperAdmin ? 'hover:bg-emerald-100 dark:hover:bg-emerald-900/80 cursor-pointer' : ''
            }`}
            title={
              isSuperAdmin
                ? "CEO Authority: Click to Update Work Shift (12-Hour Timing)"
                : `Work Shift: ${companyShift?.startTime12 || '10:30 AM'} – ${companyShift?.endTime12 || '06:30 PM'} (Updated by Sabyasachi, CEO)`
            }
          >
            <Clock className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
            <div className="flex items-center gap-1.5 whitespace-nowrap">
              <span className="font-mono text-xs font-black text-emerald-950 dark:text-emerald-200">
                Shift: {companyShift?.startTime12 || '10:30 AM'} – {companyShift?.endTime12 || '06:30 PM'}
              </span>
              <span className="text-[10px] font-extrabold px-1.5 py-0.2 rounded bg-emerald-200/90 text-emerald-950 dark:bg-emerald-900 dark:text-emerald-100">
                Updated by Sabyasachi
              </span>
            </div>
            {isSuperAdmin && (
              <span className="text-[10px] font-bold text-amber-700 dark:text-amber-300 underline ml-0.5 whitespace-nowrap">
                Edit 12h
              </span>
            )}
          </button>

          {/* Sort By Dropdown with Custom Chevron */}
          <div className="relative">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="h-9 appearance-none rounded-xl border border-neutral-200/90 dark:border-neutral-800 bg-white dark:bg-neutral-900 pl-3 pr-8 text-xs font-semibold text-neutral-700 dark:text-neutral-200 shadow-2xs hover:bg-neutral-50 dark:hover:bg-neutral-800/60 focus:outline-none focus:ring-1 focus:ring-emerald-500 cursor-pointer transition-all whitespace-nowrap"
            >
              <option value="time">Sort: Start Time (12h)</option>
              <option value="dueDate">Sort: Date</option>
              <option value="priority">Sort: Priority</option>
              {isSuperAdmin && <option value="employee">Sort: Staff Name</option>}
              <option value="title">Sort: Title</option>
            </select>
            <ChevronDown className="pointer-events-none absolute right-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-neutral-400" />
          </div>

          {/* View Mode Toggle: List vs Board vs Table */}
          <div className="flex h-9 items-center rounded-xl border border-neutral-200/90 bg-neutral-100/80 p-0.5 dark:border-neutral-800 dark:bg-neutral-800/80 shadow-2xs whitespace-nowrap">
            <button
              type="button"
              onClick={() => setViewMode('list')}
              className={`h-7 px-2.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap select-none ${
                viewMode === 'list'
                  ? 'bg-white text-neutral-900 shadow-xs dark:bg-neutral-900 dark:text-white'
                  : 'text-neutral-500 hover:text-neutral-800 dark:text-neutral-400 dark:hover:text-white'
              }`}
              title="List View"
            >
              <ListTodo className="h-3.5 w-3.5 shrink-0" />
              <span className="hidden sm:inline">List</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode('board')}
              className={`h-7 px-2.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap select-none ${
                viewMode === 'board'
                  ? 'bg-white text-neutral-900 shadow-xs dark:bg-neutral-900 dark:text-white'
                  : 'text-neutral-500 hover:text-neutral-800 dark:text-neutral-400 dark:hover:text-white'
              }`}
              title="Kanban Focus Board"
            >
              <Layers className="h-3.5 w-3.5 shrink-0" />
              <span className="hidden sm:inline">Board</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode('table')}
              className={`h-7 px-2.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap select-none ${
                viewMode === 'table'
                  ? 'bg-white text-neutral-900 shadow-xs dark:bg-neutral-900 dark:text-white'
                  : 'text-neutral-500 hover:text-neutral-800 dark:text-neutral-400 dark:hover:text-white'
              }`}
              title="Enterprise Table Grid"
            >
              <TableIcon className="h-3.5 w-3.5 shrink-0" />
              <span className="hidden sm:inline">Table</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. Super Admin Inspection Filters */}
      {isSuperAdmin && (
        <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200 dark:border-neutral-800 p-4 shadow-2xs space-y-3">
          <div className="flex items-center gap-2 mb-1">
            <Filter className="w-4 h-4 text-indigo-600" />
            <h3 className="text-[11px] font-black uppercase tracking-widest text-neutral-400">Master Worklog Inspection (CEO Filters)</h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-neutral-500 uppercase ml-1">Staff Member</label>
              <div className="relative">
                <select
                  value={adminFilterEmployee}
                  onChange={(e) => setAdminFilterEmployee(e.target.value)}
                  className="w-full h-9 appearance-none rounded-xl bg-neutral-100 dark:bg-neutral-800 pl-3 pr-8 text-xs font-semibold text-neutral-800 dark:text-neutral-200 focus:outline-none"
                >
                  <option value="all">All Employees</option>
                  {employees.map(emp => (
                    <option key={emp.id} value={emp.name}>{emp.name}</option>
                  ))}
                </select>
                <ChevronDown className="pointer-events-none absolute right-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-neutral-400" />
              </div>
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-neutral-500 uppercase ml-1">Start Date</label>
              <input
                type="date"
                value={adminFilterStartDate}
                onChange={(e) => setAdminFilterStartDate(e.target.value)}
                className="w-full h-9 rounded-xl bg-neutral-100 dark:bg-neutral-800 px-3 text-xs font-semibold text-neutral-800 dark:text-neutral-200 focus:outline-none"
              />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-neutral-500 uppercase ml-1">End Date</label>
              <input
                type="date"
                value={adminFilterEndDate}
                onChange={(e) => setAdminFilterEndDate(e.target.value)}
                className="w-full h-9 rounded-xl bg-neutral-100 dark:bg-neutral-800 px-3 text-xs font-semibold text-neutral-800 dark:text-neutral-200 focus:outline-none"
              />
            </div>
            <div className="flex items-end">
              <button
                onClick={() => {
                  setAdminFilterEmployee('all');
                  setAdminFilterStartDate('');
                  setAdminFilterEndDate('');
                }}
                className="h-9 px-4 rounded-xl text-xs font-bold text-neutral-500 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-all border border-transparent hover:border-rose-200"
              >
                Reset Filters
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 2. Fast Inline Employee Work Log Creation Bar with 12-Hour Timing */}
      <form
        onSubmit={handleQuickSubmit}
        className="rounded-2xl border border-neutral-200/90 dark:border-neutral-800 bg-white dark:bg-neutral-900 p-1.5 sm:p-2.5 shadow-2xs space-y-1.5 transition-all focus-within:ring-2 focus-within:ring-emerald-500/20 focus-within:border-emerald-500"
      >
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-1.5 md:gap-2">
          {/* Work Title */}
          <input
            type="text"
            required
            value={quickTitle}
            onChange={(e) => setQuickTitle(e.target.value)}
            placeholder="Log deliverable..."
            className="flex-1 bg-transparent px-2 py-2 text-xs sm:text-sm text-neutral-900 dark:text-neutral-100 placeholder:text-neutral-400 dark:placeholder:text-neutral-500 focus:outline-none"
          />

          <div className="flex flex-wrap items-center gap-2">
            {/* Employee Selector */}
            {isSuperAdmin ? (
              <div className="relative">
                <select
                  value={quickEmployee}
                  onChange={(e) => setQuickEmployee(e.target.value)}
                  className="appearance-none rounded-xl bg-neutral-100 dark:bg-neutral-800 pl-3 pr-8 py-2 text-xs font-semibold text-neutral-800 dark:text-neutral-200 focus:outline-none cursor-pointer whitespace-nowrap"
                >
                  {employees.map((emp) => (
                    <option key={emp.id} value={emp.name}>
                      {emp.name}
                    </option>
                  ))}
                </select>
                <ChevronDown className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-neutral-400" />
              </div>
            ) : (
              <div className="flex items-center gap-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 px-3 py-2 text-xs font-bold border border-emerald-200 dark:border-emerald-800/80 whitespace-nowrap shrink-0">
                <User className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>You</span>
              </div>
            )}

            {/* Start Time with 12h Conversion */}
            <div className="flex items-center gap-1 bg-neutral-100 dark:bg-neutral-800 rounded-xl px-2.5 py-1.5 border border-transparent focus-within:border-neutral-300 dark:focus-within:border-neutral-700 whitespace-nowrap shrink-0">
              <span className="text-[10px] text-neutral-400 font-bold uppercase">In:</span>
              <input
                type="time"
                value={quickStartTime}
                onChange={(e) => setQuickStartTime(e.target.value)}
                className="bg-transparent text-xs font-mono font-bold text-neutral-800 dark:text-neutral-200 focus:outline-none cursor-pointer"
              />
            </div>

            {/* End Time with 12h Conversion */}
            <div className="flex items-center gap-1 bg-neutral-100 dark:bg-neutral-800 rounded-xl px-2.5 py-1.5 border border-transparent focus-within:border-neutral-300 dark:focus-within:border-neutral-700 whitespace-nowrap shrink-0">
              <span className="text-[10px] text-neutral-400 font-bold uppercase">Out:</span>
              <input
                type="time"
                value={quickEndTime}
                onChange={(e) => setQuickEndTime(e.target.value)}
                className="bg-transparent text-xs font-mono font-bold text-neutral-800 dark:text-neutral-200 focus:outline-none cursor-pointer"
              />
            </div>

            {/* 12-Hour Live Preview Chip */}
            <div className="hidden lg:flex items-center gap-1 font-mono text-[10px] font-bold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-1 rounded-xl border border-emerald-200/70 dark:border-emerald-900/60 whitespace-nowrap shrink-0" title="12-Hour Timing">
              <Clock className="w-3 h-3 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <span>{formatTimeSlot(quickStartTime, quickEndTime)}</span>
            </div>

            {/* Quick Priority */}
            <div className="relative">
              <select
                value={quickPriority}
                onChange={(e) => setQuickPriority(e.target.value as TaskPriority)}
                className="appearance-none rounded-xl bg-neutral-100 dark:bg-neutral-800 pl-3 pr-8 py-2 text-xs font-bold text-neutral-700 dark:text-neutral-300 focus:outline-none capitalize cursor-pointer whitespace-nowrap"
              >
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
                <option value="urgent">Urgent</option>
              </select>
              <ChevronDown className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-neutral-400" />
            </div>

            {/* Quick Reminder Toggle */}
            <button
              type="button"
              onClick={() => setQuickHasReminder(!quickHasReminder)}
              className={`p-1.5 rounded-xl transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                quickHasReminder
                  ? 'bg-amber-100 text-amber-900 dark:bg-amber-900/60 dark:text-amber-200 shadow-2xs'
                  : 'text-neutral-400 hover:bg-neutral-100 hover:text-neutral-700 dark:hover:bg-neutral-800 dark:hover:text-neutral-200'
              }`}
              title={quickHasReminder ? 'Reminder enabled in 30m' : 'Add 30-min Reminder'}
            >
              <Bell className="h-3.5 w-3.5" />
            </button>

            {/* Add Work Log Button */}
            <button
              type="submit"
              disabled={!quickTitle.trim()}
              className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white px-4 py-2 text-xs font-bold shadow-2xs hover:shadow-xs disabled:opacity-40 disabled:cursor-not-allowed transition-all active:scale-[0.98] cursor-pointer whitespace-nowrap shrink-0 select-none"
            >
              <Plus className="h-4 w-4 stroke-[2.5] shrink-0" />
              <span>Add Log</span>
            </button>
          </div>
        </div>
      </form>

      {/* 3. Executive Category Segmented Control & Status Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
        {/* Segmented Filter Bar: All, To Do, In Progress, Completed */}
        <div className="inline-flex items-center p-1 rounded-2xl bg-neutral-100/90 dark:bg-neutral-800/80 border border-neutral-200/80 dark:border-neutral-700/60 gap-1 overflow-x-auto max-w-full shadow-2xs scrollbar-none">
          
          {/* Tab: All Tasks */}
          <button
            type="button"
            onClick={() => setSelectedCategory('all')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer whitespace-nowrap select-none shrink-0 ${
              selectedCategory === 'all'
                ? 'bg-white text-neutral-900 shadow-2xs dark:bg-neutral-900 dark:text-white font-bold'
                : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-white/40 dark:hover:bg-neutral-700/40'
            }`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-neutral-400 dark:bg-neutral-500 shrink-0" />
            <span>All Tasks ({allCount})</span>
          </button>

          {/* Tab 1: To Do */}
          <button
            type="button"
            onClick={() => setSelectedCategory('todo')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer whitespace-nowrap select-none shrink-0 ${
              selectedCategory === 'todo'
                ? 'bg-white text-neutral-900 shadow-2xs dark:bg-neutral-900 dark:text-white font-bold'
                : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-white/40 dark:hover:bg-neutral-700/40'
            }`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-blue-500 shadow-xs shrink-0" />
            <span>To Do ({todoCount})</span>
          </button>

          {/* Tab 2: In Progress */}
          <button
            type="button"
            onClick={() => setSelectedCategory('in_progress')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer whitespace-nowrap select-none shrink-0 ${
              selectedCategory === 'in_progress'
                ? 'bg-white text-neutral-900 shadow-2xs dark:bg-neutral-900 dark:text-white font-bold'
                : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-white/40 dark:hover:bg-neutral-700/40'
            }`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shadow-xs shrink-0" />
            <span>In Progress ({inProgressCount})</span>
          </button>

          {/* Tab 3: Completed */}
          <button
            type="button"
            onClick={() => setSelectedCategory('completed')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer whitespace-nowrap select-none shrink-0 ${
              selectedCategory === 'completed'
                ? 'bg-white text-neutral-900 shadow-2xs dark:bg-neutral-900 dark:text-white font-bold'
                : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-white/40 dark:hover:bg-neutral-700/40'
            }`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-xs shrink-0" />
            <span>Completed ({completedCount})</span>
          </button>
        </div>

        {/* Clear Completed Action */}
        {completedInView > 0 && (
          <div className="flex items-center gap-2 text-xs text-neutral-500 dark:text-neutral-400 shrink-0 self-end sm:self-center">
            <span className="text-[11px] font-medium">{completedInView} completed in view</span>
            
            {isClearingConfirm ? (
              <div className="flex items-center gap-1.5 bg-rose-50 dark:bg-rose-950 p-1 rounded-xl border border-rose-200 dark:border-rose-900 animate-in slide-in-from-right-4 duration-200">
                <span className="text-[10px] font-bold text-rose-600 dark:text-rose-400 px-1">Clear all {completedInView}?</span>
                <button
                  onClick={() => {
                    onClearCompleted();
                    setIsClearingConfirm(false);
                  }}
                  className="px-2 py-0.5 rounded bg-rose-600 text-white text-[10px] font-bold hover:bg-rose-700 transition cursor-pointer"
                >
                  Yes
                </button>
                <button
                  onClick={() => setIsClearingConfirm(false)}
                  className="px-1.5 py-0.5 text-[10px] text-neutral-500 hover:text-neutral-800 font-bold cursor-pointer"
                >
                  No
                </button>
              </div>
            ) : (
              <button
                onClick={() => setIsClearingConfirm(true)}
                className="hover:text-rose-600 dark:hover:text-rose-400 transition-colors flex items-center gap-1.5 text-[11px] font-medium px-2 py-1 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/30 cursor-pointer"
              >
                <Trash2 className="h-3 w-3" />
                <span>Clear completed</span>
              </button>
            )}
          </div>
        )}
      </div>

      {/* 4. Tasks Rendering: List, Board, or Table */}
      {sortedTasks.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-neutral-300 dark:border-neutral-800 p-12 text-center space-y-3 bg-neutral-50/40 dark:bg-neutral-900/20">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white dark:bg-neutral-800 mx-auto text-neutral-400 shadow-2xs border border-neutral-200/60 dark:border-neutral-700/60">
            <Inbox className="h-6 w-6 stroke-[1.5]" />
          </div>
          <div className="space-y-1">
            <h3 className="text-sm font-semibold text-neutral-800 dark:text-neutral-200">
              No employee work logs found
            </h3>
            <p className="text-xs text-neutral-500 dark:text-neutral-400 max-w-sm mx-auto">
              {searchQuery
                ? 'Try tweaking your search term or employee selection.'
                : 'All tasks logged for this filter! Use the input above to log your next deliverable.'}
            </p>
          </div>
        </div>
      ) : viewMode === 'list' ? (
        <div className="space-y-2.5">
          {sortedTasks.map((task) => (
            <TaskItem
              key={task.id}
              task={task}
              onToggleComplete={onToggleComplete}
              onDelete={onDelete}
              onEdit={onEdit}
              onQuickSnooze={onQuickSnooze}
              onToggleSubtask={onToggleSubtask}
              onOpenDetail={(t) => setSelectedTaskForDetail(t)}
              onUpdateStatus={onUpdateStatus}
              isSuperAdmin={isSuperAdmin}
              onUpdateRating={onUpdateRating}
            />
          ))}
        </div>
      ) : viewMode === 'table' ? (
        /* Enterprise Tabular View: Clean spreadsheet presentation with Start Time, End Time & Staff */
        <div className="overflow-x-auto rounded-2xl border border-neutral-200/90 dark:border-neutral-800/90 bg-white dark:bg-neutral-900 shadow-xs">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-neutral-200 dark:border-neutral-800 bg-neutral-50/80 dark:bg-neutral-850 text-neutral-500 dark:text-neutral-400 font-semibold">
                <th className="py-3 px-3.5 pl-4">Status</th>
                <th className="py-3 px-3">Work Deliverable</th>
                <th className="py-3 px-3">Category</th>
                <th className="py-3 px-3">Staff / Author</th>
                <th className="py-3 px-3">Shift Slot</th>
                <th className="py-3 px-3">Duration</th>
                <th className="py-3 px-3">Department</th>
                <th className="py-3 px-3">Priority</th>
                <th className="py-3 px-3">Rating</th>
                <th className="py-3 px-3 pr-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800">
              {sortedTasks.map((task) => {
                const cat = getTaskCategory(task);
                return (
                  <tr
                    key={task.id}
                    onClick={() => setSelectedTaskForDetail(task)}
                    className="hover:bg-neutral-50/80 dark:hover:bg-neutral-800/40 transition cursor-pointer"
                    title="Click row to open wide note & details"
                  >
                    <td className="py-2.5 px-3.5 pl-4" onClick={(e) => e.stopPropagation()}>
                      <input
                        type="checkbox"
                        checked={task.completed}
                        onChange={() => {
                          if (!task.completed && onUpdateStatus) {
                            onUpdateStatus(task.id, 'completed');
                          } else if (task.completed && onUpdateStatus) {
                            onUpdateStatus(task.id, 'in_progress');
                          } else {
                            onToggleComplete(task.id);
                          }
                        }}
                        className="rounded border-neutral-300 text-emerald-600 focus:ring-emerald-500 h-4 w-4 cursor-pointer"
                      />
                    </td>
                    <td className="py-2.5 px-3 font-medium text-neutral-900 dark:text-neutral-100 max-w-xs">
                      <div className="flex items-center gap-1.5">
                        <span className={task.completed ? 'line-through text-neutral-400' : ''}>
                          {task.title}
                        </span>
                        {task.description && (
                          <span className="p-0.5 rounded bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-400 text-[10px] font-bold" title="Has pasted note">
                            <StickyNote className="w-3 h-3 inline" />
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                        cat === 'todo'
                          ? 'bg-blue-50 text-blue-800 dark:bg-blue-950 dark:text-blue-300 border border-blue-200 dark:border-blue-900'
                          : cat === 'in_progress'
                          ? 'bg-amber-50 text-amber-800 dark:bg-amber-950 dark:text-amber-300 border border-amber-200 dark:border-amber-900'
                          : 'bg-emerald-50 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-900'
                      }`}>
                        {cat === 'todo' ? 'To Do' : cat === 'in_progress' ? 'In Progress' : 'Completed'}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap font-semibold text-neutral-800 dark:text-neutral-200">
                      {task.employeeName}
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap font-mono text-[11px] text-emerald-700 dark:text-emerald-400">
                      {formatTimeSlot(task.startTime, task.endTime)}
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap font-mono font-bold text-neutral-700 dark:text-neutral-300">
                      {task.durationHours ? `${task.durationHours.toFixed(1)}h` : '1.0h'}
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap text-neutral-500 dark:text-neutral-400">
                      {task.department}
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold capitalize ${
                          task.priority === 'urgent'
                            ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                            : task.priority === 'high'
                            ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                            : 'bg-neutral-100 text-neutral-700 dark:bg-neutral-800 dark:text-neutral-300'
                        }`}
                      >
                        {task.priority}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap">
                      <div className="flex items-center gap-0.5" onClick={(e) => e.stopPropagation()}>
                        {[1, 2, 3, 4, 5].map((star) => (
                          <button
                            key={star}
                            disabled={!isSuperAdmin || !task.completed}
                            onClick={() => onUpdateRating?.(task.id, star)}
                            className={`${isSuperAdmin && task.completed ? 'cursor-pointer hover:scale-110' : 'cursor-default'} transition-transform`}
                          >
                            <Star
                              className={`h-3 w-3 ${
                                star <= (task.rating || 0)
                                  ? 'fill-amber-400 text-amber-400'
                                  : 'text-neutral-300 dark:text-neutral-700'
                              }`}
                            />
                          </button>
                        ))}
                      </div>
                    </td>
                    <td className="py-2.5 px-3 pr-4 text-right whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => setSelectedTaskForDetail(task)}
                          className="p-1 text-neutral-400 hover:text-emerald-600 rounded transition cursor-pointer"
                          title="Open Wide View"
                        >
                          <Maximize2 className="h-3.5 w-3.5" />
                        </button>
                        <button
                          onClick={() => onEdit(task)}
                          className="p-1 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 rounded transition cursor-pointer"
                          title="Edit Task"
                        >
                          <Pencil className="h-3.5 w-3.5" />
                        </button>
                        
                        {deleteConfirmId === task.id ? (
                          <div className="flex items-center gap-1 bg-rose-50 dark:bg-rose-950 p-0.5 rounded-lg border border-rose-200 dark:border-rose-900 animate-in zoom-in duration-150">
                            <button
                              onClick={() => {
                                onDelete(task.id);
                                setDeleteConfirmId(null);
                              }}
                              className="px-2 py-0.5 rounded bg-rose-600 text-white text-[10px] font-bold hover:bg-rose-700 transition cursor-pointer"
                            >
                              Del
                            </button>
                            <button
                              onClick={() => setDeleteConfirmId(null)}
                              className="px-1.5 py-0.5 text-[10px] text-neutral-500 hover:text-neutral-800 font-bold cursor-pointer"
                            >
                              No
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => setDeleteConfirmId(task.id)}
                            className="p-1 text-neutral-400 hover:text-rose-500 rounded transition cursor-pointer"
                            title="Delete"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      ) : (
        /* Board / Kanban: 3 Dedicated Categories (To Do, In Progress, Completed) */
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          
          {/* Category Column 1: To Do */}
          <div className="space-y-3 bg-neutral-50/60 dark:bg-neutral-900/40 p-3 sm:p-4 rounded-3xl border border-neutral-200/80 dark:border-neutral-800/80">
            <div className="flex items-center justify-between pb-2 border-b border-neutral-200 dark:border-neutral-800">
              <span className="text-xs font-extrabold text-blue-900 dark:text-blue-300 flex items-center gap-1.5 uppercase tracking-wider">
                <ListTodo className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                To Do
              </span>
              <span className="font-mono text-xs font-black px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300">
                {viewScopedTasks.filter((t) => getTaskCategory(t) === 'todo').length}
              </span>
            </div>
            <div className="space-y-2.5">
              {viewScopedTasks
                .filter((t) => getTaskCategory(t) === 'todo')
                .map((task) => (
                  <TaskItem
                    key={task.id}
                    task={task}
                    onToggleComplete={onToggleComplete}
                    onDelete={onDelete}
                    onEdit={onEdit}
                    onQuickSnooze={onQuickSnooze}
                    onToggleSubtask={onToggleSubtask}
                    onOpenDetail={(t) => setSelectedTaskForDetail(t)}
                    onUpdateStatus={onUpdateStatus}
                    isSuperAdmin={isSuperAdmin}
                    onUpdateRating={onUpdateRating}
                  />
                ))}
              {viewScopedTasks.filter((t) => getTaskCategory(t) === 'todo').length === 0 && (
                <div className="py-8 text-center text-xs text-neutral-400 border border-dashed border-neutral-200 dark:border-neutral-800 rounded-2xl">
                  No tasks in To Do
                </div>
              )}
            </div>
          </div>

          {/* Category Column 2: In Progress */}
          <div className="space-y-3 bg-amber-50/30 dark:bg-neutral-900/40 p-3 sm:p-4 rounded-3xl border border-amber-200/60 dark:border-neutral-800/80">
            <div className="flex items-center justify-between pb-2 border-b border-amber-200/80 dark:border-neutral-800">
              <span className="text-xs font-extrabold text-amber-950 dark:text-amber-300 flex items-center gap-1.5 uppercase tracking-wider">
                <Flame className="h-4 w-4 text-amber-500" />
                In Progress
              </span>
              <span className="font-mono text-xs font-black px-2 py-0.5 rounded-full bg-amber-200/80 text-amber-950 dark:bg-amber-950 dark:text-amber-300">
                {viewScopedTasks.filter((t) => getTaskCategory(t) === 'in_progress').length}
              </span>
            </div>
            <div className="space-y-2.5">
              {viewScopedTasks
                .filter((t) => getTaskCategory(t) === 'in_progress')
                .map((task) => (
                  <TaskItem
                    key={task.id}
                    task={task}
                    onToggleComplete={onToggleComplete}
                    onDelete={onDelete}
                    onEdit={onEdit}
                    onQuickSnooze={onQuickSnooze}
                    onToggleSubtask={onToggleSubtask}
                    onOpenDetail={(t) => setSelectedTaskForDetail(t)}
                    onUpdateStatus={onUpdateStatus}
                    isSuperAdmin={isSuperAdmin}
                    onUpdateRating={onUpdateRating}
                  />
                ))}
              {viewScopedTasks.filter((t) => getTaskCategory(t) === 'in_progress').length === 0 && (
                <div className="py-8 text-center text-xs text-neutral-400 border border-dashed border-neutral-200 dark:border-neutral-800 rounded-2xl">
                  No active tasks in progress
                </div>
              )}
            </div>
          </div>

          {/* Category Column 3: Completed */}
          <div className="space-y-3 bg-emerald-50/30 dark:bg-neutral-900/40 p-3 sm:p-4 rounded-3xl border border-emerald-200/60 dark:border-neutral-800/80">
            <div className="flex items-center justify-between pb-2 border-b border-emerald-200/80 dark:border-neutral-800">
              <span className="text-xs font-extrabold text-emerald-950 dark:text-emerald-300 flex items-center gap-1.5 uppercase tracking-wider">
                <CheckCircle2 className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                Completed
              </span>
              <span className="font-mono text-xs font-black px-2 py-0.5 rounded-full bg-emerald-200/80 text-emerald-950 dark:bg-emerald-950 dark:text-emerald-300">
                {viewScopedTasks.filter((t) => getTaskCategory(t) === 'completed').length}
              </span>
            </div>
            <div className="space-y-2.5">
              {viewScopedTasks
                .filter((t) => getTaskCategory(t) === 'completed')
                .map((task) => (
                  <TaskItem
                    key={task.id}
                    task={task}
                    onToggleComplete={onToggleComplete}
                    onDelete={onDelete}
                    onEdit={onEdit}
                    onQuickSnooze={onQuickSnooze}
                    onToggleSubtask={onToggleSubtask}
                    onOpenDetail={(t) => setSelectedTaskForDetail(t)}
                    onUpdateStatus={onUpdateStatus}
                    isSuperAdmin={isSuperAdmin}
                    onUpdateRating={onUpdateRating}
                  />
                ))}
              {viewScopedTasks.filter((t) => getTaskCategory(t) === 'completed').length === 0 && (
                <div className="py-8 text-center text-xs text-neutral-400 border border-dashed border-neutral-200 dark:border-neutral-800 rounded-2xl">
                  No completed deliverables yet
                </div>
              )}
            </div>
          </div>

        </div>
      )}

      {/* 5. WIDE TASK DETAIL MODAL: Clear Note Display & 3-Category Switcher */}
      <TaskDetailWideModal
        task={selectedTaskForDetail}
        isOpen={Boolean(selectedTaskForDetail)}
        onClose={() => setSelectedTaskForDetail(null)}
        onUpdateStatus={(id, status) => {
          if (onUpdateStatus) {
            onUpdateStatus(id, status);
          } else {
            if (status === 'completed') {
              onToggleComplete(id);
            }
          }
          setSelectedTaskForDetail((prev) =>
            prev && prev.id === id ? { ...prev, status, completed: status === 'completed' } : prev
          );
        }}
        onUpdateDescription={(id, description) => {
          if (onUpdateDescription) {
            onUpdateDescription(id, description);
          }
          setSelectedTaskForDetail((prev) =>
            prev && prev.id === id ? { ...prev, description } : prev
          );
        }}
        onToggleSubtask={(taskId, subtaskId) => {
          onToggleSubtask(taskId, subtaskId);
          setSelectedTaskForDetail((prev) => {
            if (!prev || prev.id !== taskId) return prev;
            return {
              ...prev,
              subtasks: prev.subtasks.map((s) => (s.id === subtaskId ? { ...s, completed: !s.completed } : s)),
            };
          });
        }}
        onAddSubtask={(taskId, title) => {
          if (onAddSubtask) {
            onAddSubtask(taskId, title);
          }
          setSelectedTaskForDetail((prev) => {
            if (!prev || prev.id !== taskId) return prev;
            const newSub = { id: `st_${Date.now()}`, title, completed: false };
            return {
              ...prev,
              subtasks: [...(prev.subtasks || []), newSub],
            };
          });
        }}
        onEditFullTask={(task) => {
          setSelectedTaskForDetail(null);
          onEdit(task);
        }}
        onDeleteTask={(id) => {
          onDelete(id);
          setSelectedTaskForDetail(null);
        }}
        isSuperAdmin={isSuperAdmin}
        onUpdateRating={(id, rating) => {
          if (onUpdateRating) {
            onUpdateRating(id, rating);
          }
          setSelectedTaskForDetail((prev) =>
            prev && prev.id === id ? { ...prev, rating } : prev
          );
        }}
      />

    </div>
  );
};
