import React, { useState } from 'react';
import {
  Inbox,
  Calendar,
  CalendarDays,
  Bell,
  CheckCircle2,
  Users,
  Building2,
  Plus,
  Trash2,
  Clock,
  Briefcase,
  UserPlus,
  Volume2,
  Crown,
  User,
  ExternalLink,
  Megaphone,
  LogOut,
  LogIn,
  ShieldCheck,
  ArrowRight,
  MapPin,
  FileSpreadsheet,
  ShieldAlert,
  CheckCheck,
  Image as ImageIcon,
  ChevronDown,
  BarChart3,
  QrCode,
  RefreshCw
} from 'lucide-react';
import { Task, ViewFilter, Employee, ActivePage, CompanyShift, checkIsSuperAdmin } from '../types/task';
import { getNotificationPermission, requestNotificationPermission, sendPushNotification } from '../services/notificationService';

interface SidebarProps {
  currentView: ViewFilter;
  onSelectView: (view: ViewFilter) => void;
  departments: string[];
  employees: Employee[];
  currentUser: Employee;
  companyShift?: CompanyShift;
  onAddEmployee: (emp: Partial<Employee>) => void;
  onOpenProfile: (emp: Employee) => void;
  selectedPriority: string | null;
  onSelectPriority: (priority: string | null) => void;
  tasks: Task[];
  onOpenNewTask: () => void;
  activePage?: ActivePage;
  onNavigatePage?: (page: ActivePage) => void;
  noticesCount?: number;
  onLogout?: () => void;
  onPunchIn?: () => void;
  onPunchOut?: () => void;
  onOpenLeaveModal?: () => void;
  isOpen?: boolean;
  onOpenUpdateShift?: () => void;
  onApproveAllTasks?: () => void;
  onExportMasterSheet?: () => void;
  onOpenChangeLogo?: () => void;
  onOpenNotices?: () => void;
  onOpenQRScanner?: (action: 'punch-in' | 'punch-out') => void;
  onOpenQRGenerator?: () => void;
  onRefreshData?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  onSelectView,
  departments,
  employees,
  currentUser,
  companyShift,
  onAddEmployee,
  onOpenProfile,
  selectedPriority,
  onSelectPriority,
  tasks,
  onOpenNewTask,
  activePage,
  onNavigatePage,
  noticesCount = 0,
  onLogout,
  onPunchIn,
  onPunchOut,
  onOpenLeaveModal,
  isOpen,
  onOpenUpdateShift,
  onApproveAllTasks,
  onExportMasterSheet,
  onOpenChangeLogo,
  onOpenNotices,
  onOpenQRScanner,
  onOpenQRGenerator,
  onRefreshData,
}) => {
  const [isAddingEmp, setIsAddingEmp] = useState(false);
  const [newEmpName, setNewEmpName] = useState('');
  const [showCeoControls, setShowCeoControls] = useState(false);
  const [newEmpRole, setNewEmpRole] = useState('');
  const [newEmpDept, setNewEmpDept] = useState(departments[0] || 'Business Development & Tech');
  const [permission, setPermission] = useState(getNotificationPermission());

  const todayStr = new Date().toISOString().split('T')[0];

  const countAll = tasks.filter((t) => !t.completed).length;
  const countToday = tasks.filter(
    (t) => !t.completed && (t.dueDate === todayStr || (t.dueDate && t.dueDate < todayStr))
  ).length;
  const countUpcoming = tasks.filter(
    (t) => !t.completed && t.dueDate && t.dueDate > todayStr
  ).length;
  const countReminders = tasks.filter(
    (t) => !t.completed && Boolean(t.reminderTime)
  ).length;
  const countCompleted = tasks.filter((t) => t.completed).length;

  const totalTodayHours = tasks
    .filter((t) => t.dueDate === todayStr)
    .reduce((acc, t) => acc + (t.durationHours || 1.0), 0);

  const isSuperAdmin = checkIsSuperAdmin(currentUser);

  const handleCreateEmployee = (e: React.FormEvent) => {
    e.preventDefault();
    if (newEmpName.trim()) {
      onAddEmployee({
        name: newEmpName.trim(),
        role: newEmpRole.trim() || 'Operations Specialist',
        department: newEmpDept
      });
      setNewEmpName('');
      setNewEmpRole('');
      setIsAddingEmp(false);
    }
  };

  const handleEnableNotifications = async () => {
    const res = await requestNotificationPermission();
    setPermission(res);
    if (res === 'granted') {
      sendPushNotification('MANDIDEALS Alerts Active', 'You will now receive shift and task reminders.');
    }
  };

  return (
    <aside className={`fixed inset-y-0 left-0 md:relative z-50 md:z-auto transition-transform duration-300 ease-in-out ${
      isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0 pointer-events-none md:pointer-events-auto'
    } w-[300px] md:w-64 lg:w-72 h-[100dvh] md:h-auto flex-none md:shrink-0 flex flex-col gap-2 md:gap-4 py-3 md:py-5 px-1 md:px-3.5 border-r border-neutral-200/80 bg-white dark:border-neutral-800/80 dark:bg-neutral-900 text-xs overflow-y-auto shadow-2xl md:shadow-none pb-24 md:pb-5 overscroll-contain rounded-r-[32px] md:rounded-none`}>
      
      {/* QR Scanner Global Integration */}
      <button 
        onClick={() => onOpenQRScanner?.(currentUser.isPunchedIn ? 'punch-out' : 'punch-in')}
        className="flex items-center justify-center gap-2 w-full py-3 rounded-2xl bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-900/50 font-black uppercase tracking-widest text-[10px] shadow-xs hover:bg-indigo-100 dark:hover:bg-indigo-900/60 transition active:scale-95 group shrink-0"
      >
        <QrCode className="w-4 h-4 group-hover:rotate-12 transition-transform" />
        <span>Scan Complex QR</span>
      </button>

      {/* 1. Logged In Member Card (With Direct Link to Separate Profile Page) */}
      <div 
        onClick={() => onOpenProfile(currentUser)}
        className={`p-2 md:p-3.5 rounded-2xl md:rounded-3xl border transition-all duration-300 shadow-sm relative overflow-hidden cursor-pointer hover:shadow-md active:scale-[0.98] group/card flex-none flex flex-row md:flex-col items-center md:items-stretch gap-3 md:justify-center ${
        isSuperAdmin
          ? 'bg-gradient-to-br from-amber-50 to-white dark:from-amber-950/40 dark:to-neutral-900 border-amber-300 dark:border-amber-700/60'
          : 'bg-white dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800'
      }`}>
        {currentUser.isPunchedIn && (
          <div className="absolute top-0 right-0 px-2 py-0.5 bg-emerald-500 text-white text-[8px] font-black uppercase tracking-widest rounded-bl-xl shadow-sm z-10">
            Active
          </div>
        )}
        
        <div className="flex items-center gap-2 md:gap-3 min-w-0">
          <div className={`w-8 h-8 md:w-10 md:h-10 rounded-lg md:rounded-xl flex items-center justify-center font-bold text-[10px] md:text-xs shrink-0 overflow-hidden shadow-sm border ${
            isSuperAdmin
              ? 'bg-amber-500 text-slate-950 border-amber-400 font-black'
              : 'bg-neutral-900 text-white dark:bg-neutral-100 dark:text-neutral-900 border-neutral-200 dark:border-neutral-700'
          }`}>
            {currentUser.avatar ? (
              <img src={currentUser.avatar} alt={currentUser.name} className="w-full h-full object-cover" />
            ) : (
              (currentUser.name || '?').charAt(0)
            )}
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1 flex-nowrap min-w-0">
              <span className="font-extrabold text-[11px] md:text-xs text-neutral-900 dark:text-neutral-100 truncate min-w-0">
                {currentUser.name}
              </span>
              {isSuperAdmin && (
                <Crown className="w-3 md:w-3.5 h-3 md:h-3.5 text-amber-500 shrink-0" />
              )}
            </div>
            <div className="flex items-center justify-between gap-1">
              <span className="text-[9px] md:text-[10px] text-neutral-400 font-medium truncate block">
                {isSuperAdmin ? 'Super Admin · CEO' : currentUser.role}
              </span>
              <User className="hidden md:block w-3 h-3 text-neutral-300 group-hover/card:text-emerald-500 transition-colors shrink-0" />
            </div>
          </div>
        </div>

        {/* Compact Punch Status on Mobile */}
        <div className="md:hidden ml-auto">
          {currentUser.isPunchedIn ? (
            <span className="text-[9px] font-black text-emerald-600 dark:text-emerald-400 uppercase">On Duty</span>
          ) : (
            <span className="text-[9px] font-bold text-neutral-400 uppercase">Off Duty</span>
          )}
        </div>
      </div>

      {/* 2. CEO Master Controls Section (Super Admin Only) */}
      {isSuperAdmin && (
        <div className="space-y-1">
          <button
            onClick={() => setShowCeoControls(!showCeoControls)}
            className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl bg-amber-500 text-slate-950 shadow-sm transition-all hover:bg-amber-400 active:scale-[0.98] cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 stroke-[2.5]" />
              <span className="font-black uppercase tracking-tight text-[10px] md:text-xs">CEO Master Console</span>
            </div>
            <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-300 ${showCeoControls ? 'rotate-180' : ''}`} />
          </button>

          {showCeoControls && (
            <div className="p-1 space-y-1 bg-amber-50/50 dark:bg-amber-950/20 rounded-2xl border border-amber-200/50 dark:border-amber-900/30 animate-in slide-in-from-top-2 duration-200 max-h-[60vh] overflow-y-auto custom-scrollbar">
              {onNavigatePage && (
                <button
                  onClick={() => onNavigatePage('admin')}
                  className="w-full flex items-center gap-2 px-3 py-2 rounded-xl hover:bg-white/80 dark:hover:bg-amber-900/40 text-slate-900 dark:text-amber-200 font-bold transition-colors cursor-pointer text-[10px] md:text-xs"
                >
                  <ShieldCheck className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Administrative Control Panel</span>
                  {employees.some(e => e.isAuthorized === false) && (
                    <span className="ml-auto h-2 w-2 rounded-full bg-rose-500 animate-pulse" />
                  )}
                </button>
              )}
              {onOpenUpdateShift && (
                <button
                  onClick={onOpenUpdateShift}
                  className="w-full flex items-center gap-2 px-3 py-2 rounded-xl hover:bg-white/80 dark:hover:bg-amber-900/40 text-slate-900 dark:text-amber-200 font-bold transition-colors cursor-pointer text-[10px] md:text-xs"
                >
                  <Clock className="w-3.5 h-3.5 text-amber-600" />
                  <span>Update Work Shift</span>
                </button>
              )}
              {onNavigatePage && (
                <button
                  onClick={() => onNavigatePage('performance')}
                  className="w-full flex items-center gap-2 px-3 py-2 rounded-xl hover:bg-white/80 dark:hover:bg-amber-900/40 text-slate-900 dark:text-amber-200 font-bold transition-colors cursor-pointer text-[10px] md:text-xs"
                >
                  <BarChart3 className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Performance Metrics</span>
                </button>
              )}
              {onOpenQRGenerator && (
                <button
                  onClick={onOpenQRGenerator}
                  className="w-full flex items-center gap-2 px-3 py-2 rounded-xl hover:bg-white/80 dark:hover:bg-amber-900/40 text-slate-900 dark:text-amber-200 font-bold transition-colors cursor-pointer text-[10px] md:text-xs"
                >
                  <QrCode className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Generate Complex QR</span>
                </button>
              )}
              {onOpenNotices && (
                <button
                  onClick={onOpenNotices}
                  className="w-full flex items-center gap-2 px-3 py-2 rounded-xl hover:bg-white/80 dark:hover:bg-amber-900/40 text-slate-900 dark:text-amber-200 font-bold transition-colors cursor-pointer text-[10px] md:text-xs"
                >
                  <Megaphone className="w-3.5 h-3.5 text-amber-600" />
                  <span>Post Notice Board</span>
                </button>
              )}
              {onApproveAllTasks && (
                <button
                  onClick={onApproveAllTasks}
                  className="w-full flex items-center gap-2 px-3 py-2 rounded-xl hover:bg-white/80 dark:hover:bg-amber-900/40 text-slate-900 dark:text-amber-200 font-bold transition-colors cursor-pointer text-[10px] md:text-xs"
                >
                  <CheckCheck className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Approve All Work Logs</span>
                </button>
              )}
              {onExportMasterSheet && (
                <button
                  onClick={onExportMasterSheet}
                  className="w-full flex items-center gap-2 px-3 py-2 rounded-xl hover:bg-white/80 dark:hover:bg-amber-900/40 text-slate-900 dark:text-amber-200 font-bold transition-colors cursor-pointer text-[10px] md:text-xs"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Export Master Sheet</span>
                </button>
              )}
              {onOpenChangeLogo && (
                <button
                  onClick={onOpenChangeLogo}
                  className="w-full flex items-center gap-2 px-3 py-2 rounded-xl hover:bg-white/80 dark:hover:bg-amber-900/40 text-slate-900 dark:text-amber-200 font-bold transition-colors cursor-pointer text-[10px] md:text-xs"
                >
                  <ImageIcon className="w-3.5 h-3.5 text-amber-600" />
                  <span>Change Company Logo</span>
                </button>
              )}
              {onRefreshData && (
                <button
                  onClick={onRefreshData}
                  className="w-full flex items-center gap-2 px-3 py-2 rounded-xl hover:bg-white/80 dark:hover:bg-amber-900/40 text-slate-900 dark:text-amber-200 font-bold transition-colors cursor-pointer text-[10px] md:text-xs"
                >
                  <RefreshCw className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Refresh Cloud Data</span>
                </button>
              )}
              <button
                onClick={() => onOpenProfile(currentUser)}
                className="w-full flex items-center gap-2 px-3 py-2 rounded-xl hover:bg-white/80 dark:hover:bg-amber-900/40 text-slate-900 dark:text-amber-200 font-bold transition-colors cursor-pointer text-[10px] md:text-xs"
              >
                <User className="w-3.5 h-3.5 text-slate-600" />
                <span>My Workspace Profile</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* 3. Attendance & Punch In/Out (Universal Design) - Very compact on Mobile */}
      <div className="rounded-2xl border border-neutral-200/80 bg-white p-2 md:p-3.5 dark:border-neutral-800 dark:bg-neutral-900 shadow-2xs space-y-2 md:space-y-3">
        <div className="hidden md:flex items-center justify-between text-neutral-500 dark:text-neutral-400">
          <span className="text-[10px] font-bold uppercase tracking-wider flex items-center gap-1">
            <Clock className="h-3 w-3 text-emerald-600 dark:text-emerald-400" />
            Attendance System
          </span>
        </div>

        <div className="flex flex-row md:flex-col gap-2">
          {!currentUser.isPunchedIn ? (
            <button
              onClick={onPunchIn}
              className="flex-1 flex items-center justify-center gap-2 py-1.5 md:py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] md:text-xs font-bold transition shadow-sm active:scale-95"
            >
              <LogIn className="w-3.5 h-3.5 md:w-4 md:h-4" />
              <span className="truncate">Punch In</span>
            </button>
          ) : (
            <button
              onClick={onPunchOut}
              className="flex-1 flex items-center justify-center gap-2 py-1.5 md:py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-[10px] md:text-xs font-bold transition shadow-sm active:scale-95"
            >
              <LogOut className="w-3.5 h-3.5 md:w-4 md:h-4" />
              <span className="truncate">Punch Out</span>
            </button>
          )}

          <button
            onClick={onOpenLeaveModal}
            className="flex-1 flex items-center justify-center gap-2 py-1.5 md:py-2 rounded-xl border border-neutral-200 dark:border-neutral-700 hover:bg-neutral-50 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300 text-[10px] md:text-xs font-bold transition"
          >
            <CalendarDays className="w-3.5 h-3.5 md:w-4 md:h-4 text-indigo-500" />
            <span className="truncate text-center">Request Leave</span>
          </button>
        </div>
      </div>

      {/* 2b. MANDIDEALS Shift Stats Widget - Hidden or very compact on mobile */}
      <div className="hidden md:block rounded-2xl border border-neutral-200/80 bg-white p-3.5 dark:border-neutral-800 dark:bg-neutral-900 shadow-2xs space-y-2">
        <div className="flex items-center justify-between text-neutral-500 dark:text-neutral-400">
          <span className="text-[10px] font-bold uppercase tracking-wider flex items-center gap-1">
            <Clock className="h-3 w-3 text-emerald-600 dark:text-emerald-400" />
            12-Hour Shift
          </span>
          <span className="font-mono text-[10px] font-bold px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-900 dark:bg-emerald-950 dark:text-emerald-300">
            {companyShift?.durationHours || 8.0}h Target
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span className="font-mono text-xs font-bold text-neutral-900 dark:text-neutral-100">
            {companyShift?.startTime12 || '10:30 AM'} – {companyShift?.endTime12 || '06:30 PM'}
          </span>
        </div>
        <div className="pt-1 flex items-baseline justify-between text-[11px]">
          <span className="text-neutral-500 dark:text-neutral-400">Hours Logged Today:</span>
          <span className="font-mono font-bold text-neutral-900 dark:text-neutral-100">
            {totalTodayHours.toFixed(1)}h / {companyShift?.durationHours || 8.0}h
          </span>
        </div>
        <div className="w-full bg-neutral-100 dark:bg-neutral-800 rounded-full h-1.5 overflow-hidden">
          <div
            className="bg-emerald-600 dark:bg-emerald-500 h-1.5 rounded-full transition-all duration-300"
            style={{ width: `${Math.min(100, (totalTodayHours / (companyShift?.durationHours || 8.0)) * 100)}%` }}
          />
        </div>
      </div>

      {/* 3. Operations Views Section */}
      <div className="space-y-1">
        <span className="text-[10px] font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider px-2 block mb-1">
          Work Views & Notices
        </span>

        <div className="grid grid-cols-3 gap-2 md:flex md:flex-col md:gap-1">
          {/* Company Notice Board navigation */}
          {onNavigatePage && (
            <button
              onClick={() => onNavigatePage('notices')}
              className={`flex flex-col md:flex-row items-center md:justify-between px-2 py-3 md:px-3 md:py-2 rounded-xl font-medium transition cursor-pointer select-none ${
                activePage === 'notices'
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-xs'
                  : 'text-neutral-700 hover:bg-amber-100/60 dark:text-amber-300 dark:hover:bg-amber-950/40'
              }`}
            >
              <div className="flex flex-col md:flex-row items-center gap-1 md:gap-2.5">
                <Megaphone className={`h-4 w-4 shrink-0 ${activePage === 'notices' ? 'text-slate-950' : 'text-amber-500'}`} />
                <span className="text-[9px] md:text-xs text-center md:text-left leading-tight">Notice<br className="md:hidden" /> Board</span>
              </div>
              {noticesCount > 0 && (
                <span
                  className={`hidden md:inline font-mono text-[10px] px-1.5 py-0.2 rounded-full font-bold shrink-0 ${
                    activePage === 'notices'
                      ? 'bg-slate-950 text-amber-300'
                      : 'bg-amber-200 text-amber-900 dark:bg-amber-900/80 dark:text-amber-200'
                  }`}
                >
                  {noticesCount}
                </span>
              )}
            </button>
          )}

          {/* Attendance Dashboard navigation */}
          {onNavigatePage && (
            <button
              onClick={() => onNavigatePage('attendance')}
              className={`flex flex-col md:flex-row items-center md:justify-between px-2 py-3 md:px-3 md:py-2 rounded-xl font-medium transition cursor-pointer select-none ${
                activePage === 'attendance'
                  ? 'bg-emerald-600 text-white font-bold shadow-xs'
                  : 'text-neutral-700 hover:bg-emerald-50 dark:text-emerald-300 dark:hover:bg-emerald-950/40'
              }`}
            >
              <div className="flex flex-col md:flex-row items-center gap-1 md:gap-2.5">
                <Clock className={`h-4 w-4 shrink-0 ${activePage === 'attendance' ? 'text-white' : 'text-emerald-500'}`} />
                <span className="text-[9px] md:text-xs text-center md:text-left leading-tight">Time<br className="md:hidden" /> Logs</span>
              </div>
            </button>
          )}

          {/* Performance Metrics navigation */}
          {onNavigatePage && isSuperAdmin && (
            <button
              onClick={() => onNavigatePage('performance')}
              className={`flex flex-col md:flex-row items-center md:justify-between px-2 py-3 md:px-3 md:py-2 rounded-xl font-medium transition cursor-pointer select-none ${
                activePage === 'performance'
                  ? 'bg-indigo-600 text-white font-bold shadow-xs'
                  : 'text-neutral-700 hover:bg-indigo-50 dark:text-indigo-300 dark:hover:bg-indigo-950/40'
              }`}
            >
              <div className="flex flex-col md:flex-row items-center gap-1 md:gap-2.5">
                <BarChart3 className={`h-4 w-4 shrink-0 ${activePage === 'performance' ? 'text-white' : 'text-indigo-500'}`} />
                <span className="text-[9px] md:text-xs text-center md:text-left leading-tight">Metrics<br className="md:hidden" /> Center</span>
              </div>
            </button>
          )}

          <button
            onClick={() => {
              onSelectView('all');
              if (onNavigatePage) onNavigatePage('tasks');
            }}
            className={`flex flex-col md:flex-row items-center md:justify-between px-2 py-3 md:px-3 md:py-2 rounded-xl font-medium transition cursor-pointer select-none ${
              activePage === 'tasks' && currentView === 'all'
                ? 'bg-neutral-900 text-white dark:bg-neutral-100 dark:text-neutral-900 shadow-2xs font-semibold'
                : 'text-neutral-600 hover:bg-neutral-200/50 hover:text-neutral-900 dark:text-neutral-400 dark:hover:bg-neutral-800 dark:hover:text-neutral-100'
            }`}
          >
            <div className="flex flex-col md:flex-row items-center gap-1 md:gap-2.5">
              <Inbox className="h-4 w-4 shrink-0" />
              <span className="text-[9px] md:text-xs text-center md:text-left leading-tight">All<br className="md:hidden" /> Logs</span>
            </div>
          </button>

          <button
            onClick={() => onSelectView('today')}
            className={`flex flex-col md:flex-row items-center md:justify-between px-2 py-3 md:px-3 md:py-2 rounded-xl font-medium transition cursor-pointer select-none ${
              currentView === 'today'
                ? 'bg-neutral-900 text-white dark:bg-neutral-100 dark:text-neutral-900 shadow-2xs font-semibold'
                : 'text-neutral-600 hover:bg-neutral-200/50 hover:text-neutral-900 dark:text-neutral-400 dark:hover:bg-neutral-800 dark:hover:text-neutral-100'
            }`}
          >
            <div className="flex flex-col md:flex-row items-center gap-1 md:gap-2.5">
              <Calendar className="h-4 w-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <span className="text-[9px] md:text-xs text-center md:text-left leading-tight">Today's<br className="md:hidden" /> Shift</span>
            </div>
          </button>

          <button
            onClick={() => onSelectView('upcoming')}
            className={`flex flex-col md:flex-row items-center md:justify-between px-2 py-3 md:px-3 md:py-2 rounded-xl font-medium transition cursor-pointer select-none ${
              currentView === 'upcoming'
                ? 'bg-neutral-900 text-white dark:bg-neutral-100 dark:text-neutral-900 shadow-2xs font-semibold'
                : 'text-neutral-600 hover:bg-neutral-200/50 hover:text-neutral-900 dark:text-neutral-400 dark:hover:bg-neutral-800 dark:hover:text-neutral-100'
            }`}
          >
            <div className="flex flex-col md:flex-row items-center gap-1 md:gap-2.5">
              <CalendarDays className="h-4 w-4 text-blue-600 dark:text-blue-400 shrink-0" />
              <span className="text-[9px] md:text-xs text-center md:text-left leading-tight">Upcoming<br className="md:hidden" /> Roster</span>
            </div>
          </button>

          <button
            onClick={() => onSelectView('reminders')}
            className={`flex flex-col md:flex-row items-center md:justify-between px-2 py-3 md:px-3 md:py-2 rounded-xl font-medium transition cursor-pointer select-none ${
              currentView === 'reminders'
                ? 'bg-neutral-900 text-white dark:bg-neutral-100 dark:text-neutral-900 shadow-2xs font-semibold'
                : 'text-neutral-600 hover:bg-neutral-200/50 hover:text-neutral-900 dark:text-neutral-400 dark:hover:bg-neutral-800 dark:hover:text-neutral-100'
            }`}
          >
            <div className="flex flex-col md:flex-row items-center gap-1 md:gap-2.5">
              <Bell className="h-4 w-4 text-amber-500 shrink-0" />
              <span className="text-[9px] md:text-xs text-center md:text-left leading-tight">Shift<br className="md:hidden" /> Alerts</span>
            </div>
          </button>

          <button
            onClick={() => onSelectView('completed')}
            className={`flex flex-col md:flex-row items-center md:justify-between px-2 py-3 md:px-3 md:py-2 rounded-xl font-medium transition cursor-pointer select-none ${
              currentView === 'completed'
                ? 'bg-neutral-900 text-white dark:bg-neutral-100 dark:text-neutral-900 shadow-2xs font-semibold'
                : 'text-neutral-600 hover:bg-neutral-200/50 hover:text-neutral-900 dark:text-neutral-400 dark:hover:bg-neutral-800 dark:hover:text-neutral-100'
            }`}
          >
            <div className="flex flex-col md:flex-row items-center gap-1 md:gap-2.5">
              <CheckCircle2 className="h-4 w-4 text-neutral-400 dark:text-neutral-500 shrink-0" />
              <span className="text-[9px] md:text-xs text-center md:text-left leading-tight">Signed<br className="md:hidden" /> Off</span>
            </div>
          </button>
        </div>
      </div>

      {/* 4. Member Workspaces Section (Exclusively for Sabyasachi / Super Admin) */}
      {isSuperAdmin ? (
        <div className="space-y-1">
          <div className="flex items-center justify-between px-2 mb-1">
            <div className="flex items-center gap-1.5">
              <Briefcase className="h-3 w-3 text-emerald-600" />
              <span className="text-[10px] font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider">
                All Member Workspaces ({employees.length})
              </span>
            </div>
            <div className="flex items-center gap-1">
              <span className="text-[9px] font-black uppercase px-1.5 py-0.2 rounded bg-amber-100 text-amber-900 dark:bg-amber-950 dark:text-amber-300 border border-amber-300/60 dark:border-amber-700/60">
                Sabyasachi Only
              </span>
              <button
                onClick={() => setIsAddingEmp(!isAddingEmp)}
                className="p-1 rounded text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200"
                title="Register New Employee Workspace"
              >
                <UserPlus className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>

          {isAddingEmp && (
            <form onSubmit={handleCreateEmployee} className="px-2 py-2 mb-2 rounded-xl bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 space-y-1.5">
              <input
                type="text"
                required
                value={newEmpName}
                onChange={(e) => setNewEmpName(e.target.value)}
                placeholder="Staff Name..."
                className="w-full rounded-lg border border-neutral-300 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-900 px-2.5 py-1 text-xs text-neutral-900 dark:text-neutral-100 placeholder:text-neutral-400 focus:outline-none"
              />
              <input
                type="text"
                value={newEmpRole}
                onChange={(e) => setNewEmpRole(e.target.value)}
                placeholder="Role (e.g. Ops Lead)..."
                className="w-full rounded-lg border border-neutral-300 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-900 px-2.5 py-1 text-xs text-neutral-900 dark:text-neutral-100 placeholder:text-neutral-400 focus:outline-none"
              />
              <div className="flex justify-end gap-1.5 pt-1">
                <button
                  type="button"
                  onClick={() => setIsAddingEmp(false)}
                  className="px-2 py-0.5 text-[10px] text-neutral-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-2.5 py-0.5 bg-emerald-600 text-white rounded-md text-[10px] font-semibold"
                >
                  Add Staff
                </button>
              </div>
            </form>
          )}

          <div className="space-y-0.5">
            {employees.map((emp) => {
              const empTasks = tasks.filter((t) => (t.employeeName || '').toLowerCase() === (emp.name || '').toLowerCase());
              const activeCount = empTasks.filter((t) => !t.completed).length;
              const empHours = empTasks.reduce((acc, t) => acc + (t.durationHours || 1.0), 0);
              const isEmpSelected = currentView === `emp:${emp.name}`;
              const isEmpCeo = emp.isSuperAdmin || emp.accessLevel === 'SUPER_ADMIN';

              return (
                <div
                  key={emp.id}
                  className={`group flex items-center justify-between rounded-xl px-2.5 py-1.5 transition ${
                    isEmpSelected
                      ? 'bg-neutral-900 text-white dark:bg-neutral-100 dark:text-neutral-900 font-semibold shadow-2xs'
                      : 'text-neutral-700 hover:bg-neutral-200/50 dark:text-neutral-300 dark:hover:bg-neutral-800'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => {
                      onSelectView(`emp:${emp.name}`);
                      if (onNavigatePage) onNavigatePage('tasks');
                    }}
                    className="flex items-center gap-2 min-w-0 flex-1 text-left"
                    title={`Open ${emp.name}'s Workspace`}
                  >
                    <div className={`h-6 w-6 rounded-lg flex items-center justify-center font-bold text-[10px] shrink-0 ${
                      isEmpCeo
                        ? 'bg-amber-400 text-slate-950 font-black'
                        : isEmpSelected
                        ? 'bg-white text-neutral-900 dark:bg-neutral-900 dark:text-white'
                        : 'bg-neutral-200 text-neutral-700 dark:bg-neutral-800 dark:text-neutral-300'
                    }`}>
                      {emp.avatar ? (
                        <img src={emp.avatar} alt={emp.name} className="w-full h-full object-cover rounded-lg" />
                      ) : (
                        (emp.name || '?').charAt(0)
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <span className="block truncate text-xs font-semibold">
                        {emp.name}
                      </span>
                      <span className={`block truncate text-[10px] ${isEmpSelected ? 'text-neutral-300 dark:text-neutral-600' : 'text-neutral-400'}`}>
                        {isEmpCeo ? '👑 CEO (Admin)' : `${emp.role} · Workspace`}
                      </span>
                    </div>
                  </button>

                  <div className="flex items-center gap-1.5 pl-1 shrink-0">
                    <span className={`font-mono text-[10px] ${isEmpSelected ? 'text-neutral-300 dark:text-neutral-700' : 'text-neutral-400'}`}>
                      {empHours.toFixed(1)}h
                    </span>

                    {/* Direct Button to open Member's Separate Profile Page */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onOpenProfile(emp);
                      }}
                      className={`p-1 rounded-md transition ${
                        isEmpSelected
                          ? 'text-neutral-200 hover:text-white dark:text-neutral-700 dark:hover:text-black'
                          : 'text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-100 hover:bg-neutral-200/60 dark:hover:bg-neutral-700'
                      }`}
                      title={`Inspect ${emp.name}'s Full Workspace Profile`}
                    >
                      <ExternalLink className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        /* Regular Staff: Privacy Guard Notice & Isolated Personal Workspace Card */
        <div className="p-3.5 rounded-2xl border border-neutral-200/80 dark:border-neutral-800 bg-white/70 dark:bg-neutral-900/70 space-y-2.5 shadow-2xs">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-xs font-bold text-neutral-900 dark:text-neutral-100">
              <Briefcase className="w-3.5 h-3.5 text-emerald-600" />
              <span>My Workspace</span>
            </div>
            <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950/70 text-emerald-800 dark:text-emerald-300 font-bold border border-emerald-200 dark:border-emerald-800">
              Private
            </span>
          </div>

          <div className="p-2.5 rounded-xl bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-100 dark:border-neutral-800 text-[11px] space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-neutral-500 dark:text-neutral-400">My Deliverables:</span>
              <span className="font-bold font-mono text-neutral-900 dark:text-neutral-100">{tasks.length} active</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-neutral-500 dark:text-neutral-400">Shift Logged Today:</span>
              <span className="font-bold font-mono text-emerald-600 dark:text-emerald-400">{totalTodayHours.toFixed(1)} hrs</span>
            </div>
          </div>

          <div className="rounded-xl bg-amber-50/90 dark:bg-amber-950/30 border border-amber-200/80 dark:border-amber-900/50 p-2.5">
            <p className="text-[10px] text-amber-900 dark:text-amber-300 font-medium leading-relaxed">
              🔒 <strong>Company Policy:</strong> All member workspaces and work logs are shown only to Super Admin (Sabyasachi). Other team members cannot view your workspace, and you cannot view theirs.
            </p>
          </div>

          <button
            onClick={() => onOpenProfile(currentUser)}
            className="w-full flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-neutral-100 dark:hover:bg-neutral-200 dark:text-neutral-900 text-[11px] font-semibold transition shadow-2xs"
          >
            <span>Open My Workspace Profile</span>
            <ExternalLink className="w-3 h-3" />
          </button>
        </div>
      )}

      {/* 5. Company Departments / Work Streams */}
      <div className="space-y-1">
        <span className="text-[10px] font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-wider px-2 block mb-1">
          {isSuperAdmin ? 'Departments & Streams' : 'My Department Streams'}
        </span>

        <div className="space-y-0.5">
          {departments.map((dept) => {
            const count = tasks.filter((t) => !t.completed && t.department === dept).length;
            const isSelected = currentView === `dept:${dept}`;

            return (
              <button
                key={dept}
                onClick={() => onSelectView(`dept:${dept}`)}
                className={`w-full group flex items-center justify-between rounded-xl px-2.5 py-1.5 transition text-left ${
                  isSelected
                    ? 'font-semibold text-neutral-900 dark:text-neutral-100 bg-neutral-200/60 dark:bg-neutral-800'
                    : 'text-neutral-600 hover:bg-neutral-200/40 dark:text-neutral-400 dark:hover:bg-neutral-800/60'
                }`}
              >
                <div className="flex items-center gap-2 truncate flex-1">
                  <Building2 className="h-3.5 w-3.5 text-neutral-400 shrink-0" />
                  <span className="truncate">{dept}</span>
                </div>
                <span className="font-mono text-[10px] text-neutral-400 dark:text-neutral-500 ml-1">
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 6. Push Notification Support Card */}
      {permission !== 'granted' && (
        <div className="mt-auto rounded-2xl border border-amber-200/80 bg-amber-50/70 p-3 dark:border-amber-900/60 dark:bg-amber-950/30">
          <div className="flex items-start gap-2">
            <Volume2 className="h-4 w-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <span className="font-semibold text-amber-900 dark:text-amber-200 block text-[11px]">
                Shift Push Alerts
              </span>
              <p className="text-[10px] text-amber-800/80 dark:text-amber-300/80 leading-relaxed">
                Receive browser alerts and chime sounds for task start and end times.
              </p>
              {permission === 'denied' ? (
                <div className="mt-2 p-1.5 rounded bg-rose-50 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900/50 text-[9px] text-rose-600 dark:text-rose-400 font-bold">
                  Notifications blocked. Please check browser settings to allow "MANDIDEALS" to send alerts.
                </div>
              ) : (
                <button
                  onClick={handleEnableNotifications}
                  className="mt-1.5 w-full rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-semibold py-1.5 px-2 text-[11px] transition shadow-2xs"
                >
                  Allow Notifications
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 7. Footer & Sign Out */}
      <div className="mt-auto pt-4 border-t border-neutral-200/80 dark:border-neutral-800 space-y-3 pb-8">
        {onLogout && (
          <button
            type="button"
            onClick={onLogout}
            className="w-full flex items-center justify-center gap-2 py-3 rounded-2xl bg-rose-50 dark:bg-rose-950/30 text-rose-600 dark:text-rose-400 text-xs font-black uppercase tracking-wider transition-all hover:bg-rose-100 dark:hover:bg-rose-900/40 active:scale-[0.98] cursor-pointer shadow-sm border border-rose-100 dark:border-rose-900/50"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out Session</span>
          </button>
        )}
        <div className="text-[10px] text-neutral-400 dark:text-neutral-500 px-3 flex items-center justify-between font-bold">
          <span className="uppercase tracking-tighter">{companyShift?.startTime12 || '10:30 AM'} Shift</span>
          <span className="text-emerald-500 font-black truncate ml-2">CEO Sabyasachi</span>
        </div>
      </div>

    </aside>
  );
};
