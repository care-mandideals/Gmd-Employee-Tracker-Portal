import React, { useState } from 'react';
import { 
  Users, 
  CheckCircle, 
  XCircle, 
  Clock, 
  Calendar,
  ShieldCheck,
  UserCheck,
  Plus,
  Pencil,
  Trash2,
  X,
  ShieldAlert
} from 'lucide-react';
import { Employee, LeaveRequest } from '../types/task';

interface AdminViewProps {
  employees: Employee[];
  leaveRequests: LeaveRequest[];
  onToggleAuthorization: (id: string, isAuthorized: boolean) => void;
  onUpdateAccessLevel: (id: string, level: Employee['accessLevel']) => void;
  onUpdateLeaveStatus: (id: string, status: 'approved' | 'rejected') => void;
  onAddEmployee: (emp: Omit<Employee, 'id' | 'isAuthorized'>) => void;
  onUpdateEmployee: (emp: Employee) => void;
  onDeleteEmployee: (id: string) => void;
  currentUser: Employee;
}

export const AdminView: React.FC<AdminViewProps> = ({
  employees,
  leaveRequests,
  onToggleAuthorization,
  onUpdateAccessLevel,
  onUpdateLeaveStatus,
  onAddEmployee,
  onUpdateEmployee,
  onDeleteEmployee,
  currentUser,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingEmp, setEditingEmp] = useState<Employee | null>(null);

  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [revokeConfirmId, setRevokeConfirmId] = useState<string | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('');
  const [department, setDepartment] = useState('');
  const [accessLevel, setAccessLevel] = useState<Employee['accessLevel']>('STAFF');

  const pendingEmployees = employees.filter(e => e.isAuthorized === false);
  const authorizedEmployees = employees.filter(e => e.isAuthorized === true && e.id !== currentUser.id);
  const pendingLeaves = leaveRequests.filter(r => r.status === 'pending');

  // Leave History States
  const [leaveFilterEmp, setLeaveFilterEmp] = useState('all');
  const [leaveFilterStatus, setLeaveFilterStatus] = useState<'all' | 'approved' | 'rejected' | 'pending'>('all');

  const filteredLeaveHistory = leaveRequests.filter(req => {
    const matchesEmp = leaveFilterEmp === 'all' || req.employeeId === leaveFilterEmp;
    const matchesStatus = leaveFilterStatus === 'all' || req.status === leaveFilterStatus;
    return matchesEmp && matchesStatus;
  }).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const handleOpenAddModal = () => {
    setEditingEmp(null);
    setName('');
    setEmail('');
    setRole('');
    setDepartment('');
    setAccessLevel('STAFF');
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (emp: Employee) => {
    setEditingEmp(emp);
    setName(emp.name);
    setEmail(emp.email);
    setRole(emp.role);
    setDepartment(emp.department);
    setAccessLevel(emp.accessLevel);
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingEmp) {
      onUpdateEmployee({
        ...editingEmp,
        name,
        email,
        role,
        department,
        accessLevel,
        isSuperAdmin: accessLevel === 'SUPER_ADMIN'
      });
    } else {
      onAddEmployee({
        name,
        email,
        password: 'ChangeMe@123', // Default password
        role,
        department,
        accessLevel,
        isSuperAdmin: accessLevel === 'SUPER_ADMIN',
        status: 'Active',
        joinedDate: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }).replace(/ /g, '-')
      });
    }
    setIsModalOpen(false);
  };

  return (
    <div className="flex-1 md:overflow-y-auto p-4 sm:p-6 lg:p-8 space-y-8 bg-neutral-50 dark:bg-neutral-950">
      <div className="max-w-5xl mx-auto space-y-8">
        
        {/* Header Action Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-black text-neutral-900 dark:text-neutral-100 flex items-center gap-2">
              <ShieldAlert className="w-8 h-8 text-amber-500" />
              Super Admin Executive Panel
            </h1>
            <p className="text-sm text-neutral-500 dark:text-neutral-400">Master controls for staff access, permissions, and corporate governance.</p>
          </div>
          <button
            onClick={handleOpenAddModal}
            className="flex items-center justify-center gap-2 px-5 py-2.5 bg-neutral-900 dark:bg-neutral-100 text-white dark:text-neutral-900 rounded-2xl text-sm font-bold shadow-sm hover:scale-[1.02] transition active:scale-95"
          >
            <Plus className="w-4 h-4" />
            Add New Employee
          </button>
        </div>

        {/* Section: Pending Authorizations */}
        <section className="space-y-4">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-amber-100 dark:bg-amber-900/40 flex items-center justify-center">
              <ShieldCheck className="w-6 h-6 text-amber-600 dark:text-amber-400" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-neutral-900 dark:text-neutral-100">Pending Staff Authorizations</h2>
              <p className="text-sm text-neutral-500 dark:text-neutral-400">New registration requests waiting for your approval.</p>
            </div>
          </div>

          {pendingEmployees.length === 0 ? (
            <div className="p-8 text-center bg-white dark:bg-neutral-900 rounded-2xl border border-dashed border-neutral-200 dark:border-neutral-800">
              <UserCheck className="w-12 h-12 text-neutral-300 dark:text-neutral-700 mx-auto mb-3" />
              <p className="text-neutral-500 dark:text-neutral-400 font-medium">All staff members are currently authorized.</p>
            </div>
          ) : (
            <div className="grid gap-3 sm:grid-cols-2">
              {pendingEmployees.map(emp => (
                <div key={emp.id} className="p-4 bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200 dark:border-neutral-800 flex items-center justify-between shadow-sm">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center text-lg font-bold text-neutral-700 dark:text-neutral-300">
                      {(emp.name || '?').charAt(0)}
                    </div>
                    <div>
                      <h3 className="font-bold text-neutral-900 dark:text-neutral-100">{emp.name}</h3>
                      <p className="text-xs text-neutral-500 dark:text-neutral-400">{emp.role} · {emp.department}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {deleteConfirmId === emp.id ? (
                      <div className="flex items-center gap-1 bg-rose-50 dark:bg-rose-950/80 p-0.5 rounded-lg animate-in fade-in zoom-in duration-150 border border-rose-200">
                        <button
                          onClick={() => {
                            onDeleteEmployee(emp.id);
                            setDeleteConfirmId(null);
                          }}
                          className="px-2 py-1 rounded-md bg-rose-600 text-white text-[10px] font-bold hover:bg-rose-700 transition"
                        >
                          Confirm
                        </button>
                        <button
                          onClick={() => setDeleteConfirmId(null)}
                          className="px-1.5 py-1 text-[10px] text-neutral-500 hover:text-neutral-700 font-bold"
                        >
                          Cancel
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => setDeleteConfirmId(emp.id)}
                        className="p-2 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl transition"
                        title="Reject & Delete Account"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    )}
                    <button
                      onClick={() => onToggleAuthorization(emp.id, true)}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition shadow-sm active:scale-95"
                    >
                      Authorize
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* Section: Staff Access Management */}
        <section className="space-y-4">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-neutral-900 dark:bg-neutral-800 flex items-center justify-center">
              <Users className="w-6 h-6 text-white dark:text-neutral-100" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-neutral-900 dark:text-neutral-100">Staff Management & Permission Center</h2>
              <p className="text-sm text-neutral-500 dark:text-neutral-400">Complete control over member accounts, access rights, and profile data.</p>
            </div>
          </div>

          <div className="bg-white dark:bg-neutral-900 rounded-3xl border border-neutral-200 dark:border-neutral-800 overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[900px] text-left text-sm">
                <thead className="bg-neutral-50 dark:bg-neutral-800/50 border-b border-neutral-200 dark:border-neutral-800">
                  <tr>
                    <th className="px-6 py-4 font-bold text-neutral-900 dark:text-neutral-100 uppercase tracking-wider text-[10px]">Staff Member</th>
                    <th className="px-6 py-4 font-bold text-neutral-900 dark:text-neutral-100 uppercase tracking-wider text-[10px]">Department</th>
                    <th className="px-6 py-4 font-bold text-neutral-900 dark:text-neutral-100 uppercase tracking-wider text-[10px]">Access Authority</th>
                    <th className="px-6 py-4 font-bold text-neutral-900 dark:text-neutral-100 uppercase tracking-wider text-[10px] text-right">Administrative Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800">
                  {authorizedEmployees.map(emp => (
                    <tr key={emp.id} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-800/30 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-lg bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center font-bold text-neutral-700 dark:text-neutral-300">
                            {(emp.name || '?').charAt(0)}
                          </div>
                          <div>
                            <div className="font-bold text-neutral-900 dark:text-neutral-100">{emp.name}</div>
                            <div className="text-[10px] text-neutral-500 font-medium">{emp.email} · {emp.role}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 font-medium text-neutral-600 dark:text-neutral-400">{emp.department}</td>
                      <td className="px-6 py-4">
                        <select 
                          value={emp.accessLevel}
                          onChange={(e) => onUpdateAccessLevel(emp.id, e.target.value as Employee['accessLevel'])}
                          className="bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-lg px-2 py-1 text-xs font-bold text-neutral-800 dark:text-neutral-200 focus:ring-1 focus:ring-emerald-500 outline-none"
                        >
                          <option value="STAFF">STAFF (Viewer)</option>
                          <option value="MANAGER">MANAGER (Standard)</option>
                          <option value="ADMIN">ADMIN (Panel Access)</option>
                          <option value="SUPER_ADMIN">SUPER_ADMIN (CEO Power)</option>
                        </select>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => handleOpenEditModal(emp)}
                            className="p-2 text-neutral-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 rounded-xl transition"
                            title="Edit Profile"
                          >
                            <Pencil className="w-4 h-4" />
                          </button>

                          {deleteConfirmId === emp.id ? (
                            <div className="flex items-center gap-1 bg-rose-50 dark:bg-rose-950/80 p-0.5 rounded-lg animate-in fade-in zoom-in duration-150 border border-rose-200">
                              <button
                                onClick={() => {
                                  onDeleteEmployee(emp.id);
                                  setDeleteConfirmId(null);
                                }}
                                className="px-2 py-1 rounded-md bg-rose-600 text-white text-[10px] font-bold hover:bg-rose-700 transition"
                              >
                                Delete
                              </button>
                              <button
                                onClick={() => setDeleteConfirmId(null)}
                                className="px-1.5 py-1 text-[10px] text-neutral-500 hover:text-neutral-700 font-bold"
                              >
                                Esc
                              </button>
                            </div>
                          ) : (
                            <button
                              onClick={() => setDeleteConfirmId(emp.id)}
                              className="p-2 text-neutral-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl transition"
                              title="Delete Account"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}

                          <div className="w-px h-4 bg-neutral-200 dark:bg-neutral-800 mx-1" />

                          {revokeConfirmId === emp.id ? (
                            <div className="flex items-center gap-1 bg-amber-50 dark:bg-amber-950/80 p-0.5 rounded-lg animate-in fade-in zoom-in duration-150 border border-amber-200">
                              <button
                                onClick={() => {
                                  onToggleAuthorization(emp.id, false);
                                  setRevokeConfirmId(null);
                                }}
                                className="px-2 py-1 rounded-md bg-amber-600 text-white text-[10px] font-bold hover:bg-amber-700 transition"
                              >
                                Revoke Now
                              </button>
                              <button
                                onClick={() => setRevokeConfirmId(null)}
                                className="px-1.5 py-1 text-[10px] text-neutral-500 hover:text-neutral-700 font-bold"
                              >
                                No
                              </button>
                            </div>
                          ) : (
                            <button
                              onClick={() => setRevokeConfirmId(emp.id)}
                              className="px-3 py-1.5 rounded-xl text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-[11px] font-bold transition border border-transparent hover:border-rose-200"
                            >
                              Revoke
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                  {authorizedEmployees.length === 0 && (
                    <tr>
                      <td colSpan={4} className="px-6 py-12 text-center text-neutral-500 italic">No other authorized staff found.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </section>

        {/* Section: Leave Requests */}
        <section className="space-y-4">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-indigo-100 dark:bg-indigo-900/40 flex items-center justify-center">
              <Calendar className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-neutral-900 dark:text-neutral-100">Leave Management</h2>
              <p className="text-sm text-neutral-500 dark:text-neutral-400">Review and approve employee leave applications.</p>
            </div>
          </div>

          {pendingLeaves.length === 0 ? (
            <div className="p-8 text-center bg-white dark:bg-neutral-900 rounded-2xl border border-dashed border-neutral-200 dark:border-neutral-800">
              <CheckCircle className="w-12 h-12 text-neutral-300 dark:text-neutral-700 mx-auto mb-3" />
              <p className="text-neutral-500 dark:text-neutral-400 font-medium">No pending leave requests at this time.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {pendingLeaves.map(req => (
                <div key={req.id} className="p-5 bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200 dark:border-neutral-800 shadow-sm space-y-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-indigo-50 dark:bg-indigo-950/50 flex items-center justify-center font-bold text-indigo-700 dark:text-indigo-300">
                        {(req.employeeName || '?').charAt(0)}
                      </div>
                      <div>
                        <h3 className="font-bold text-neutral-900 dark:text-neutral-100">{req.employeeName}</h3>
                        <p className="text-xs text-neutral-500 dark:text-neutral-400 flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          Requested on {new Date(req.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onUpdateLeaveStatus(req.id, 'rejected')}
                        className="p-2 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl transition"
                        title="Reject Leave"
                      >
                        <XCircle className="w-6 h-6" />
                      </button>
                      <button
                        onClick={() => onUpdateLeaveStatus(req.id, 'approved')}
                        className="p-2 text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 rounded-xl transition"
                        title="Approve Leave"
                      >
                        <CheckCircle className="w-6 h-6" />
                      </button>
                    </div>
                  </div>
                  
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="p-3 bg-neutral-50 dark:bg-neutral-800/60 rounded-xl border border-neutral-100 dark:border-neutral-700/60">
                      <span className="text-[10px] uppercase font-bold text-neutral-400 dark:text-neutral-500 block mb-1">Duration</span>
                      <span className="text-sm font-semibold text-neutral-800 dark:text-neutral-200">{req.startDate} to {req.endDate}</span>
                    </div>
                    <div className="p-3 bg-neutral-50 dark:bg-neutral-800/60 rounded-xl border border-neutral-100 dark:border-neutral-700/60">
                      <span className="text-[10px] uppercase font-bold text-neutral-400 dark:text-neutral-500 block mb-1">Reason</span>
                      <p className="text-sm text-neutral-800 dark:text-neutral-200 leading-relaxed italic">"{req.reason}"</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* Section: Leave History & Auditing */}
        <section className="space-y-4 pb-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center">
                <Clock className="w-6 h-6 text-neutral-600 dark:text-neutral-400" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-neutral-900 dark:text-neutral-100">Leave History & Auditing</h2>
                <p className="text-sm text-neutral-500 dark:text-neutral-400">Complete record of all processed leave applications.</p>
              </div>
            </div>

            {/* Inline Filters */}
            <div className="flex items-center gap-2">
              <select
                value={leaveFilterEmp}
                onChange={(e) => setLeaveFilterEmp(e.target.value)}
                className="h-9 rounded-lg bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 px-3 text-xs font-bold focus:outline-none"
              >
                <option value="all">All Members</option>
                {employees.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
              </select>
              <select
                value={leaveFilterStatus}
                onChange={(e) => setLeaveFilterStatus(e.target.value as any)}
                className="h-9 rounded-lg bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 px-3 text-xs font-bold focus:outline-none"
              >
                <option value="all">All Status</option>
                <option value="pending">Pending</option>
                <option value="approved">Approved</option>
                <option value="rejected">Rejected</option>
              </select>
            </div>
          </div>

          <div className="bg-white dark:bg-neutral-900 rounded-3xl border border-neutral-200 dark:border-neutral-800 overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[800px] text-left text-sm">
                <thead className="bg-neutral-50 dark:bg-neutral-800/50 border-b border-neutral-200 dark:border-neutral-800">
                  <tr>
                    <th className="px-6 py-4 font-bold text-neutral-900 dark:text-neutral-100 uppercase tracking-wider text-[10px]">Employee</th>
                    <th className="px-6 py-4 font-bold text-neutral-900 dark:text-neutral-100 uppercase tracking-wider text-[10px]">Dates</th>
                    <th className="px-6 py-4 font-bold text-neutral-900 dark:text-neutral-100 uppercase tracking-wider text-[10px]">Reason</th>
                    <th className="px-6 py-4 font-bold text-neutral-900 dark:text-neutral-100 uppercase tracking-wider text-[10px] text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800">
                  {filteredLeaveHistory.length === 0 ? (
                    <tr>
                      <td colSpan={4} className="px-6 py-12 text-center text-neutral-500 italic">No leave records found matching the filters.</td>
                    </tr>
                  ) : (
                    filteredLeaveHistory.map(req => (
                      <tr key={req.id} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-800/30 transition-colors">
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-lg bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center font-bold text-neutral-500 text-xs">
                              {(req.employeeName || '?').charAt(0)}
                            </div>
                            <span className="font-bold text-neutral-900 dark:text-neutral-100">{req.employeeName}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 font-medium text-neutral-600 dark:text-neutral-400 text-xs">
                          {req.startDate} to {req.endDate}
                        </td>
                        <td className="px-6 py-4 text-xs text-neutral-500 max-w-xs truncate" title={req.reason}>
                          {req.reason}
                        </td>
                        <td className="px-6 py-4 text-right">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                            req.status === 'approved' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-400' :
                            req.status === 'rejected' ? 'bg-rose-100 text-rose-800 dark:bg-rose-950/40 dark:text-rose-400' :
                            'bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-400'
                          }`}>
                            {req.status}
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      </div>

      {/* Modal: Add / Edit Employee */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/70 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="w-full max-w-lg bg-white dark:bg-neutral-900 rounded-3xl border border-neutral-200 dark:border-neutral-800 shadow-2xl overflow-hidden">
            <div className="p-6 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
              <h3 className="text-lg font-black text-neutral-900 dark:text-neutral-100">
                {editingEmp ? 'Edit Staff Member Profile' : 'Register New Executive Member'}
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="p-2 text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-100">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-neutral-400 uppercase ml-1">Full Name</label>
                  <input
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full h-11 rounded-xl bg-neutral-100 dark:bg-neutral-800 px-4 text-sm font-medium text-neutral-900 dark:text-neutral-100 focus:ring-2 focus:ring-amber-500 outline-none"
                    placeholder="e.g. Rahul Sharma"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-neutral-400 uppercase ml-1">Work Email</label>
                  <input
                    required
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full h-11 rounded-xl bg-neutral-100 dark:bg-neutral-800 px-4 text-sm font-medium text-neutral-900 dark:text-neutral-100 focus:ring-2 focus:ring-amber-500 outline-none"
                    placeholder="name@mandideals.com"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-neutral-400 uppercase ml-1">Executive Role</label>
                  <input
                    required
                    value={role}
                    onChange={(e) => setRole(e.target.value)}
                    className="w-full h-11 rounded-xl bg-neutral-100 dark:bg-neutral-800 px-4 text-sm font-medium text-neutral-900 dark:text-neutral-100 focus:ring-2 focus:ring-amber-500 outline-none"
                    placeholder="e.g. Operations Manager"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-neutral-400 uppercase ml-1">Department</label>
                  <input
                    required
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    className="w-full h-11 rounded-xl bg-neutral-100 dark:bg-neutral-800 px-4 text-sm font-medium text-neutral-900 dark:text-neutral-100 focus:ring-2 focus:ring-amber-500 outline-none"
                    placeholder="e.g. Logistics & Supply"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-neutral-400 uppercase ml-1">Access Authority Level</label>
                <select
                  value={accessLevel}
                  onChange={(e) => setAccessLevel(e.target.value as Employee['accessLevel'])}
                  className="w-full h-11 rounded-xl bg-neutral-100 dark:bg-neutral-800 px-4 text-sm font-bold text-neutral-900 dark:text-neutral-100 focus:ring-2 focus:ring-amber-500 outline-none"
                >
                  <option value="STAFF">STAFF (Restricted Viewer)</option>
                  <option value="MANAGER">MANAGER (Standard Operations)</option>
                  <option value="ADMIN">ADMIN (Panel & Governance)</option>
                  <option value="SUPER_ADMIN">SUPER_ADMIN (CEO Strategic Control)</option>
                </select>
              </div>

              <div className="pt-4 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-6 py-2.5 rounded-xl text-sm font-bold text-neutral-500 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-8 py-2.5 rounded-xl bg-neutral-900 dark:bg-neutral-100 text-white dark:text-neutral-900 text-sm font-black shadow-lg hover:scale-[1.02] transition active:scale-95"
                >
                  {editingEmp ? 'Save Profile Updates' : 'Authorize & Register Member'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
