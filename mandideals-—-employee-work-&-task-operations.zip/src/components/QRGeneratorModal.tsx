import React, { useState, useRef } from 'react';
import { QRCodeCanvas } from 'qrcode.react';
import { X, QrCode, Download, Calendar, ShieldAlert, Check, RefreshCw } from 'lucide-react';

interface QRGeneratorModalProps {
  isOpen: boolean;
  onClose: () => void;
  rotationSeed?: string;
  lastRotated?: string;
  onRegenerate?: () => void;
}

export const QRGeneratorModal: React.FC<QRGeneratorModalProps> = ({ 
  isOpen, 
  onClose,
  rotationSeed = 'GMD-INITIAL',
  lastRotated,
  onRegenerate
}) => {
  const [expiryDate, setExpiryDate] = useState(() => {
    const nextMonth = new Date();
    nextMonth.setMonth(nextMonth.getMonth() + 1);
    return nextMonth.toISOString().split('T')[0];
  });
  
  // Daily Rotation: Generation date ensures codes rotate every 24 hours
  const generationDate = new Date().toISOString().split('T')[0];
  const [isCopied, setIsCopied] = useState(false);
  const canvasRef = useRef<HTMLDivElement>(null);

  if (!isOpen) return null;

  // Format: MANDIDEALS-VERIFY:EXPIRY_DATE:GENERATION_DATE:ROTATION_SEED
  const qrValue = `MANDIDEALS-VERIFY:${expiryDate}:${generationDate}:${rotationSeed}`;

  const handleDownload = () => {
    const canvas = document.querySelector('canvas') as HTMLCanvasElement;
    if (!canvas) return;
    
    const url = canvas.toDataURL('image/png');
    const link = document.createElement('a');
    link.href = url;
    link.download = `mandideals_complex_qr_${generationDate}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-start justify-center bg-neutral-950/80 backdrop-blur-md animate-in fade-in duration-200 overflow-y-auto">
      <div className="QRGeneratorModal relative w-full max-w-md mx-auto min-h-[100dvh] bg-white dark:bg-neutral-900 shadow-2xl border-x border-neutral-200 dark:border-neutral-800 flex flex-col">
        <div className="p-6 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between bg-neutral-50/50 dark:bg-neutral-800/50 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-100 dark:bg-indigo-950/40 flex items-center justify-center text-indigo-600">
              <QrCode className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-black text-neutral-900 dark:text-neutral-100 uppercase italic leading-none">Security QR Generator</h3>
              <p className="text-[10px] text-neutral-500 font-bold uppercase tracking-widest mt-1">GMD Executive Protocol</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-100 transition-colors">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-8 space-y-8 overflow-y-auto">
          {/* Controls */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-neutral-400 uppercase tracking-widest ml-1 flex items-center gap-2">
                <Calendar className="w-3 h-3" />
                Temporary Access Expiry
              </label>
              <input 
                type="date"
                value={expiryDate}
                onChange={(e) => setExpiryDate(e.target.value)}
                className="w-full h-12 px-4 rounded-2xl bg-neutral-50 dark:bg-neutral-800 border border-neutral-100 dark:border-neutral-800 text-sm font-bold text-neutral-900 dark:text-neutral-100 outline-none focus:ring-2 focus:ring-indigo-500/20"
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between ml-1">
                <label className="text-[10px] font-black text-neutral-400 uppercase tracking-widest flex items-center gap-2">
                  <RefreshCw className="w-3 h-3" />
                  Security Rotation
                </label>
                {lastRotated && (
                  <span className="text-[9px] font-bold text-indigo-500 bg-indigo-50 dark:bg-indigo-950/40 px-2 py-0.5 rounded-full">
                    Last: {new Date(lastRotated).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true })}
                  </span>
                )}
              </div>
              <button
                onClick={onRegenerate}
                className="w-full h-12 px-4 rounded-2xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900/50 text-xs font-black text-indigo-600 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 transition-colors flex items-center justify-center gap-2 group"
              >
                <RefreshCw className="w-4 h-4 group-active:animate-spin" />
                Regenerate Now
              </button>
            </div>
          </div>

          {/* QR Preview area with explicit internal scrollbars for visibility */}
          <div className="flex flex-col items-center justify-center p-6 sm:p-8 bg-neutral-50 dark:bg-neutral-800/50 rounded-[32px] border border-dashed border-neutral-200 dark:border-neutral-700/50 overflow-auto max-h-[400px] scrollbar-thin scrollbar-thumb-neutral-300 dark:scrollbar-thumb-neutral-700">
            <div className="p-6 bg-white rounded-[24px] shadow-xl border border-neutral-100 shrink-0 min-w-[240px] flex justify-center">
              <QRCodeCanvas 
                value={qrValue}
                size={220}
                level="H"
                includeMargin={true}
                imageSettings={{
                  src: "https://raw.githubusercontent.com/lucide-react/lucide/main/icons/building-2.svg",
                  x: undefined,
                  y: undefined,
                  height: 44,
                  width: 44,
                  excavate: true,
                }}
              />
            </div>
            <div className="mt-6 text-center space-y-1 shrink-0">
              <p className="text-xs font-black text-neutral-900 dark:text-neutral-100 uppercase tracking-tighter">Authorized Mandi Complex QR</p>
              <p className="text-[10px] text-neutral-500 font-bold">Expires on: <span className="text-rose-500 font-black">{new Date(expiryDate).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}</span></p>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/50 flex items-start gap-3">
            <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="text-xs font-bold text-amber-900 dark:text-amber-200 uppercase tracking-tight">Executive Notice</p>
              <p className="text-[10px] text-amber-800/80 dark:text-amber-400/80 leading-relaxed">
                Clicking <span className="font-bold">"Regenerate Now"</span> will immediately invalidate all previously printed QR codes. Use this only if security is compromised or at the start of a new security cycle.
              </p>
            </div>
          </div>
        </div>

        <div className="p-6 bg-neutral-50 dark:bg-neutral-800/30 border-t border-neutral-100 dark:border-neutral-800 flex gap-3">
          <button 
            onClick={handleDownload}
            className="flex-1 flex items-center justify-center gap-2 py-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black uppercase tracking-widest transition shadow-lg shadow-emerald-600/20 active:scale-[0.98]"
          >
            <Download className="w-4 h-4" />
            Download Print File
          </button>
        </div>
      </div>
    </div>
  );
};
