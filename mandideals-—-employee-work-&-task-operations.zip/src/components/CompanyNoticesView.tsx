import React, { useState } from 'react';
import {
  Bell,
  Megaphone,
  Pin,
  Plus,
  Pencil,
  Trash2,
  Calendar,
  User,
  ShieldAlert,
  ArrowLeft,
  X,
  Check,
  Flame,
  Info,
  CheckCheck
} from 'lucide-react';
import { CompanyNotice, Employee, NoticePriority } from '../types/task';

interface CompanyNoticesViewProps {
  currentUser: Employee;
  notices: CompanyNotice[];
  onAddNotice: (notice: Omit<CompanyNotice, 'id' | 'createdAt'>) => void;
  onEditNotice: (id: string, updated: Partial<Omit<CompanyNotice, 'id' | 'createdAt'>>) => void;
  onDeleteNotice: (id: string) => void;
  onTogglePinNotice: (id: string) => void;
  onBackToTasks: () => void;
}

export const CompanyNoticesView: React.FC<CompanyNoticesViewProps> = ({
  currentUser,
  notices,
  onAddNotice,
  onEditNotice,
  onDeleteNotice,
  onTogglePinNotice,
  onBackToTasks,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingNotice, setEditingNotice] = useState<CompanyNotice | null>(null);

  const [deleteConfirmNoticeId, setDeleteConfirmNoticeId] = useState<string | null>(null);

  // Form states
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [priority, setPriority] = useState<NoticePriority>('urgent');
  const [pinned, setPinned] = useState(true);

  // Check if current user is Sabyasachi or designated Super Admin
  const isSuperAdmin = currentUser.isSuperAdmin || currentUser.accessLevel === 'SUPER_ADMIN';

  // Open modal for Creating a new notice
  const handleOpenCreateModal = () => {
    setEditingNotice(null);
    setTitle('');
    setContent('');
    setPriority('urgent');
    setPinned(true);
    setIsModalOpen(true);
  };

  // Open modal for Editing an existing notice
  const handleOpenEditModal = (notice: CompanyNotice) => {
    setEditingNotice(notice);
    setTitle(notice.title);
    setContent(notice.content);
    setPriority(notice.priority);
    setPinned(Boolean(notice.pinned));
    setIsModalOpen(true);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) return;

    if (editingNotice) {
      // Edit existing notice
      onEditNotice(editingNotice.id, {
        title: title.trim(),
        content: content.trim(),
        priority,
        pinned,
      });
    } else {
      // Add new notice
      onAddNotice({
        title: title.trim(),
        content: content.trim(),
        authorName: currentUser.name,
        authorRole: isSuperAdmin ? 'CEO & Super Admin' : currentUser.role,
        priority,
        pinned,
      });
    }

    setIsModalOpen(false);
    setEditingNotice(null);
    setTitle('');
    setContent('');
  };

  const getPriorityBadge = (p: NoticePriority) => {
    switch (p) {
      case 'urgent':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-rose-100 text-rose-800 dark:bg-rose-950/70 dark:text-rose-300 border border-rose-300 dark:border-rose-800">
            <Flame className="w-3 h-3 text-rose-500" />
            <span>Urgent Mandi Directive</span>
          </span>
        );
      case 'announcement':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-amber-100 text-amber-800 dark:bg-amber-950/70 dark:text-amber-300 border border-amber-300 dark:border-amber-800">
            <Megaphone className="w-3 h-3 text-amber-600" />
            <span>Executive Announcement</span>
          </span>
        );
      case 'operational':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-blue-100 text-blue-800 dark:bg-blue-950/70 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
            <Info className="w-3 h-3 text-blue-500" />
            <span>Operational Notice</span>
          </span>
        );
      case 'policy':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800 dark:bg-emerald-950/70 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
            <ShieldAlert className="w-3 h-3 text-emerald-500" />
            <span>Policy Update</span>
          </span>
        );
    }
  };

  const sortedNotices = [...notices].sort((a, b) => {
    if (a.pinned && !b.pinned) return -1;
    if (!a.pinned && b.pinned) return 1;
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });

  return (
    <div className="flex-1 md:overflow-y-auto px-4 sm:px-6 lg:px-8 py-6 max-w-5xl mx-auto w-full space-y-6 animate-in fade-in duration-150">
      
      {/* Header and Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-3 border-b border-neutral-200/80 dark:border-neutral-800/80">
        <div className="space-y-1">
          <div className="flex items-center gap-3">
            <button
              onClick={onBackToTasks}
              className="flex items-center gap-1.5 h-9 px-3 rounded-xl border border-neutral-200/90 dark:border-neutral-800 bg-white hover:bg-neutral-50 dark:bg-neutral-900 dark:hover:bg-neutral-800 text-xs font-semibold text-neutral-700 dark:text-neutral-200 transition-all shadow-2xs hover:shadow-xs active:scale-[0.98] cursor-pointer whitespace-nowrap shrink-0"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              <span>Back to Tasks</span>
            </button>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-neutral-900 dark:text-neutral-100 flex items-center gap-2">
              <Megaphone className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
              <span>Company Notice Board</span>
            </h1>
          </div>
          <p className="text-xs text-neutral-500 dark:text-neutral-400">
            Official announcements, APMC yard advisories, and executive notices issued to all staff
          </p>
        </div>

        {/* CEO Super Admin: Add Notice Button */}
        {isSuperAdmin ? (
          <button
            onClick={handleOpenCreateModal}
            className="flex h-9 items-center justify-center gap-2 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 text-xs font-extrabold shadow-xs hover:shadow-sm active:scale-[0.98] transition-all cursor-pointer whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>Post Company Notice (CEO)</span>
          </button>
        ) : (
          <div className="flex items-center gap-1.5 text-xs text-neutral-500 dark:text-neutral-400 bg-neutral-100 dark:bg-neutral-800/60 px-3 py-1.5 rounded-xl border border-neutral-200 dark:border-neutral-700">
            <Info className="w-3.5 h-3.5 text-neutral-400" />
            <span>Notices broadcast from Super Admin (Sabyasachi)</span>
          </div>
        )}
      </div>

      {/* Notices Feed */}
      <div className="space-y-3.5">
        {sortedNotices.length === 0 ? (
          <div className="p-12 rounded-3xl border border-dashed border-neutral-300 dark:border-neutral-800 text-center space-y-2 bg-neutral-50/50 dark:bg-neutral-900/20">
            <Megaphone className="w-8 h-8 text-neutral-400 mx-auto" />
            <h3 className="text-sm font-semibold text-neutral-800 dark:text-neutral-200">
              No active company notices
            </h3>
            <p className="text-xs text-neutral-500 max-w-sm mx-auto">
              Company notices posted by Sabyasachi (Super Admin) will appear here for all employees.
            </p>
          </div>
        ) : (
          sortedNotices.map((notice) => (
            <div
              key={notice.id}
              className={`rounded-2xl border p-4 sm:p-5 transition shadow-2xs ${
                notice.pinned
                  ? 'border-amber-300/80 bg-gradient-to-br from-amber-50/40 via-white to-amber-50/20 dark:from-amber-950/20 dark:via-neutral-900 dark:to-neutral-900 dark:border-amber-700/60 shadow-xs'
                  : 'border-neutral-200/90 bg-white dark:border-neutral-800 dark:bg-neutral-900'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="space-y-2 flex-1 min-w-0">
                  
                  {/* Badges Row */}
                  <div className="flex flex-wrap items-center gap-2">
                    {notice.pinned && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-500 text-slate-950 font-black text-[10px] uppercase tracking-wider">
                        <Pin className="w-3 h-3 stroke-[2.5]" />
                        <span>Pinned</span>
                      </span>
                    )}
                    {getPriorityBadge(notice.priority)}
                    <span className="text-[11px] text-neutral-400 font-mono">
                      {new Date(notice.createdAt).toLocaleDateString([], {
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric',
                      })}
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="text-base font-bold text-neutral-900 dark:text-neutral-100 leading-snug">
                    {notice.title}
                  </h3>

                  {/* Body Content */}
                  <p className="text-xs sm:text-sm text-neutral-700 dark:text-neutral-300 leading-relaxed whitespace-pre-line">
                    {notice.content}
                  </p>

                  {/* Author Meta */}
                  <div className="pt-2 flex items-center gap-2 text-xs text-neutral-500 dark:text-neutral-400 font-medium">
                    <span className="font-bold text-neutral-800 dark:text-neutral-200 flex items-center gap-1">
                      <User className="w-3 h-3 text-neutral-400" />
                      {notice.authorName}
                    </span>
                    <span>·</span>
                    <span className="text-neutral-500">{notice.authorRole}</span>
                  </div>
                </div>

                {/* CEO Super Admin Actions: Edit, Pin, Delete */}
                {isSuperAdmin && (
                  <div className="flex items-center gap-1 shrink-0 bg-neutral-100 dark:bg-neutral-800/80 p-1 rounded-xl border border-neutral-200 dark:border-neutral-700/80">
                    {/* Edit Notice Button */}
                    <button
                      onClick={() => handleOpenEditModal(notice)}
                      className="p-1.5 rounded-lg text-neutral-600 hover:text-amber-600 hover:bg-amber-100/60 dark:text-neutral-300 dark:hover:text-amber-300 dark:hover:bg-amber-950/60 transition"
                      title="Edit Notice (CEO)"
                    >
                      <Pencil className="w-3.5 h-3.5" />
                    </button>

                    {/* Pin/Unpin Notice */}
                    <button
                      onClick={() => onTogglePinNotice(notice.id)}
                      className={`p-1.5 rounded-lg transition text-xs font-semibold ${
                        notice.pinned
                          ? 'bg-amber-200 text-amber-950 dark:bg-amber-900/80 dark:text-amber-200'
                          : 'text-neutral-500 hover:bg-neutral-200/80 hover:text-neutral-800 dark:text-neutral-400 dark:hover:bg-neutral-700'
                      }`}
                      title={notice.pinned ? 'Unpin Notice' : 'Pin Notice to Top'}
                    >
                      <Pin className="w-3.5 h-3.5" />
                    </button>

                    {/* Delete Notice Button */}
                    {deleteConfirmNoticeId === notice.id ? (
                      <div className="flex items-center gap-1 bg-rose-50 dark:bg-rose-950/80 p-0.5 rounded-lg animate-in fade-in zoom-in duration-150">
                        <button
                          onClick={() => {
                            onDeleteNotice(notice.id);
                            setDeleteConfirmNoticeId(null);
                          }}
                          className="px-2 py-1 rounded-md bg-rose-600 text-white text-[10px] font-bold hover:bg-rose-700 transition"
                        >
                          Confirm
                        </button>
                        <button
                          onClick={() => setDeleteConfirmNoticeId(null)}
                          className="px-1.5 py-1 text-[10px] text-neutral-500 hover:text-neutral-700 font-bold"
                        >
                          Cancel
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => setDeleteConfirmNoticeId(notice.id)}
                        className="p-1.5 rounded-lg text-neutral-500 hover:bg-rose-100 hover:text-rose-600 dark:text-neutral-400 dark:hover:bg-rose-950/60 dark:hover:text-rose-300 transition"
                        title="Delete Notice (CEO)"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>

      {/* CREATE & EDIT NOTICE MODAL FOR CEO SUPER ADMIN */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/70 backdrop-blur-xs animate-in fade-in duration-150">
          <div
            className="w-full max-w-lg rounded-3xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 p-6 shadow-2xl space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-neutral-100 dark:border-neutral-800">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold">
                  {editingNotice ? <Pencil className="w-4 h-4 stroke-[2.5]" /> : <Megaphone className="w-4 h-4 stroke-[2.5]" />}
                </div>
                <div>
                  <h3 className="text-sm font-bold text-neutral-900 dark:text-neutral-100">
                    {editingNotice ? 'Edit Company Notice (CEO)' : 'Post New Company Notice (CEO)'}
                  </h3>
                  <p className="text-[11px] text-amber-600 dark:text-amber-400 font-semibold">
                    {editingNotice ? 'Save updates and re-broadcast to all staff' : 'Broadcasts immediately to all MANDIDEALS staff'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  setIsModalOpen(false);
                  setEditingNotice(null);
                }}
                className="p-1 rounded-lg text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleFormSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                  Notice Headline / Subject *
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. APMC Gate #1 Consignment Processing Schedule"
                  className="w-full rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 px-3.5 py-2 text-xs sm:text-sm text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                  Notice Details & Instructions *
                </label>
                <textarea
                  rows={4}
                  required
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Provide detailed instructions, shift requirements, or APMC regulations..."
                  className="w-full rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 px-3.5 py-2 text-xs text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-2 focus:ring-amber-500 leading-relaxed"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                    Notice Category
                  </label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as NoticePriority)}
                    className="w-full rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 px-3 py-2 text-xs font-semibold text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  >
                    <option value="urgent">🔥 Urgent Directive</option>
                    <option value="announcement">📢 Executive Announcement</option>
                    <option value="operational">⚙️ Operational Notice</option>
                    <option value="policy">🛡️ Policy Update</option>
                  </select>
                </div>

                <div className="flex items-center pt-5">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={pinned}
                      onChange={(e) => setPinned(e.target.checked)}
                      className="rounded border-neutral-300 text-amber-600 focus:ring-amber-500"
                    />
                    <span className="text-xs font-bold text-neutral-800 dark:text-neutral-200">
                      Pin to Top for All Staff
                    </span>
                  </label>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-neutral-100 dark:border-neutral-800">
                <button
                  type="button"
                  onClick={() => {
                    setIsModalOpen(false);
                    setEditingNotice(null);
                  }}
                  className="px-3.5 py-1.5 text-xs font-semibold text-neutral-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-black shadow-xs transition flex items-center gap-1.5"
                >
                  {editingNotice ? (
                    <>
                      <CheckCheck className="w-3.5 h-3.5 stroke-[2.5]" />
                      <span>Save Notice Changes</span>
                    </>
                  ) : (
                    <>
                      <Megaphone className="w-3.5 h-3.5 stroke-[2.5]" />
                      <span>Publish Notice to All</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
