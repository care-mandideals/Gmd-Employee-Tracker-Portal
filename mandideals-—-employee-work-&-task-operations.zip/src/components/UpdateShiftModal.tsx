import React, { useState } from 'react';
import {
  Clock,
  Crown,
  X,
  Check,
  ShieldCheck,
  Calendar,
  AlertCircle
} from 'lucide-react';
import { CompanyShift, formatTo12Hour } from '../types/task';

interface UpdateShiftModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentShift: CompanyShift;
  onSaveShift: (updated: CompanyShift) => void;
}

export const UpdateShiftModal: React.FC<UpdateShiftModalProps> = ({
  isOpen,
  onClose,
  currentShift,
  onSaveShift,
}) => {
  const [startHour, setStartHour] = useState(() => {
    const raw = currentShift.startTime12 || '10:30 AM';
    const match = raw.match(/(\d+):(\d+)\s*(AM|PM)/i);
    return match ? match[1].padStart(2, '0') : '10';
  });
  const [startMin, setStartMin] = useState(() => {
    const raw = currentShift.startTime12 || '10:30 AM';
    const match = raw.match(/(\d+):(\d+)\s*(AM|PM)/i);
    return match ? match[2] : '30';
  });
  const [startAmpm, setStartAmpm] = useState<'AM' | 'PM'>(() => {
    const raw = currentShift.startTime12 || '10:30 AM';
    return /PM/i.test(raw) ? 'PM' : 'AM';
  });

  const [endHour, setEndHour] = useState(() => {
    const raw = currentShift.endTime12 || '06:30 PM';
    const match = raw.match(/(\d+):(\d+)\s*(AM|PM)/i);
    return match ? match[1].padStart(2, '0') : '06';
  });
  const [endMin, setEndMin] = useState(() => {
    const raw = currentShift.endTime12 || '06:30 PM';
    const match = raw.match(/(\d+):(\d+)\s*(AM|PM)/i);
    return match ? match[2] : '30';
  });
  const [endAmpm, setEndAmpm] = useState<'AM' | 'PM'>(() => {
    const raw = currentShift.endTime12 || '06:30 PM';
    return /AM/i.test(raw) ? 'AM' : 'PM';
  });

  const [notes, setNotes] = useState(
    currentShift.notes || 'Official Mandi Operations & Floor Auction Roster'
  );

  if (!isOpen) return null;

  const currentFormattedStart = `${startHour}:${startMin} ${startAmpm}`;
  const currentFormattedEnd = `${endHour}:${endMin} ${endAmpm}`;

  // Calculate duration in hours
  const calculateHours = () => {
    let sH = parseInt(startHour, 10);
    if (startAmpm === 'PM' && sH < 12) sH += 12;
    if (startAmpm === 'AM' && sH === 12) sH = 0;
    const sMinutes = sH * 60 + parseInt(startMin, 10);

    let eH = parseInt(endHour, 10);
    if (endAmpm === 'PM' && eH < 12) eH += 12;
    if (endAmpm === 'AM' && eH === 12) eH = 0;
    const eMinutes = eH * 60 + parseInt(endMin, 10);

    let diff = eMinutes - sMinutes;
    if (diff < 0) diff += 24 * 60;
    return Number((diff / 60).toFixed(1));
  };

  const calculatedHours = calculateHours();

  const handleApplyPreset = (s12: string, e12: string, noteText: string) => {
    const sMatch = s12.match(/(\d+):(\d+)\s*(AM|PM)/i);
    if (sMatch) {
      setStartHour(sMatch[1].padStart(2, '0'));
      setStartMin(sMatch[2]);
      setStartAmpm(sMatch[3].toUpperCase() as 'AM' | 'PM');
    }
    const eMatch = e12.match(/(\d+):(\d+)\s*(AM|PM)/i);
    if (eMatch) {
      setEndHour(eMatch[1].padStart(2, '0'));
      setEndMin(eMatch[2]);
      setEndAmpm(eMatch[3].toUpperCase() as 'AM' | 'PM');
    }
    setNotes(noteText);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: CompanyShift = {
      startTime12: currentFormattedStart,
      endTime12: currentFormattedEnd,
      durationHours: calculatedHours,
      updatedBy: 'Sabyasachi (CEO)',
      updatedAt: new Date().toISOString(),
      notes: notes.trim(),
    };
    onSaveShift(updated);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="w-full max-w-lg rounded-3xl border border-neutral-200 bg-white p-6 shadow-2xl dark:border-neutral-800 dark:bg-neutral-900 transition-all text-xs"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-start justify-between pb-4 border-b border-neutral-100 dark:border-neutral-800">
          <div className="flex items-center gap-2.5">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-amber-500 text-slate-950 font-black shadow-xs shrink-0">
              <Crown className="h-5 w-5 stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-neutral-900 dark:text-neutral-100">
                  Update Company Work Shift
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 dark:bg-amber-950/80 dark:text-amber-300 font-extrabold text-[10px] uppercase tracking-wider">
                  Sabyasachi · CEO
                </span>
              </div>
              <p className="text-[11px] text-neutral-500 dark:text-neutral-400 mt-0.5">
                Set 12-hour work shift schedule applied enterprise-wide across all employee workspaces
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded-xl text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Live Preview Card */}
        <div className="mt-4 p-3.5 rounded-2xl border border-emerald-200 bg-emerald-50/70 dark:border-emerald-800/60 dark:bg-emerald-950/30">
          <div className="flex items-center justify-between text-emerald-900 dark:text-emerald-300 font-medium">
            <span className="text-[11px] font-bold uppercase tracking-wider flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              Live Shift Preview (12-Hour Timing)
            </span>
            <span className="font-mono text-xs font-bold px-2 py-0.5 rounded-lg bg-emerald-100 dark:bg-emerald-900/80 text-emerald-900 dark:text-emerald-200">
              {calculatedHours} Hours Total
            </span>
          </div>
          <div className="mt-2 flex items-center gap-2 flex-wrap">
            <span className="text-lg font-black font-mono tracking-tight text-neutral-900 dark:text-neutral-100">
              {currentFormattedStart} – {currentFormattedEnd}
            </span>
          </div>
          <p className="mt-1 text-[11px] text-emerald-800 dark:text-emerald-300 flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>Official MANDIDEALS Shift · Updated by Sabyasachi (CEO)</span>
          </p>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          {/* Quick Presets */}
          <div>
            <label className="text-[11px] font-bold uppercase tracking-wider text-neutral-400 dark:text-neutral-500 block mb-1.5">
              Quick Shift Presets:
            </label>
            <div className="grid grid-cols-2 gap-1.5">
              <button
                type="button"
                onClick={() =>
                  handleApplyPreset(
                    '10:30 AM',
                    '06:30 PM',
                    'Standard APMC Mandi Operations & Floor Auction Roster'
                  )
                }
                className="px-2.5 py-1.5 rounded-xl border border-neutral-200 dark:border-neutral-800 hover:border-emerald-500 text-left transition bg-neutral-50 dark:bg-neutral-800/40"
              >
                <div className="font-bold text-neutral-900 dark:text-neutral-100">
                  10:30 AM – 06:30 PM
                </div>
                <div className="text-[10px] text-neutral-500">Standard Mandi (8.0h)</div>
              </button>

              <button
                type="button"
                onClick={() =>
                  handleApplyPreset(
                    '10:00 AM',
                    '07:00 PM',
                    'Extended Auction Trading & Settlement Shift'
                  )
                }
                className="px-2.5 py-1.5 rounded-xl border border-neutral-200 dark:border-neutral-800 hover:border-emerald-500 text-left transition bg-neutral-50 dark:bg-neutral-800/40"
              >
                <div className="font-bold text-neutral-900 dark:text-neutral-100">
                  10:00 AM – 07:00 PM
                </div>
                <div className="text-[10px] text-neutral-500">Extended Trading (9.0h)</div>
              </button>

              <button
                type="button"
                onClick={() =>
                  handleApplyPreset(
                    '09:00 AM',
                    '05:00 PM',
                    'Corporate HQ Executive Governance Shift'
                  )
                }
                className="px-2.5 py-1.5 rounded-xl border border-neutral-200 dark:border-neutral-800 hover:border-emerald-500 text-left transition bg-neutral-50 dark:bg-neutral-800/40"
              >
                <div className="font-bold text-neutral-900 dark:text-neutral-100">
                  09:00 AM – 05:00 PM
                </div>
                <div className="text-[10px] text-neutral-500">Corporate Day (8.0h)</div>
              </button>

              <button
                type="button"
                onClick={() =>
                  handleApplyPreset(
                    '08:00 AM',
                    '04:30 PM',
                    'Early Yard Consignment & QC Testing Shift'
                  )
                }
                className="px-2.5 py-1.5 rounded-xl border border-neutral-200 dark:border-neutral-800 hover:border-emerald-500 text-left transition bg-neutral-50 dark:bg-neutral-800/40"
              >
                <div className="font-bold text-neutral-900 dark:text-neutral-100">
                  08:00 AM – 04:30 PM
                </div>
                <div className="text-[10px] text-neutral-500">Early Mandi (8.5h)</div>
              </button>
            </div>
          </div>

          {/* Custom Time Selectors (12-Hour Timing) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
            {/* Shift Start Time */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-bold uppercase tracking-wider text-neutral-600 dark:text-neutral-300">
                Shift Start Time (12-Hour)
              </label>
              <div className="flex items-center gap-1.5">
                {/* Hour */}
                <select
                  value={startHour}
                  onChange={(e) => setStartHour(e.target.value)}
                  className="flex-1 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 py-2 px-2 text-xs font-mono font-bold text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-1 focus:ring-emerald-500 cursor-pointer"
                >
                  {Array.from({ length: 12 }, (_, i) => {
                    const val = (i + 1).toString().padStart(2, '0');
                    return (
                      <option key={val} value={val}>
                        {val}
                      </option>
                    );
                  })}
                </select>

                <span className="font-mono font-bold text-neutral-400">:</span>

                {/* Minute */}
                <select
                  value={startMin}
                  onChange={(e) => setStartMin(e.target.value)}
                  className="flex-1 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 py-2 px-2 text-xs font-mono font-bold text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-1 focus:ring-emerald-500 cursor-pointer"
                >
                  {['00', '15', '30', '45'].map((m) => (
                    <option key={m} value={m}>
                      {m}
                    </option>
                  ))}
                </select>

                {/* AM/PM */}
                <select
                  value={startAmpm}
                  onChange={(e) => setStartAmpm(e.target.value as 'AM' | 'PM')}
                  className="w-16 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 py-2 px-2 text-xs font-bold text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-1 focus:ring-emerald-500 cursor-pointer"
                >
                  <option value="AM">AM</option>
                  <option value="PM">PM</option>
                </select>
              </div>
            </div>

            {/* Shift End Time */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-bold uppercase tracking-wider text-neutral-600 dark:text-neutral-300">
                Shift End Time (12-Hour)
              </label>
              <div className="flex items-center gap-1.5">
                {/* Hour */}
                <select
                  value={endHour}
                  onChange={(e) => setEndHour(e.target.value)}
                  className="flex-1 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 py-2 px-2 text-xs font-mono font-bold text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-1 focus:ring-emerald-500 cursor-pointer"
                >
                  {Array.from({ length: 12 }, (_, i) => {
                    const val = (i + 1).toString().padStart(2, '0');
                    return (
                      <option key={val} value={val}>
                        {val}
                      </option>
                    );
                  })}
                </select>

                <span className="font-mono font-bold text-neutral-400">:</span>

                {/* Minute */}
                <select
                  value={endMin}
                  onChange={(e) => setEndMin(e.target.value)}
                  className="flex-1 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 py-2 px-2 text-xs font-mono font-bold text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-1 focus:ring-emerald-500 cursor-pointer"
                >
                  {['00', '15', '30', '45'].map((m) => (
                    <option key={m} value={m}>
                      {m}
                    </option>
                  ))}
                </select>

                {/* AM/PM */}
                <select
                  value={endAmpm}
                  onChange={(e) => setEndAmpm(e.target.value as 'AM' | 'PM')}
                  className="w-16 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 py-2 px-2 text-xs font-bold text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-1 focus:ring-emerald-500 cursor-pointer"
                >
                  <option value="AM">AM</option>
                  <option value="PM">PM</option>
                </select>
              </div>
            </div>
          </div>

          {/* Shift Directive / Note */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-bold uppercase tracking-wider text-neutral-600 dark:text-neutral-300">
              Executive Shift Directive (Issued by Sabyasachi)
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Standard APMC Mandi Operations & Floor Auction Roster"
              className="w-full rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 px-3 py-2 text-xs text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          {/* Modal Actions */}
          <div className="flex items-center justify-end gap-2 pt-3 border-t border-neutral-100 dark:border-neutral-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-neutral-300 dark:border-neutral-700 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center gap-2 px-5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold shadow-xs hover:shadow-sm active:scale-[0.98] transition cursor-pointer"
            >
              <Check className="w-4 h-4 stroke-[2.5]" />
              <span>Update Work Shift (Sabyasachi)</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
