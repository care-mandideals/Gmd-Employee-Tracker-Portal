import React, { useState, useEffect } from 'react';
import {
  X,
  Calendar,
  Clock,
  Bell,
  User,
  Building2,
  Trash2,
  Check,
  Zap
} from 'lucide-react';
import { Task, TaskPriority, SubTask, TaskComment, Employee, TaskStatus, getTaskCategory } from '../types/task';
import {
  getNotificationPermission,
  requestNotificationPermission,
} from '../services/notificationService';
import { calculateDurationHours } from '../data/initialTasks';

const to12Hour = (time24: string): string => {
  if (!time24) return '';
  const [hStr, mStr] = time24.split(':');
  const h = parseInt(hStr, 10);
  if (isNaN(h)) return time24;
  const suffix = h >= 12 ? 'PM' : 'AM';
  const h12 = h % 12 || 12;
  return `${h12.toString().padStart(2, '0')}:${mStr || '00'} ${suffix}`;
};

interface TaskModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (taskData: Omit<Task, 'id' | 'createdAt'>, existingId?: string) => void;
  editingTask: Task | null;
  employees: Employee[];
  departments: string[];
  defaultEmployee?: string;
  defaultDepartment?: string;
  currentUser?: Employee;
  isSuperAdmin?: boolean;
}

export const TaskModal: React.FC<TaskModalProps> = ({
  isOpen,
  onClose,
  onSave,
  editingTask,
  employees,
  departments,
  defaultEmployee,
  defaultDepartment,
  currentUser,
  isSuperAdmin = false,
}) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [status, setStatus] = useState<TaskStatus>('in_progress');
  const [employeeName, setEmployeeName] = useState(
    !isSuperAdmin && currentUser
      ? currentUser.name
      : defaultEmployee || (employees[0]?.name || 'Sandip Sahoo')
  );
  const [department, setDepartment] = useState(
    !isSuperAdmin && currentUser?.department
      ? currentUser.department
      : defaultDepartment || (departments[0] || 'Business Development & Tech')
  );
  const [startTime, setStartTime] = useState('10:30');
  const [endTime, setEndTime] = useState('11:30');
  const [priority, setPriority] = useState<TaskPriority>('medium');
  const [dueDate, setDueDate] = useState('');
  const [hasReminder, setHasReminder] = useState(false);
  const [reminderDate, setReminderDate] = useState('');
  const [reminderTime, setReminderTime] = useState('');
  const [subtasks, setSubtasks] = useState<SubTask[]>([]);
  const [comments, setComments] = useState<TaskComment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [newSubtaskTitle, setNewSubtaskTitle] = useState('');
  const [permission, setPermission] = useState(getNotificationPermission());

  useEffect(() => {
    if (editingTask) {
      setTitle(editingTask.title);
      setDescription(editingTask.description || '');
      setStatus(getTaskCategory(editingTask));
      setEmployeeName(editingTask.employeeName);
      setDepartment(editingTask.department);
      setStartTime(editingTask.startTime || '10:30');
      setEndTime(editingTask.endTime || '11:30');
      setPriority(editingTask.priority);
      setDueDate(editingTask.dueDate || '');
      setSubtasks(editingTask.subtasks || []);
      setComments(editingTask.comments || []);

      if (editingTask.reminderTime) {
        setHasReminder(true);
        const remDate = new Date(editingTask.reminderTime);
        setReminderDate(remDate.toISOString().split('T')[0]);
        const hh = String(remDate.getHours()).padStart(2, '0');
        const mm = String(remDate.getMinutes()).padStart(2, '0');
        setReminderTime(`${hh}:${mm}`);
      } else {
        setHasReminder(false);
        setReminderDate('');
        setReminderTime('');
      }
    } else {
      setTitle('');
      setDescription('');
      setStatus('in_progress');
      setEmployeeName(
        !isSuperAdmin && currentUser
          ? currentUser.name
          : defaultEmployee || (employees[0]?.name || 'Sandip Sahoo')
      );
      setDepartment(
        !isSuperAdmin && currentUser?.department
          ? currentUser.department
          : defaultDepartment || (departments[0] || 'Business Development & Tech')
      );
      setStartTime('10:30');
      setEndTime('11:30');
      setPriority('medium');
      const todayStr = new Date().toISOString().split('T')[0];
      setDueDate(todayStr);
      setHasReminder(false);
      setReminderDate('');
      setReminderTime('');
      setSubtasks([]);
      setComments([]);
    }
  }, [editingTask, defaultEmployee, defaultDepartment, employees, departments, isOpen, currentUser, isSuperAdmin]);

  // When employee changes, auto-sync their department if matching
  const handleEmployeeChange = (name: string) => {
    setEmployeeName(name);
    const found = employees.find((e) => e.name === name);
    if (found && found.department) {
      setDepartment(found.department);
    }
  };

  const currentDuration = calculateDurationHours(startTime, endTime);

  const applyShiftPreset = (s: string, e: string) => {
    setStartTime(s);
    setEndTime(e);
  };

  const handleAddSubtask = (e: React.FormEvent) => {
    e.preventDefault();
    if (newSubtaskTitle.trim()) {
      setSubtasks([
        ...subtasks,
        {
          id: `sub-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
          title: newSubtaskTitle.trim(),
          completed: false,
        },
      ]);
      setNewSubtaskTitle('');
    }
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (newComment.trim() && currentUser) {
      const comment: TaskComment = {
        id: `comment-${Date.now()}`,
        authorId: currentUser.id,
        authorName: currentUser.name,
        content: newComment.trim(),
        createdAt: new Date().toISOString()
      };
      setComments([...comments, comment]);
      setNewComment('');
    }
  };

  const handleRemoveSubtask = (id: string) => {
    setSubtasks(subtasks.filter((s) => s.id !== id));
  };

  const handleToggleSubtask = (id: string) => {
    setSubtasks(
      subtasks.map((s) => (s.id === id ? { ...s, completed: !s.completed } : s))
    );
  };

  const handleQuickReminderPreset = async (preset: 'start' | '15m' | '1h') => {
    setHasReminder(true);
    const now = new Date();

    if (preset === 'start') {
      const d = dueDate || now.toISOString().split('T')[0];
      setReminderDate(d);
      setReminderTime(startTime);
    } else if (preset === '15m') {
      const target = new Date(now.getTime() + 15 * 60 * 1000);
      setReminderDate(target.toISOString().split('T')[0]);
      setReminderTime(
        `${String(target.getHours()).padStart(2, '0')}:${String(target.getMinutes()).padStart(2, '0')}`
      );
    } else if (preset === '1h') {
      const target = new Date(now.getTime() + 60 * 60 * 1000);
      setReminderDate(target.toISOString().split('T')[0]);
      setReminderTime(
        `${String(target.getHours()).padStart(2, '0')}:${String(target.getMinutes()).padStart(2, '0')}`
      );
    }

    if (permission !== 'granted') {
      const res = await requestNotificationPermission();
      setPermission(res);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    let computedReminder: string | undefined = undefined;
    if (hasReminder && reminderDate && reminderTime) {
      computedReminder = new Date(`${reminderDate}T${reminderTime}:00`).toISOString();
    }

    const matchedEmp = employees.find((e) => e.name === employeeName);

    const isCompleted = status === 'completed';

    onSave(
      {
        title: title.trim(),
        description: description.trim() || undefined,
        employeeName,
        employeeRole: matchedEmp?.role,
        department,
        startTime,
        endTime,
        durationHours: currentDuration,
        priority,
        status,
        completed: isCompleted,
        completedAt: isCompleted ? (editingTask?.completedAt || new Date().toISOString()) : undefined,
        dueDate: dueDate || undefined,
        reminderTime: computedReminder,
        reminderTriggered:
          editingTask && computedReminder === editingTask.reminderTime
            ? editingTask.reminderTriggered
            : false,
        subtasks,
        comments,
      },
      editingTask ? editingTask.id : undefined
    );

    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        className="w-full max-w-xl max-h-[92vh] overflow-y-auto rounded-3xl border border-neutral-200 bg-white p-5 sm:p-6 shadow-2xl dark:border-neutral-800 dark:bg-neutral-900 transition-colors"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-neutral-100 dark:border-neutral-800">
          <div className="flex items-center gap-2">
            <span className="h-6 w-1.5 rounded-full bg-emerald-600" />
            <h2 className="text-base font-bold text-neutral-900 dark:text-neutral-100">
              {editingTask ? 'Edit Employee Work Log' : 'Log New Employee Work'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1 text-neutral-400 hover:bg-neutral-100 hover:text-neutral-700 dark:hover:bg-neutral-800 dark:hover:text-neutral-200 transition"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          
          {/* Work / Task Title */}
          <div>
            <label className="block text-[11px] font-semibold text-neutral-500 dark:text-neutral-400 mb-1 uppercase tracking-wider">
              Work Deliverable / Task Title *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Onboard grain merchants or inspect consignment weighbridge"
              autoFocus
              className="w-full rounded-xl border border-neutral-200 bg-neutral-50 px-3.5 py-2.5 text-sm text-neutral-900 placeholder:text-neutral-400 focus:border-emerald-500 focus:bg-white focus:outline-none dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100 dark:placeholder:text-neutral-500 dark:focus:border-emerald-500 transition"
            />
          </div>

          {/* Three Categories: To Do, In Progress, Completed */}
          <div>
            <label className="block text-[11px] font-semibold text-neutral-500 dark:text-neutral-400 mb-1.5 uppercase tracking-wider">
              Category & Status
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setStatus('todo')}
                className={`py-2 px-3 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                  status === 'todo'
                    ? 'border-blue-500 bg-blue-50 text-blue-900 dark:bg-blue-950 dark:text-blue-200 dark:border-blue-700 shadow-2xs'
                    : 'border-neutral-200 dark:border-neutral-700 text-neutral-600 dark:text-neutral-400 hover:bg-neutral-50 dark:hover:bg-neutral-800'
                }`}
              >
                <span>📋 To Do</span>
              </button>
              <button
                type="button"
                onClick={() => setStatus('in_progress')}
                className={`py-2 px-3 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                  status === 'in_progress'
                    ? 'border-amber-500 bg-amber-50 text-amber-900 dark:bg-amber-950 dark:text-amber-200 dark:border-amber-700 shadow-2xs'
                    : 'border-neutral-200 dark:border-neutral-700 text-neutral-600 dark:text-neutral-400 hover:bg-neutral-50 dark:hover:bg-neutral-800'
                }`}
              >
                <span>⚡ In Progress</span>
              </button>
              <button
                type="button"
                onClick={() => setStatus('completed')}
                className={`py-2 px-3 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                  status === 'completed'
                    ? 'border-emerald-500 bg-emerald-50 text-emerald-900 dark:bg-emerald-950 dark:text-emerald-200 dark:border-emerald-700 shadow-2xs'
                    : 'border-neutral-200 dark:border-neutral-700 text-neutral-600 dark:text-neutral-400 hover:bg-neutral-50 dark:hover:bg-neutral-800'
                }`}
              >
                <span>✅ Completed</span>
              </button>
            </div>
          </div>

          {/* Notes & Deliverable Instructions (Prominently displayed) */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-[11px] font-semibold text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
                Task Note / Deliverable Details
              </label>
              <span className="text-[10px] text-amber-600 dark:text-amber-400 font-bold">
                Opens in wide format on click
              </span>
            </div>
            <textarea
              rows={4}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Paste instructions, commodity specs, handover details, or customer notes..."
              className="w-full rounded-xl border border-neutral-200 bg-neutral-50 p-3 text-xs text-neutral-900 placeholder:text-neutral-400 focus:border-emerald-500 focus:bg-white focus:outline-none dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100 dark:placeholder:text-neutral-500 dark:focus:border-emerald-500 transition leading-relaxed font-sans"
            />
          </div>

          {/* Employee & Department Assignment */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-semibold text-neutral-500 dark:text-neutral-400 mb-1 uppercase tracking-wider flex items-center gap-1">
                <User className="h-3 w-3 text-emerald-600" />
                Assign Employee *
              </label>
              {isSuperAdmin ? (
                <select
                  value={employeeName}
                  onChange={(e) => handleEmployeeChange(e.target.value)}
                  className="w-full rounded-xl border border-neutral-200 bg-neutral-50 px-3 py-2 text-xs font-semibold text-neutral-800 focus:border-emerald-500 focus:bg-white focus:outline-none dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-200"
                >
                  {employees.map((emp) => (
                    <option key={emp.id} value={emp.name}>
                      {emp.name} ({emp.role})
                    </option>
                  ))}
                </select>
              ) : (
                <div className="w-full rounded-xl border border-neutral-200 bg-neutral-100/90 px-3 py-2 text-xs font-bold text-neutral-800 dark:border-neutral-700 dark:bg-neutral-800/90 dark:text-neutral-200 flex items-center justify-between">
                  <span>{currentUser?.name || employeeName} (You)</span>
                  <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold bg-emerald-100/80 dark:bg-emerald-950/80 px-1.5 py-0.5 rounded">
                    Personal Work Log
                  </span>
                </div>
              )}
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-neutral-500 dark:text-neutral-400 mb-1 uppercase tracking-wider flex items-center gap-1">
                <Building2 className="h-3 w-3 text-neutral-400" />
                Department / Stream
              </label>
              <select
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                className="w-full rounded-xl border border-neutral-200 bg-neutral-50 px-3 py-2 text-xs font-medium text-neutral-800 focus:border-emerald-500 focus:bg-white focus:outline-none dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-200"
              >
                {departments.map((dept) => (
                  <option key={dept} value={dept}>
                    {dept}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* START TIME & END TIME (12-Hour Timing · Updated by Sabyasachi) */}
          <div className="rounded-2xl border border-emerald-200/80 bg-emerald-50/40 dark:border-emerald-900/60 dark:bg-emerald-950/20 p-3.5 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs font-bold text-neutral-900 dark:text-neutral-100 flex items-center gap-1.5 whitespace-nowrap">
                <Clock className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                Work Shift Timing (12-Hour Timing · Updated by Sabyasachi)
              </span>
              <span className="font-mono text-xs font-bold text-emerald-800 dark:text-emerald-300 bg-emerald-100 dark:bg-emerald-900/80 px-2 py-0.5 rounded-lg border border-emerald-300 dark:border-emerald-800 whitespace-nowrap shrink-0">
                Duration: {currentDuration.toFixed(1)} hrs
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-neutral-600 dark:text-neutral-400 mb-1">
                  Start Time * (12h format: {to12Hour(startTime)})
                </label>
                <input
                  type="time"
                  required
                  value={startTime}
                  onChange={(e) => setStartTime(e.target.value)}
                  className="w-full rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 px-3 py-2 text-xs font-mono font-semibold text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-neutral-600 dark:text-neutral-400 mb-1">
                  End Time * (12h format: {to12Hour(endTime)})
                </label>
                <input
                  type="time"
                  required
                  value={endTime}
                  onChange={(e) => setEndTime(e.target.value)}
                  className="w-full rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 px-3 py-2 text-xs font-mono font-semibold text-neutral-900 dark:text-neutral-100 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>
            </div>

            {/* Shift Presets */}
            <div className="flex flex-wrap items-center gap-1.5 pt-1">
              <span className="text-[10px] text-neutral-500 dark:text-neutral-400 font-medium whitespace-nowrap">
                12h Presets:
              </span>
              <button
                type="button"
                onClick={() => applyShiftPreset('10:30', '11:30')}
                className="px-2.5 py-1 rounded-lg border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-[11px] font-medium text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-700 whitespace-nowrap shrink-0 transition-colors"
              >
                10:30 AM – 11:30 AM (1h)
              </button>
              <button
                type="button"
                onClick={() => applyShiftPreset('11:30', '13:30')}
                className="px-2.5 py-1 rounded-lg border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-[11px] font-medium text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-700 whitespace-nowrap shrink-0 transition-colors"
              >
                11:30 AM – 01:30 PM (2h)
              </button>
              <button
                type="button"
                onClick={() => applyShiftPreset('14:00', '16:30')}
                className="px-2.5 py-1 rounded-lg border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-[11px] font-medium text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-700 whitespace-nowrap shrink-0 transition-colors"
              >
                02:00 PM – 04:30 PM (2.5h)
              </button>
              <button
                type="button"
                onClick={() => applyShiftPreset('16:30', '18:30')}
                className="px-2.5 py-1 rounded-lg border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-[11px] font-medium text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-700 whitespace-nowrap shrink-0 transition-colors"
              >
                04:30 PM – 06:30 PM (2h)
              </button>
            </div>
          </div>

          {/* Date & Priority */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-semibold text-neutral-500 dark:text-neutral-400 mb-1 uppercase tracking-wider flex items-center gap-1">
                <Calendar className="h-3 w-3" />
                Work Date
              </label>
              <input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full rounded-xl border border-neutral-200 bg-neutral-50 px-3 py-2 text-xs font-mono text-neutral-800 focus:border-emerald-500 focus:bg-white focus:outline-none dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-200"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-neutral-500 dark:text-neutral-400 mb-1 uppercase tracking-wider">
                Priority
              </label>
              <div className="grid grid-cols-4 gap-1">
                {(['low', 'medium', 'high', 'urgent'] as const).map((p) => (
                  <button
                    key={p}
                    type="button"
                    onClick={() => setPriority(p)}
                    className={`py-1.5 rounded-lg text-[11px] font-medium capitalize transition border ${
                      priority === p
                        ? 'border-neutral-900 bg-neutral-900 text-white dark:border-neutral-100 dark:bg-neutral-100 dark:text-neutral-900 font-semibold'
                        : 'border-neutral-200 bg-white text-neutral-600 hover:border-neutral-300 dark:border-neutral-800 dark:bg-neutral-800/80 dark:text-neutral-400'
                    }`}
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-[11px] font-semibold text-neutral-500 dark:text-neutral-400 mb-1 uppercase tracking-wider">
              Work Notes & Deliverables
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Merchant feedback, transaction volume, consignment details, or blockers..."
              className="w-full rounded-xl border border-neutral-200 bg-neutral-50 px-3.5 py-2 text-xs text-neutral-900 placeholder:text-neutral-400 focus:border-emerald-500 focus:bg-white focus:outline-none dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100 dark:placeholder:text-neutral-500 dark:focus:border-emerald-500 transition"
            />
          </div>

          {/* Push Notification Reminder Section */}
          <div className="rounded-2xl border border-amber-200/80 bg-amber-50/50 dark:border-amber-900/60 dark:bg-amber-950/20 p-3.5 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Bell className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                <div>
                  <span className="text-xs font-semibold text-neutral-900 dark:text-neutral-100 block">
                    Push Notification Reminder
                  </span>
                  <span className="text-[10px] text-neutral-500 dark:text-neutral-400">
                    Sends browser push notification & chime when task begins
                  </span>
                </div>
              </div>

              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={hasReminder}
                  onChange={(e) => {
                    setHasReminder(e.target.checked);
                    if (e.target.checked && !reminderDate) {
                      handleQuickReminderPreset('start');
                    }
                  }}
                  className="sr-only peer"
                />
                <div className="w-9 h-5 bg-neutral-200 peer-focus:outline-none rounded-full peer dark:bg-neutral-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-neutral-600 peer-checked:bg-amber-500"></div>
              </label>
            </div>

            {hasReminder && (
              <div className="space-y-2.5 pt-1 animate-in fade-in duration-100">
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="text-[10px] font-medium text-neutral-500 dark:text-neutral-400">
                    Quick Reminder:
                  </span>
                  <button
                    type="button"
                    onClick={() => handleQuickReminderPreset('start')}
                    className="px-2 py-0.5 rounded-lg border border-amber-200 dark:border-amber-800 bg-white dark:bg-neutral-800 text-[10px] font-medium text-amber-900 dark:text-amber-200 hover:bg-amber-100 dark:hover:bg-neutral-700 transition"
                  >
                    At Task Start Time ({startTime})
                  </button>
                  <button
                    type="button"
                    onClick={() => handleQuickReminderPreset('15m')}
                    className="px-2 py-0.5 rounded-lg border border-amber-200 dark:border-amber-800 bg-white dark:bg-neutral-800 text-[10px] font-medium text-amber-900 dark:text-amber-200 hover:bg-amber-100 dark:hover:bg-neutral-700 transition"
                  >
                    In 15 Mins
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="date"
                    required={hasReminder}
                    value={reminderDate}
                    onChange={(e) => setReminderDate(e.target.value)}
                    className="w-full rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 px-3 py-1.5 text-xs font-mono text-neutral-800 dark:text-neutral-200"
                  />
                  <input
                    type="time"
                    required={hasReminder}
                    value={reminderTime}
                    onChange={(e) => setReminderTime(e.target.value)}
                    className="w-full rounded-xl border border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800 px-3 py-1.5 text-xs font-mono text-neutral-800 dark:text-neutral-200"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Subtasks / Checklist */}
          <div>
            <label className="block text-[11px] font-semibold text-neutral-500 dark:text-neutral-400 mb-1.5 uppercase tracking-wider">
              Checklist / Subtasks ({subtasks.length})
            </label>

            <div className="space-y-1.5 mb-2">
              {subtasks.map((sub) => (
                <div
                  key={sub.id}
                  className="flex items-center justify-between rounded-xl border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-800/40 px-3 py-1.5 text-xs"
                >
                  <div className="flex items-center gap-2 flex-1">
                    <button
                      type="button"
                      onClick={() => handleToggleSubtask(sub.id)}
                      className={`h-4 w-4 rounded border flex items-center justify-center ${
                        sub.completed
                          ? 'border-emerald-600 bg-emerald-600 text-white'
                          : 'border-neutral-300 bg-white dark:border-neutral-700 dark:bg-neutral-800'
                      }`}
                    >
                      {sub.completed && <Check className="h-2.5 w-2.5 stroke-[3]" />}
                    </button>
                    <span
                      className={
                        sub.completed
                          ? 'line-through text-neutral-400'
                          : 'text-neutral-800 dark:text-neutral-200'
                      }
                    >
                      {sub.title}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleRemoveSubtask(sub.id)}
                    className="text-neutral-400 hover:text-rose-500 p-0.5"
                  >
                    <Trash2 className="h-3 w-3" />
                  </button>
                </div>
              ))}
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                value={newSubtaskTitle}
                onChange={(e) => setNewSubtaskTitle(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddSubtask(e);
                  }
                }}
                placeholder="Add checklist item..."
                className="flex-1 rounded-xl border border-neutral-200 bg-neutral-50 px-3 py-1.5 text-xs text-neutral-900 placeholder:text-neutral-400 focus:outline-none dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100"
              />
              <button
                type="button"
                onClick={handleAddSubtask}
                className="rounded-xl border border-neutral-200 bg-white px-3 py-1.5 text-xs font-medium text-neutral-700 hover:bg-neutral-100 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-300 dark:hover:bg-neutral-700"
              >
                Add
              </button>
            </div>
          </div>

          {/* Collaboration Comments */}
          <div className="pt-4 border-t border-neutral-100 dark:border-neutral-800">
            <label className="block text-[11px] font-semibold text-neutral-500 dark:text-neutral-400 mb-2 uppercase tracking-wider">
              Collaboration & Shift Tracking Notes ({comments.length})
            </label>
            
            <div className="space-y-3 mb-4 max-h-48 overflow-y-auto pr-1">
              {comments.length === 0 ? (
                <p className="text-[10px] text-neutral-400 italic text-center py-2">No collaboration notes yet.</p>
              ) : (
                comments.map((comment) => (
                  <div key={comment.id} className="bg-neutral-50 dark:bg-neutral-800/40 rounded-2xl p-3 border border-neutral-100 dark:border-neutral-800">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-tight">
                        {comment.authorName}
                      </span>
                      <span className="text-[9px] text-neutral-400 font-mono">
                        {new Date(comment.createdAt).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <p className="text-xs text-neutral-700 dark:text-neutral-300 leading-relaxed">
                      {comment.content}
                    </p>
                  </div>
                ))
              )}
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddComment(e);
                  }
                }}
                placeholder="Leave a timestamped note..."
                className="flex-1 rounded-xl border border-neutral-200 bg-neutral-50 px-3.5 py-2 text-xs text-neutral-900 placeholder:text-neutral-400 focus:outline-none dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-100"
              />
              <button
                type="button"
                onClick={handleAddComment}
                className="rounded-xl bg-indigo-600 px-4 py-2 text-xs font-bold text-white hover:bg-indigo-700 shadow-sm transition"
              >
                Post
              </button>
            </div>
          </div>

          {/* Modal Actions */}
          <div className="pt-3 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-neutral-600 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-neutral-100 rounded-xl transition whitespace-nowrap shrink-0"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="rounded-xl bg-emerald-600 px-5 py-2 text-xs font-bold text-white hover:bg-emerald-700 transition shadow-xs whitespace-nowrap shrink-0"
            >
              {editingTask ? 'Save Changes' : 'Save Work Log'}
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
