import React, { useState } from 'react';
import {
  Check,
  Clock,
  Bell,
  Trash2,
  Pencil,
  ChevronDown,
  ChevronUp,
  User,
  Building2,
  Calendar,
  StickyNote,
  Maximize2,
  Flame,
  ListTodo,
  CheckCircle2,
  Star
} from 'lucide-react';
import { Task, TaskStatus, getTaskCategory } from '../types/task';
import { playChime } from '../services/notificationService';
import { formatTimeSlot } from '../data/initialTasks';

interface TaskItemProps {
  task: Task;
  onToggleComplete: (id: string) => void;
  onDelete: (id: string) => void;
  onEdit: (task: Task) => void;
  onQuickSnooze: (id: string, minutes: number) => void;
  onToggleSubtask: (taskId: string, subtaskId: string) => void;
  onOpenDetail?: (task: Task) => void;
  onUpdateStatus?: (id: string, status: TaskStatus) => void;
  isSuperAdmin?: boolean;
  onUpdateRating?: (id: string, rating: number) => void;
}

export const TaskItem: React.FC<TaskItemProps> = ({
  task,
  onToggleComplete,
  onDelete,
  onEdit,
  onQuickSnooze,
  onToggleSubtask,
  onOpenDetail,
  onUpdateStatus,
  isSuperAdmin,
  onUpdateRating,
}) => {
  const [showSubtasks, setShowSubtasks] = useState(false);
  const [isDeleteConfirming, setIsDeleteConfirming] = useState(false);

  const category = getTaskCategory(task);

  const handleToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!task.completed) {
      playChime('complete');
      if (onUpdateStatus) {
        onUpdateStatus(task.id, 'completed');
        return;
      }
    } else {
      if (onUpdateStatus) {
        onUpdateStatus(task.id, 'in_progress');
        return;
      }
    }
    onToggleComplete(task.id);
  };

  const handleOpenWide = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (onOpenDetail) {
      onOpenDetail(task);
    } else {
      onEdit(task);
    }
  };

  const todayStr = new Date().toISOString().split('T')[0];
  const isOverdue = !task.completed && task.dueDate && task.dueDate < todayStr;
  const isDueToday = task.dueDate === todayStr;

  const formatDueDate = (dateStr?: string) => {
    if (!dateStr) return null;
    if (dateStr === todayStr) return 'Today';
    const tomorrowStr = new Date(Date.now() + 86400000).toISOString().split('T')[0];
    if (dateStr === tomorrowStr) return 'Tomorrow';
    
    const parts = dateStr.split('-');
    if (parts.length === 3) {
      const d = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
      return d.toLocaleDateString([], { month: 'short', day: 'numeric' });
    }
    return dateStr;
  };

  const completedSubtasksCount = task.subtasks.filter((s) => s.completed).length;

  return (
    <div
      onClick={handleOpenWide}
      className={`group relative rounded-2xl border transition-all duration-150 cursor-pointer ${
        task.completed
          ? 'border-neutral-200/60 bg-neutral-50/60 dark:border-neutral-800/40 dark:bg-neutral-900/30 opacity-80'
          : category === 'in_progress'
          ? 'border-neutral-200/90 bg-white hover:border-amber-400/80 dark:border-neutral-800/90 dark:bg-neutral-900 dark:hover:border-amber-600/80 shadow-2xs hover:shadow-xs'
          : 'border-neutral-200/90 bg-white hover:border-blue-300 dark:border-neutral-800/90 dark:bg-neutral-900 dark:hover:border-neutral-700 shadow-2xs hover:shadow-xs'
      } p-3.5 sm:p-4`}
    >
      <div className="flex items-start gap-3">
        
        {/* Custom Rounded Checkbox */}
        <button
          type="button"
          onClick={handleToggle}
          className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-lg border transition-colors cursor-pointer ${
            task.completed
              ? 'border-emerald-600 bg-emerald-600 text-white dark:border-emerald-500 dark:bg-emerald-500'
              : 'border-neutral-300 bg-white hover:border-neutral-400 dark:border-neutral-700 dark:bg-neutral-800 dark:hover:border-neutral-600'
          }`}
          aria-label={task.completed ? 'Mark task incomplete' : 'Mark task complete'}
        >
          {task.completed && <Check className="h-3.5 w-3.5 stroke-[2.8]" />}
        </button>

        {/* Task Core Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div className="space-y-1 flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                {/* 3-Category Badge */}
                <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider ${
                  category === 'todo'
                    ? 'bg-blue-50 text-blue-800 dark:bg-blue-950/70 dark:text-blue-300 border border-blue-200 dark:border-blue-900'
                    : category === 'in_progress'
                    ? 'bg-amber-50 text-amber-800 dark:bg-amber-950/70 dark:text-amber-300 border border-amber-200 dark:border-amber-900'
                    : 'bg-emerald-50 text-emerald-800 dark:bg-emerald-950/70 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-900'
                }`}>
                  {category === 'todo' && <ListTodo className="w-3 h-3 text-blue-600" />}
                  {category === 'in_progress' && <Flame className="w-3 h-3 text-amber-500" />}
                  {category === 'completed' && <CheckCircle2 className="w-3 h-3 text-emerald-600" />}
                  <span>{category === 'todo' ? 'To Do' : category === 'in_progress' ? 'In Progress' : 'Completed'}</span>
                </span>

                <h3
                  className={`text-sm font-semibold leading-snug select-none transition ${
                    task.completed
                      ? 'line-through text-neutral-400 dark:text-neutral-500 font-normal'
                      : 'text-neutral-900 dark:text-neutral-100 group-hover:text-emerald-700 dark:group-hover:text-emerald-400'
                  }`}
                >
                  {task.title}
                </h3>
              </div>
            </div>

            {/* Quick Action Buttons on Desktop Hover */}
            <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
              <button
                type="button"
                onClick={handleOpenWide}
                className="p-1 rounded-lg text-neutral-400 hover:bg-neutral-100 hover:text-emerald-700 dark:hover:bg-neutral-800 dark:hover:text-emerald-400 transition cursor-pointer"
                title="Open in wide format to view note & details"
              >
                <Maximize2 className="h-3.5 w-3.5" />
              </button>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onEdit(task);
                }}
                className="p-1 rounded-lg text-neutral-400 hover:bg-neutral-100 hover:text-neutral-700 dark:hover:bg-neutral-800 dark:hover:text-neutral-200 transition cursor-pointer"
                title="Edit Work Details"
              >
                <Pencil className="h-3.5 w-3.5" />
              </button>

              {isDeleteConfirming ? (
                <div className="flex items-center gap-1 bg-rose-50 dark:bg-rose-950 p-0.5 rounded-lg border border-rose-200 dark:border-rose-900 animate-in zoom-in duration-150">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDelete(task.id);
                      setIsDeleteConfirming(false);
                    }}
                    className="px-2 py-0.5 rounded bg-rose-600 text-white text-[10px] font-bold hover:bg-rose-700 transition cursor-pointer"
                  >
                    Delete
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setIsDeleteConfirming(false);
                    }}
                    className="px-1.5 py-0.5 text-[10px] text-neutral-500 hover:text-neutral-800 font-bold cursor-pointer"
                  >
                    Esc
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setIsDeleteConfirming(true);
                  }}
                  className="p-1 rounded-lg text-neutral-400 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-950/40 dark:hover:text-rose-400 transition cursor-pointer"
                  title="Delete Work Log"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Note Snippet Box (Clickable to open in wide format) */}
          {task.description && (
            <div
              onClick={handleOpenWide}
              className="mt-2 p-2.5 rounded-xl bg-amber-50/70 dark:bg-neutral-800/60 border border-amber-200/70 dark:border-amber-900/50 hover:bg-amber-100/70 dark:hover:bg-neutral-800 transition group/note flex items-start gap-2.5 shadow-2xs"
              title="Click to open note in wide format"
            >
              <StickyNote className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 mt-0.5 shrink-0" />
              <div className="flex-1 min-w-0">
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-amber-800 dark:text-amber-300 block mb-0.5">
                  Pasted Note:
                </span>
                <p className="text-xs text-neutral-800 dark:text-neutral-200 line-clamp-2 leading-relaxed">
                  {task.description}
                </p>
              </div>
              <span className="text-[10px] font-bold text-amber-700 dark:text-amber-400 opacity-80 group-hover/note:opacity-100 transition whitespace-nowrap self-center hidden sm:inline">
                Open Wide ↗
              </span>
            </div>
          )}

          {/* Clean Typographic Metadata Row (Employee, Start/End Time, Department, Priority) */}
          <div className="mt-2.5 flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs text-neutral-500 dark:text-neutral-400 font-medium">
            
            {/* Start Time & End Time Slot */}
            <span className="inline-flex items-center gap-1 font-mono font-bold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded-md border border-emerald-200/80 dark:border-emerald-900/60">
              <Clock className="h-3 w-3" />
              {formatTimeSlot(task.startTime, task.endTime)}
              {task.durationHours ? ` (${task.durationHours.toFixed(1)}h)` : ''}
            </span>

            {/* Employee Name */}
            <span className="inline-flex items-center gap-1 font-semibold text-neutral-800 dark:text-neutral-200">
              <User className="h-3 w-3 text-neutral-400" />
              {task.employeeName}
            </span>

            {/* Department */}
            <span aria-hidden="true" className="text-neutral-300 dark:text-neutral-700">·</span>
            <span className="text-neutral-600 dark:text-neutral-400">
              {task.department}
            </span>

            {/* Priority Indicator */}
            {task.priority && (
              <>
                <span aria-hidden="true" className="text-neutral-300 dark:text-neutral-700">·</span>
                <span
                  className={`inline-flex items-center gap-1 capitalize font-medium ${
                    task.priority === 'urgent'
                      ? 'text-rose-600 dark:text-rose-400 font-semibold'
                      : task.priority === 'high'
                      ? 'text-amber-600 dark:text-amber-400 font-medium'
                      : task.priority === 'medium'
                      ? 'text-blue-600 dark:text-blue-400'
                      : 'text-neutral-400'
                  }`}
                >
                  <span
                    className={`w-1.5 h-1.5 rounded-full ${
                      task.priority === 'urgent'
                        ? 'bg-rose-500'
                        : task.priority === 'high'
                        ? 'bg-amber-500'
                        : task.priority === 'medium'
                        ? 'bg-blue-500'
                        : 'bg-neutral-400'
                    }`}
                  />
                  {task.priority}
                </span>
              </>
            )}

            {/* Due Date */}
            {task.dueDate && (
              <>
                <span aria-hidden="true" className="text-neutral-300 dark:text-neutral-700">·</span>
                <span
                  className={`inline-flex items-center gap-1 font-mono text-[11px] ${
                    isOverdue
                      ? 'text-rose-600 dark:text-rose-400 font-semibold'
                      : isDueToday
                      ? 'text-emerald-700 dark:text-emerald-400'
                      : 'text-neutral-500 dark:text-neutral-400'
                  }`}
                >
                  <Calendar className="h-3 w-3" />
                  {isOverdue && 'Overdue · '}
                  {formatDueDate(task.dueDate)}
                </span>
              </>
            )}

            {/* Performance Rating (Visible to all, editable by Super Admin) */}
            {(task.completed || task.rating) && (
              <>
                <span aria-hidden="true" className="text-neutral-300 dark:text-neutral-700">·</span>
                <div className="flex items-center gap-0.5" onClick={(e) => e.stopPropagation()}>
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      disabled={!isSuperAdmin}
                      onClick={() => onUpdateRating?.(task.id, star)}
                      className={`transition-all ${isSuperAdmin ? 'cursor-pointer hover:scale-110' : 'cursor-default'}`}
                    >
                      <Star
                        className={`h-3 w-3 ${
                          star <= (task.rating || 0)
                            ? 'fill-amber-400 text-amber-400 shadow-xs'
                            : 'text-neutral-300 dark:text-neutral-700'
                        }`}
                      />
                    </button>
                  ))}
                  {task.rating && (
                    <span className="text-[10px] font-black text-amber-600 dark:text-amber-400 ml-1">
                      {task.rating.toFixed(1)}
                    </span>
                  )}
                  {isSuperAdmin && !task.rating && (
                    <span className="text-[9px] font-bold text-neutral-400 ml-1 uppercase tracking-tighter">Rate Performance</span>
                  )}
                </div>
              </>
            )}

            {/* Scheduled Reminder Indicator */}
            {task.reminderTime && (
              <>
                <span aria-hidden="true" className="text-neutral-300 dark:text-neutral-700">·</span>
                <span
                  className={`inline-flex items-center gap-1 font-mono text-[11px] ${
                    task.reminderTriggered
                      ? 'text-neutral-400 dark:text-neutral-500'
                      : 'text-amber-600 dark:text-amber-400 font-semibold'
                  }`}
                  title={
                    task.reminderTriggered
                      ? 'Reminder alert sent'
                      : `Push reminder scheduled for ${new Date(task.reminderTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`
                  }
                >
                  <Bell className="h-3 w-3" />
                  {task.reminderTriggered ? 'Alerted' : 'Push Active'}
                </span>
              </>
            )}

            {/* Subtasks Progress Toggle */}
            {task.subtasks.length > 0 && (
              <>
                <span aria-hidden="true" className="text-neutral-300 dark:text-neutral-700">·</span>
                <button
                  onClick={() => setShowSubtasks(!showSubtasks)}
                  className="inline-flex items-center gap-1 text-[11px] font-mono text-neutral-600 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-neutral-100"
                >
                  <span>
                    {completedSubtasksCount}/{task.subtasks.length} checklist
                  </span>
                  {showSubtasks ? (
                    <ChevronUp className="h-3 w-3" />
                  ) : (
                    <ChevronDown className="h-3 w-3" />
                  )}
                </button>
              </>
            )}

          </div>

          {/* Subtasks Checklist */}
          {showSubtasks && task.subtasks.length > 0 && (
            <div className="mt-3 pl-2.5 border-l-2 border-neutral-200 dark:border-neutral-800 space-y-1.5 animate-in fade-in duration-100">
              {task.subtasks.map((sub) => (
                <div key={sub.id} className="flex items-center gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => onToggleSubtask(task.id, sub.id)}
                    className={`flex h-4 w-4 shrink-0 items-center justify-center rounded border transition ${
                      sub.completed
                        ? 'border-emerald-600 bg-emerald-600 text-white dark:border-emerald-500 dark:bg-emerald-500'
                        : 'border-neutral-300 bg-white dark:border-neutral-700 dark:bg-neutral-800'
                    }`}
                  >
                    {sub.completed && <Check className="h-2.5 w-2.5 stroke-[3]" />}
                  </button>
                  <span
                    className={`select-none ${
                      sub.completed
                        ? 'line-through text-neutral-400 dark:text-neutral-500'
                        : 'text-neutral-700 dark:text-neutral-300'
                    }`}
                  >
                    {sub.title}
                  </span>
                </div>
              ))}
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
