// src/lib/supabase.ts
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://jbzkkyorcotsqauggmna.supabase.co';
const supabaseAnonKey = 'sb_publishable_HG3MNAoSpy4Rnfc0Z0i5vw_DqNGk8-i';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);