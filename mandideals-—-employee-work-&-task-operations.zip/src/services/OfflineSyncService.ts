import { supabase } from '../lib/supabase';

export type SyncAction = {
  id: string;
  table: string;
  type: 'insert' | 'update' | 'upsert' | 'delete';
  data?: any;
  filter?: { column: string; value: any };
  timestamp: string;
};

const SYNC_QUEUE_KEY = 'mandideals_sync_queue';

class OfflineSyncService {
  private queue: SyncAction[] = [];
  private isProcessing = false;

  private listeners: ((length: number) => void)[] = [];
  private errorListeners: ((error: string | null) => void)[] = [];
  private lastError: string | null = null;

  constructor() {
    this.loadQueue();
    if (typeof window !== 'undefined') {
      window.addEventListener('online', () => this.processQueue());
    }
  }

  subscribe(listener: (length: number) => void) {
    this.listeners.push(listener);
    listener(this.queue.length);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  subscribeToErrors(listener: (error: string | null) => void) {
    this.errorListeners.push(listener);
    listener(this.lastError);
    return () => {
      this.errorListeners = this.errorListeners.filter(l => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach(l => l(this.queue.length));
  }

  private notifyError(error: string | null) {
    this.lastError = error;
    this.errorListeners.forEach(l => l(error));
  }

  private loadQueue() {
    try {
      const saved = localStorage.getItem(SYNC_QUEUE_KEY);
      if (saved) {
        this.queue = JSON.parse(saved);
        this.notify();
      }
    } catch (e) {
      console.error('Failed to load sync queue', e);
      this.queue = [];
    }
  }

  private saveQueue() {
    try {
      localStorage.setItem(SYNC_QUEUE_KEY, JSON.stringify(this.queue));
      this.notify();
    } catch (e) {
      console.error('Failed to save sync queue', e);
    }
  }

  async queueAction(action: Omit<SyncAction, 'id' | 'timestamp'>) {
    const id = typeof crypto !== 'undefined' && crypto.randomUUID 
      ? crypto.randomUUID() 
      : `sync-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

    const fullAction: SyncAction = {
      ...action,
      id,
      timestamp: new Date().toISOString(),
    };

    this.queue.push(fullAction);
    this.saveQueue();

    if (navigator.onLine) {
      this.processQueue();
    }
  }

  async processQueue() {
    if (this.isProcessing || this.queue.length === 0 || !navigator.onLine) return;

    this.isProcessing = true;
    console.log(`Starting sync of ${this.queue.length} actions...`);

    const actionsToProcess = [...this.queue];
    
    for (const action of actionsToProcess) {
      try {
        let query;
        switch (action.type) {
          case 'insert':
            query = supabase.from(action.table).insert(action.data);
            break;
          case 'update':
            query = supabase.from(action.table).update(action.data);
            if (action.filter) {
              query = query.eq(action.filter.column, action.filter.value);
            }
            break;
          case 'upsert':
            query = supabase.from(action.table).upsert(action.data);
            break;
          case 'delete':
            query = supabase.from(action.table).delete();
            if (action.filter) {
              query = query.eq(action.filter.column, action.filter.value);
            }
            break;
        }

        const { error } = await query;
        if (error) {
          console.error(`Sync failed for action ${action.id}:`, error);
          
          // If it's a permanent schema error (missing column/table)
          if (error.code === 'PGRST204' || error.code === '42P01') {
             const msg = `CRITICAL SCHEMA MISMATCH: ${error.message}. Please run supabase_schema.sql in your Supabase SQL Editor.`;
             console.error(msg);
             this.notifyError(msg);
             this.queue = this.queue.filter(a => a.id !== action.id);
             this.saveQueue();
             continue;
          }
          
          // If it's a unique constraint violation, remove it (already exists)
          if (error.code === '23505') {
             this.queue = this.queue.filter(a => a.id !== action.id);
             this.saveQueue();
             continue;
          }
          
          continue;
        }

        // Successfully synced, remove from queue
        this.queue = this.queue.filter(a => a.id !== action.id);
        this.saveQueue();
        if (this.lastError) this.notifyError(null);
        console.log(`Successfully synced action ${action.id}`);
      } catch (e) {
        console.error(`Unexpected error syncing action ${action.id}:`, e);
      }
    }

    this.isProcessing = false;
    
    if (this.queue.length > 0 && navigator.onLine) {
      // Retry if something failed but we are still online
      setTimeout(() => this.processQueue(), 5000);
    }
  }

  getQueueLength() {
    return this.queue.length;
  }
}

export const offlineSyncService = new OfflineSyncService();
