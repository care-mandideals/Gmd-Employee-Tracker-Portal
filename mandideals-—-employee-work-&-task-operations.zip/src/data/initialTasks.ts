import { Task, Employee } from '../types/task';

const today = new Date();
const todayStr = today.toISOString().split('T')[0];

const tomorrow = new Date(today.getTime() + 24 * 60 * 60 * 1000);
const tomorrowStr = tomorrow.toISOString().split('T')[0];

export const INITIAL_EMPLOYEES: Employee[] = [
  {
    id: 'emp-ceo-01',
    name: 'Sabyasachi Baral',
    email: 'sabyasachi.baral@mandideals.com',
    password: 'Sabya@123',
    role: 'Founder & CEO',
    department: 'CEO Strategic Initiatives',
    phone: '+91 98765 00001',
    location: 'Corporate HQ Executive Suite',
    joinedDate: '01-Jan-2023',
    shift: '08:30 AM – 08:30 PM',
    accessLevel: 'SUPER_ADMIN',
    isSuperAdmin: true,
    status: 'On Shift',
    isAuthorized: true,
    bio: 'Founder & Chief Executive Officer leading overall enterprise growth, agricultural commodity market expansions, and executive governance at MANDIDEALS.',
  },
];

export const INITIAL_DEPARTMENTS = [
  'Business Development & Tech',
  'Mandi Floor & Auction Operations',
  'Logistics & Dispatch',
  'Accounts & Settlement',
  'HR & Compliance',
  'CEO Strategic Initiatives',
];

export const INITIAL_NOTICES: import('../types/task').CompanyNotice[] = [];


export const DEFAULT_COMPANY_LOGO = 'https://raw.githubusercontent.com/lucide-react/lucide/main/icons/building-2.svg';
export function calculateDurationHours(startTime: string, endTime: string): number {
  if (!startTime || !endTime) return 1.0;
  const [sH, sM] = startTime.split(':').map(Number);
  const [eH, eM] = endTime.split(':').map(Number);
  let diff = (eH * 60 + eM) - (sH * 60 + sM);
  if (diff < 0) diff += 24 * 60;
  return Math.max(0.25, Number((diff / 60).toFixed(2)));
}

export function formatTimeSlot(startTime: string, endTime: string): string {
  const to12h = (timeStr: string) => {
    if (!timeStr) return '';
    const trimmed = timeStr.trim();
    if (/am|pm/i.test(trimmed)) return trimmed;
    const parts = trimmed.split(':');
    if (parts.length < 2) return trimmed;
    let h = parseInt(parts[0], 10);
    const m = parts[1].padStart(2, '0');
    if (isNaN(h)) return trimmed;
    const ampm = h >= 12 ? 'PM' : 'AM';
    h = h % 12 || 12;
    const hStr = h < 10 ? `0${h}` : `${h}`;
    return `${hStr}:${m} ${ampm}`;
  };
  if (!startTime && !endTime) return '';
  if (!startTime) return to12h(endTime);
  if (!endTime) return to12h(startTime);
  return `${to12h(startTime)} – ${to12h(endTime)}`;
}

// Reminder 30 mins from now
const reminderSoon = new Date(today.getTime() + 30 * 60 * 1000).toISOString();
// Reminder tomorrow 10:30 AM
const reminderTomorrow = new Date(`${tomorrowStr}T10:30:00`).toISOString();

export const INITIAL_TASKS: Task[] = [];
