export type TaskPriority = 'low' | 'medium' | 'high' | 'urgent';

export type TaskStatus = 'todo' | 'in_progress' | 'completed';

export interface SubTask {
  id: string;
  title: string;
  completed: boolean;
}

export type AccessLevel = 'SUPER_ADMIN' | 'ADMIN' | 'MANAGER' | 'STAFF';

export interface Employee {
  id: string;
  name: string;
  email: string;
  password?: string;
  role: string;
  department: string;
  phone?: string;
  location?: string;
  joinedDate?: string;
  shift?: string;
  accessLevel: AccessLevel;
  isSuperAdmin?: boolean;
  avatar?: string;
  status: 'Active' | 'On Shift' | 'Off Duty';
  bio?: string;
  isAuthorized?: boolean; // Required for Super Admin approval flow
  isPunchedIn?: boolean; // Current attendance state
  createdAt?: string;
}

export interface AttendanceLog {
  id: string;
  employeeId: string;
  employeeName: string;
  punchIn: string; // ISO string
  punchOut?: string; // ISO string
  date: string; // YYYY-MM-DD
  punchInLat?: number;
  punchInLng?: number;
  punchOutLat?: number;
  punchOutLng?: number;
  isLate?: boolean;
  lateReason?: string;
  createdAt?: string;
}

export interface LeaveRequest {
  id: string;
  employeeId: string;
  employeeName: string;
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
  reason: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
}

export interface TaskComment {
  id: string;
  authorId: string;
  authorName: string;
  content: string;
  createdAt: string;
}

export interface Task {
  id: string;
  title: string;
  description?: string; // Notes pasted by the employee / author
  employeeName: string;
  employeeRole?: string;
  department: string;
  startTime: string; // HH:mm format, e.g. "10:30"
  endTime: string;   // HH:mm format, e.g. "12:30"
  durationHours?: number; // Calculated, e.g. 2.0
  completed: boolean;
  status?: TaskStatus; // 'todo' | 'in_progress' | 'completed'
  completedAt?: string;
  createdAt: string;
  dueDate?: string; // YYYY-MM-DD
  reminderTime?: string; // ISO string e.g. "2026-09-28T14:30:00.000Z"
  reminderTriggered?: boolean;
  priority: TaskPriority;
  subtasks: SubTask[];
  rating?: number; // Performance rating (1-5) set by Super Admin
  comments?: TaskComment[];
}

export function getTaskCategory(task: Task): TaskStatus {
  if (task.completed) return 'completed';
  if (task.status === 'todo') return 'todo';
  if (task.status === 'completed') return 'completed';
  return 'in_progress';
}

export type NoticePriority = 'urgent' | 'announcement' | 'operational' | 'policy';

export interface CompanyNotice {
  id: string;
  title: string;
  content: string;
  authorName: string;
  authorRole: string;
  priority: NoticePriority;
  createdAt: string;
  pinned?: boolean;
}

export interface NotificationLog {
  id: string;
  taskId: string;
  taskTitle: string;
  employeeName: string;
  message: string;
  triggeredAt: string;
  read: boolean;
}

export type ThemeMode = 'light' | 'dark' | 'system';

export type ViewFilter = 'all' | 'today' | 'upcoming' | 'reminders' | 'completed' | string;

export type ActivePage = 'tasks' | 'profile' | 'admin' | 'notices' | 'attendance' | 'performance';

export interface CompanyShift {
  startTime12: string; // e.g. "10:30 AM"
  endTime12: string;   // e.g. "06:30 PM"
  durationHours: number; // e.g. 8.0
  updatedBy: string;   // "Sabyasachi (Super Admin & CEO)"
  updatedAt: string;
  notes?: string;
}

export function formatTo12Hour(timeStr?: string): string {
  if (!timeStr) return '';
  const trimmed = timeStr.trim();
  if (/am|pm/i.test(trimmed)) {
    return trimmed;
  }
  const parts = trimmed.split(':');
  if (parts.length < 2) return trimmed;
  let h = parseInt(parts[0], 10);
  const m = parts[1].padStart(2, '0');
  if (isNaN(h)) return trimmed;
  const ampm = h >= 12 ? 'PM' : 'AM';
  h = h % 12 || 12;
  const hStr = h < 10 ? `0${h}` : `${h}`;
  return `${hStr}:${m} ${ampm}`;
}

export function formatTimeSlot12h(startTime?: string, endTime?: string): string {
  if (!startTime && !endTime) return '';
  if (!startTime) return formatTo12Hour(endTime);
  if (!endTime) return formatTo12Hour(startTime);
  return `${formatTo12Hour(startTime)} – ${formatTo12Hour(endTime)}`;
}

/**
 * Unified helper to detect Super Admin (CEO) level access
 * Considers accessLevel flag, hardcoded executive emails, and specific developer authorized emails.
 */
export function checkIsSuperAdmin(user?: Employee | null): boolean {
  if (!user) return false;
  
  const email = (user.email || '').toLowerCase().trim();
  const name = (user.name || '').toLowerCase();
  
  return Boolean(
    user.accessLevel === 'SUPER_ADMIN' ||
    user.isSuperAdmin ||
    email === 'sabya@mandideals.com' ||
    email === 'sabyasachi.baral@mandideals.com' ||
    email === 'sandeepsahoo2001@gmail.com' ||
    name.includes('sabyasachi') ||
    (name.includes('sabya') && email.includes('mandideals'))
  );
}

